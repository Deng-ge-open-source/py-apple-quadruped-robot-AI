# StackForce SimReady -> MJLab

This project targets **MJLab 1.6.0** and RSL-RL. It contains a flat-ground,
contract-driven velocity task whose actor observation order is kept compatible with
the StackForce SimReady Sim2Sim contract. Actuation is generated per joint group, so
legged robots use position control while wheel-legged robots can combine position,
velocity and effort control without changing policy action order.

## Install

The CPU extra supports task discovery, MuJoCo-Warp simulation and short training smoke
tests. Use Linux plus an NVIDIA CUDA GPU for practical high-throughput training.

Windows PowerShell (CPU, also runs the bundled smoke test):

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\setup_stackforce_mjlab_env.ps1 -Backend cpu
```

Linux (CPU, also runs the bundled smoke test):

```bash
chmod +x scripts/setup_stackforce_mjlab_env.sh
./scripts/setup_stackforce_mjlab_env.sh cpu
```

After setup, a one-iteration CPU training check can be started on Windows with:

```powershell
py -m uv run train Mjlab-Velocity-Flat-Gen4TrotVirtualServo --gpu-ids None --env.scene.num-envs 1 --agent.max-iterations 1 --agent.logger tensorboard --agent.upload-model False
```

On Linux, use:

```bash
uv run train Mjlab-Velocity-Flat-Gen4TrotVirtualServo --gpu-ids None --env.scene.num-envs 1 --agent.max-iterations 1 --agent.logger tensorboard --agent.upload-model False

# High-throughput CUDA training:
uv sync --extra cu128
uv run train Mjlab-Velocity-Flat-Gen4TrotVirtualServo --env.scene.num-envs 4096
```

Task: `Mjlab-Velocity-Flat-Gen4TrotVirtualServo`

Package: `stackforce_mjlab_gen4_trot_virtual_servo`

Imported source: MJCF

Training terrain: plane. Training and playback use the flat plane.

The optional terrain selection is recorded in the manifest. A compatible Runner
can preview flat, mixed, stairs, slopes, obstacles and other individual presets.
Changing preview terrain never changes this training snapshot or policy inputs.
The configuration-page surface is an illustration; Runner playback uses the
actual generated collision terrain. Preview uses a fixed seed and medium difficulty.

Contact sensor matching capacity is sized automatically at startup from the
assembled scene and each sensor's matching criteria. The task reserves 25% spare
capacity and rounds up to a power of two, while preserving configured minimums.
The resolved value appears in the training log as `[contact-capacity]`.

## Shared backend contract

The generated task reads the same timing, command, reset and robot contract as the
Isaac Lab backend. Robot-specific controller ABI alignment is recorded separately in
`contracts/mjlab_policy_alignment.v1.json`.

- Authored physics dt: 0.001 s
- Authored policy decimation: 20
- Effective integration timing: config/numerical-integration.json (local preflight may subdivide physics steps while preserving the policy period).
- Action clip: +/-1.8
- Policy adapter: shared_backend_task_v1
- Action shape: 12
- Observation frame: base_angular_velocity, projected_gravity, commands, phase_sin_cos, virtual_joint_position_error, virtual_joint_velocity, applied_actions
- Observation shape: 47 x 6 = 282

## Export notes

- Native MJCF actuators were replaced with generated actuators for the MJLab policy contract.

Original reward terms without an exact MJLab semantic match are intentionally left at
MJLab defaults or omitted. Validate reward behavior before long training runs.
