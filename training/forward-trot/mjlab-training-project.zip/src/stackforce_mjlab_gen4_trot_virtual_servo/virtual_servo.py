"""Command-driven observer. Physical joint measurements never enter this state."""
from dataclasses import dataclass
import math
import torch
from mjlab.envs.mdp.actions import JointPositionAction, JointPositionActionCfg


@dataclass(kw_only=True)
class VirtualServoPositionActionCfg(JointPositionActionCfg):
    joint_names: tuple[str, ...] = ()
    target_velocity_limit: float = 0.0
    target_smoothing_alpha: float = 1.0
    target_resolution_rad: float = 0.0

    def build(self, env):
        return VirtualServoPositionAction(self, env)


class VirtualServoPositionAction(JointPositionAction):
    """Use the same bounded target for the plant, observer and action history."""
    def __init__(self, cfg, env):
        super().__init__(cfg, env)
        if not cfg.joint_names or set(cfg.joint_names) != set(self._target_names):
            raise ValueError('Virtual action requires exact ordered joint names')
        order = [self._target_names.index(name) for name in cfg.joint_names]
        self._target_ids = self._target_ids[order]
        self._target_names = list(cfg.joint_names)
        for name in ('_scale', '_offset', '_clip'):
            value = getattr(self, name, None)
            if isinstance(value, torch.Tensor) and value.ndim >= 2:
                setattr(self, name, value[:, order].clone())

    def process_actions(self, actions):
        previous = self._processed_actions.clone()
        super().process_actions(actions)
        limits = self._entity.data.joint_pos_limits[:, self._target_ids]
        self._processed_actions = torch.clamp(self._processed_actions, limits[..., 0], limits[..., 1])
        resolution = float(getattr(self.cfg, 'target_resolution_rad', 0))
        if not math.isfinite(resolution) or resolution < 0:
            raise ValueError('Target resolution must be finite and nonnegative')
        if resolution > 0:
            self._processed_actions = self._offset + torch.round((self._processed_actions - self._offset) / resolution) * resolution
            self._processed_actions = torch.clamp(self._processed_actions, limits[..., 0], limits[..., 1])
        alpha = float(getattr(self.cfg, 'target_smoothing_alpha', 1))
        if not 0 < alpha <= 1:
            raise ValueError('Target smoothing alpha must be in (0, 1]')
        if alpha < 1:
            self._processed_actions = previous + alpha * (self._processed_actions - previous)
        if getattr(self.cfg, 'target_velocity_limit', 0) > 0:
            maximum = self.cfg.target_velocity_limit * self._env.step_dt
            self._processed_actions = torch.clamp(self._processed_actions, previous - maximum, previous + maximum)

    def reset(self, env_ids=None):
        super().reset(env_ids)
        ids = slice(None) if env_ids is None else env_ids
        self._processed_actions[ids] = self._entity.data.default_joint_pos[ids][:, self._target_ids]


class VirtualServoState:
    def __init__(self, env, joint_names, settings):
        self.env = env
        self.settings = dict(settings)
        self.names = tuple(joint_names)
        self.robot = env.scene['robot']
        self.ids = [self.robot.joint_names.index(name) for name in joint_names]
        self.default = self.robot.data.default_joint_pos[:, self.ids].clone()
        limits = self.robot.data.joint_pos_limits[:, self.ids]
        self.lower, self.upper = limits[..., 0].clone(), limits[..., 1].clone()
        self.q = self.default.clone()
        self.dq = torch.zeros_like(self.q)
        self.target = self.default.clone()
        self.applied = torch.zeros_like(self.q)
        self.tick = torch.full((env.num_envs,), -1, dtype=torch.long, device=env.device)
        self.ready = torch.zeros(env.num_envs, dtype=torch.bool, device=env.device)

    def reset(self, env_ids=None):
        ids = slice(None) if env_ids is None else env_ids
        self.q[ids] = self.default[ids]
        self.dq[ids] = 0
        self.target[ids] = self.q[ids]
        self.applied[ids] = 0
        self.tick[ids] = -1
        self.ready[ids] = False

    def update(self):
        tick = int(self.env.common_step_counter)
        changed = self.tick != tick
        integrate = changed & self.ready
        dt = float(self.env.step_dt)
        kp, kd, inertia = (float(self.settings[k]) for k in ('kp', 'kd', 'inertia'))
        acceleration = (kp * (self.target - self.q) - kd * self.dq) / inertia
        velocity = self.dq + acceleration * dt
        position = torch.clamp(self.q + velocity * dt, self.lower, self.upper)
        self.dq = torch.where(integrate[:, None], velocity, self.dq)
        self.q = torch.where(integrate[:, None], position, self.q)
        terms = list(self.env.action_manager._terms.values())
        if len(terms) != 1 or not isinstance(terms[0], VirtualServoPositionAction):
            raise ValueError('Virtual servo requires one bounded position action term')
        action = terms[0]
        if list(action.target_names) != list(self.names):
            raise ValueError('Virtual observer/action joint order mismatch')
        delivered = action._processed_actions
        scale = torch.as_tensor(action.scale, device=self.q.device, dtype=self.q.dtype)
        if torch.any(scale == 0):
            raise ValueError('Virtual observer requires nonzero action scales')
        self.target = torch.where(changed[:, None], delivered, self.target)
        applied = (delivered - self.default) / scale
        self.applied = torch.where(changed[:, None] & self.ready[:, None], applied, self.applied)
        self.tick[changed] = tick
        self.ready[changed] = True


def virtual_servo_state(env, joint_names, settings):
    state = getattr(env, '_stackforce_virtual_servo', None)
    if state is None:
        state = env._stackforce_virtual_servo = VirtualServoState(env, joint_names, settings)
    if state.names != tuple(joint_names) or state.settings != settings:
        raise ValueError('Actor and critic must share one virtual-servo configuration')
    state.update()
    return state
