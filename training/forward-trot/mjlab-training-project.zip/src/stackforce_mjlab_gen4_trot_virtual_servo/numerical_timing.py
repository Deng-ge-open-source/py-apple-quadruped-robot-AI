"""Portable integration timing contract; shared with exported MJLab projects.

Only integer subdivisions of the authored physics step are supported. Policy,
sensor and motor periods, integrator, solver and all model parameters stay put.
"""
import json
import math
from pathlib import Path

TIMING_FILE = "config/numerical-integration.json"
FACTORS = (1, 2, 4, 8)
MIN_DT = 0.0001


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def profile_path(manifest):
    package = manifest.get("package_name", "")
    if not isinstance(package, str) or not package.isidentifier():
        raise ValueError("Invalid training package identifier")
    return "src/" + package + "/config/simready_policy.json"


def validate_timing(value):
    if not isinstance(value, dict) or value.get("schema") != 1:
        raise ValueError("Invalid numerical integration contract")
    base, effective, factor = value.get("base"), value.get("effective"), value.get("factor")
    if type(factor) is not int or factor not in FACTORS:
        raise ValueError("Unsupported physics subdivision")
    for timing in (base, effective):
        if not isinstance(timing, dict):
            raise ValueError("Missing numerical integration timing")
        dt, decimation = timing.get("simDt"), timing.get("decimation")
        if (type(dt) not in (float, int) or not math.isfinite(dt) or not MIN_DT <= dt <= 1
                or type(decimation) is not int or decimation < 1 or dt * decimation > 10):
            raise ValueError("Invalid numerical integration timing")
    if (not math.isclose(effective["simDt"] * factor, base["simDt"], rel_tol=1e-12)
            or effective["decimation"] != base["decimation"] * factor):
        raise ValueError("Physics subdivision must preserve the policy period")
    return value


def project_timing(project):
    project = Path(project)
    manifest = read_json(project / "manifest.json")
    if manifest.get("numerical_integration") != "subdivide-v1":
        return None  # Existing projects keep their authored configuration.
    timing = validate_timing(read_json(project / TIMING_FILE))
    effective = timing["effective"]
    policy_dt = effective["simDt"] * effective["decimation"]
    contract = read_json(project / "contracts/backend_task.v1.json")
    config = read_json(project / "config/effective-training.json")
    candidates = [contract["policy"], config["backendContract"]["policy"],
                  {"simDt": manifest.get("sim_dt"), "decimation": manifest.get("decimation"),
                   "policyDt": manifest.get("policy_dt")}]
    for candidate in candidates:
        if (candidate.get("simDt") != effective["simDt"] or
                candidate.get("decimation") != effective["decimation"] or
                not math.isclose(candidate.get("policyDt", 0), policy_dt, rel_tol=1e-12)):
            raise ValueError("Numerical integration and training contracts disagree; export the project again")
    if config["training"].get("runtimeTiming") != effective:
        raise ValueError("Effective training timing disagrees with integration contract")
    profile = read_json(project / profile_path(manifest))["runtime"]["timing"]
    if (profile.get("simDt") != effective["simDt"] or profile.get("decimation") != effective["decimation"]
            or not math.isclose(profile.get("controlDt", 0), policy_dt, rel_tol=1e-12)):
        raise ValueError("Policy profile timing disagrees with integration contract")
    return timing


def configure_timing(cfg, module_file):
    """Called by the task factory for checking, training, replay and export."""
    project = Path(module_file).resolve().parents[2]
    timing = project_timing(project)
    if timing is None:
        raise ValueError("Numerical integration contract missing; export the project again")
    if (not math.isclose(cfg.sim.mujoco.timestep, timing["base"]["simDt"], rel_tol=1e-12)
            or cfg.decimation != timing["base"]["decimation"]):
        raise ValueError("Authored task timing disagrees with integration contract")
    cfg.sim.mujoco.timestep = timing["effective"]["simDt"]
    cfg.decimation = timing["effective"]["decimation"]
