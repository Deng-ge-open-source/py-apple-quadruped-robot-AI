"""Load final exported resources without native filesystem encoding dependencies.

Only resource references are canonicalized, never physical definitions. The
source files stay untouched. Flat content-addressed VFS keys avoid MuJoCo's
basename fallback and survive spec copies and scene attachment.
"""
import hashlib
from pathlib import Path
import xml.etree.ElementTree as ET
import mujoco

MAX_RESOURCE_BYTES = 1024 * 1024 * 1024
MAX_RESOURCE_FILES = 20000
# In-process only. The Runner can recover bounded format facts from VFS errors
# without logging a customer filename or re-searching unrelated directories.
RESOURCE_PATHS = {}


def load_model_spec(model_xml):
    model_xml = Path(model_xml).resolve(strict=True)
    root = model_xml.parent
    assets, loaded, aliases, model_includes = {}, {}, {}, {}
    total = 0

    def resolve(name, directory):
        path = (directory / name.replace('\\', '/')).resolve()
        if not path.is_relative_to(root):
            raise ValueError('Model reference escapes the exported asset directory.')
        if not path.is_file():
            raise FileNotFoundError(2, 'Missing model resource', str(path))
        return path

    def read(path):
        nonlocal total
        if path in loaded:
            return loaded[path]
        size = path.stat().st_size
        if len(loaded) >= MAX_RESOURCE_FILES or total + size > MAX_RESOURCE_BYTES:
            raise ValueError('Model resources exceed the 1 GiB / 20,000 file limit.')
        content = path.read_bytes()
        if len(content) != size:
            raise ValueError('Model resource changed during loading; retry preflight.')
        loaded[path] = content
        total += size
        return content

    def prepare(path, stack):
        if path in stack:
            raise ValueError('Cyclic model resource reference.')
        stack = (*stack, path)
        tree = ET.fromstring(read(path))
        included = set()
        def expand(element, directory):
            for child in list(element):
                if child.tag != 'include':
                    expand(child, directory)
                    continue
                target = resolve(child.attrib['file'], directory)
                if target in included or target in stack:
                    raise ValueError('Repeated or cyclic model include.')
                included.add(target)
                nested = ET.fromstring(read(target))
                expand(nested, target.parent)
                index = list(element).index(child)
                element.remove(child)
                for offset, entry in enumerate(nested): element.insert(index + offset, entry)
        expand(tree, path.parent)
        compiler = {}
        for item in tree.findall('compiler'):
            if 'assetdir' in item.attrib:
                compiler.update(meshdir=item.attrib['assetdir'], texturedir=item.attrib['assetdir'])
            compiler.update(item.attrib)
            for key in ('meshdir', 'texturedir', 'assetdir'): item.attrib.pop(key, None)
        for asset in [*tree.findall('asset/*'), *tree.findall('deformable/skin')]:
            directory = (compiler.get('meshdir', compiler.get('assetdir', '')) if asset.tag in ('mesh', 'skin', 'hfield') else
                         compiler.get('texturedir', compiler.get('assetdir', '')) if asset.tag == 'texture' else '')
            for attr in ('file', 'fileback', 'filedown', 'filefront', 'fileleft', 'fileright', 'fileup'):
                name = asset.get(attr)
                if not name: continue
                normalized = name.replace('\\', '/')
                if compiler.get('strippath', 'false').lower() == 'true': normalized = normalized.rsplit('/', 1)[-1]
                target = resolve(normalized, path.parent / directory)
                identity = (target, asset.tag == 'model')
                if identity not in aliases:
                    content = prepare(target, stack).encode('utf-8') if asset.tag == 'model' else read(target)
                    key = 'sf_asset_' + hashlib.sha256(content).hexdigest() + target.suffix.lower()
                    assets[key] = content
                    if asset.tag == 'model': model_includes[key] = content
                    RESOURCE_PATHS[key] = target
                    aliases[identity] = key
                asset.set(attr, aliases[identity])
                # MuJoCo infers unnamed assets from the original filename stem.
                if attr == 'file' and not asset.get('name'):
                    asset.set('name', Path(normalized).stem)
        return ET.tostring(tree, encoding='unicode')

    xml = prepare(model_xml, ())
    return mujoco.MjSpec.from_string(xml, assets=assets, include=model_includes)
