"""Velocity runner with metadata support for mixed joint actions."""

import hashlib
import wandb
import torch

from mjlab.rl.exporter_utils import attach_metadata_to_onnx
from mjlab.rl.runner import MjlabOnPolicyRunner
from mjlab.tasks.velocity.rl import VelocityOnPolicyRunner
from .velocity_curriculum import curriculum_checkpoint_state, restore_curriculum_checkpoint


STACKFORCE_PROFILE_KEY = ""
SF_SOLE_ACCEPTED_SHA256 = "b379ab5a1e0aaf3ff427a6519249e05925397529cc106aae2d3fe1c4bd70b25d"


def _stackforce_metadata(env, run_path: str) -> dict:
  robot = env.scene["robot"]
  from .robot_constants import ACTUATED_JOINTS
  policy_joint_ids = [robot.joint_names.index(name) for name in ACTUATED_JOINTS]
  action = next(iter(env.action_manager._terms.values()))
  joint_name_to_ctrl_id = {}
  for actuator in robot.spec.actuators:
    joint_name_to_ctrl_id[actuator.target.split("/")[-1]] = actuator.id
  ctrl_ids = [
    joint_name_to_ctrl_id[name]
    for name in ACTUATED_JOINTS
    if name in joint_name_to_ctrl_id
  ]
  stiffness = env.sim.mj_model.actuator_gainprm[ctrl_ids, 0]
  damping = -env.sim.mj_model.actuator_biasprm[ctrl_ids, 2]


  observation_names = env.observation_manager.active_terms["actor"]
  observation_scale = []
  flatten_history = []
  history_length = []
  observation_clip = []
  for name in observation_names:
    cfg = env.observation_manager.get_term_cfg("actor", name)
    raw_scale = cfg.scale
    observation_scale.append(
      raw_scale.cpu().tolist() if isinstance(raw_scale, torch.Tensor) else (
        1.0 if raw_scale is None else raw_scale
      )
    )
    observation_clip.append(
      [float("-inf"), float("inf")] if cfg.clip is None else list(cfg.clip)
    )
    flatten_history.append(cfg.flatten_history_dim)
    history_length.append(cfg.history_length)
  raw_action_scale = action._scale
  if isinstance(raw_action_scale, torch.Tensor):
    raw_action_scale = raw_action_scale[0].detach().cpu().tolist()
  native_metadata = {}
  if type(action).__name__ == "NativeActuatorAction":
    import json
    from .native_actuators import CONTRACT
    native_metadata = {"stackforce_native_actuators": json.dumps(CONTRACT),
                       "stackforce_action_coordinates": "actuator_ctrl_before_gear",
                       "stackforce_action_ids": json.dumps([a["id"] for a in CONTRACT["actuators"]])}
  if 'reach' in env.command_manager.active_terms:
    import json
    from pathlib import Path
    from .manipulator import CONFIG
    contract = json.loads((Path(__file__).resolve().parents[2] / 'contracts/backend_task.v1.json').read_text())
    native_metadata.update({
      'stackforce_task_family': 'end_effector_reach',
      'stackforce_manipulator': json.dumps(CONFIG),
      'stackforce_policy_contract': json.dumps(contract['policy']),
      'stackforce_control_groups': json.dumps(contract['robot']['controlGroups']),
      'stackforce_policy_dt': env.step_dt,
    })
  return {
    **native_metadata,
    "run_path": run_path,
    "joint_names": list(ACTUATED_JOINTS),
    "joint_stiffness": stiffness.tolist(),
    "joint_damping": damping.tolist(),
    "default_joint_pos": robot.data.default_joint_pos[0, policy_joint_ids].cpu().tolist(),
    "model_joint_names": list(robot.joint_names),
    "model_default_joint_pos": robot.data.default_joint_pos[0].cpu().tolist(),
    "command_names": list(env.command_manager.active_terms),
    "observation_names": observation_names,
    "observation_terms_scale": observation_scale,
    "observation_terms_flatten_history_dim": flatten_history,
    "observation_terms_history_length": history_length,
    "observation_terms_clip": observation_clip,
    "action_scale": raw_action_scale,


  }


def _qmini_native_actor_state(path: str) -> dict | None:
  """Recognize the pinned RoboTamer 129x12 actor checkpoint."""
  try:
    payload = torch.load(path, map_location="cpu", weights_only=False)
  except Exception:
    return None
  actor = payload.get("actor") if isinstance(payload, dict) else None
  input_weight = actor.get("preprocess.net.0.weight") if isinstance(actor, dict) else None
  output_weight = actor.get("mu.weight") if isinstance(actor, dict) else None
  if (
    isinstance(input_weight, torch.Tensor)
    and tuple(input_weight.shape) == (512, 129)
    and isinstance(output_weight, torch.Tensor)
    and tuple(output_weight.shape) == (12, 256)
  ):
    return actor
  return None


def _sf_sole_accepted_actor_state(path: str) -> dict | None:
  """Load only the reviewed Isaac actor; MJLab rebuilds critic and optimizer state."""
  if STACKFORCE_PROFILE_KEY != "sf_biped_sole":
    return None
  digest = hashlib.sha256()
  try:
    with open(path, "rb") as stream:
      for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(chunk)
    if digest.hexdigest() != SF_SOLE_ACCEPTED_SHA256:
      return None
    payload = torch.load(path, map_location="cpu", weights_only=False)
  except Exception:
    return None
  state = payload.get("model_state_dict") if isinstance(payload, dict) else None
  input_weight = state.get("actor.0.weight") if isinstance(state, dict) else None
  output_weight = state.get("actor.6.weight") if isinstance(state, dict) else None
  if (
    isinstance(input_weight, torch.Tensor)
    and tuple(input_weight.shape) == (512, 40)
    and isinstance(output_weight, torch.Tensor)
    and tuple(output_weight.shape) == (8, 128)
  ):
    return state
  return None


class StackForceVelocityOnPolicyRunner(VelocityOnPolicyRunner):
  def export_policy_to_onnx(self, path, filename="policy.onnx", **kwargs):
    import os
    import onnx
    from onnx.compose import add_prefix

    result = super().export_policy_to_onnx(path, filename, **kwargs)
    output_path = os.path.join(path, filename)
    model = add_prefix(onnx.load(output_path), "stackforce_internal/")
    if len(model.graph.input) != 1 or len(model.graph.output) != 1:
      raise RuntimeError("Custom policy export requires one Actor input and one Action output")
    names = {
      model.graph.input[0].name: "obs",
      model.graph.output[0].name: "action",
    }
    for node in model.graph.node:
      for field in (node.input, node.output):
        for index, name in enumerate(field):
          field[index] = names.get(name, name)
    for value in (*model.graph.input, *model.graph.output, *model.graph.value_info):
      value.name = names.get(value.name, value.name)
    onnx.checker.check_model(model)
    onnx.save(model, output_path)
    return result

  def load(
    self,
    path: str,
    load_cfg: dict | None = None,
    strict: bool = True,
    map_location: str | None = None,
  ) -> dict:
    qmini_actor = _qmini_native_actor_state(path)
    if qmini_actor is not None:
      target = self.alg._raw_actor.state_dict()
      mapping = {
        "distribution.std_param": "std",
        "mlp.0.weight": "preprocess.net.0.weight",
        "mlp.0.bias": "preprocess.net.0.bias",
        "mlp.2.weight": "preprocess.net.2.weight",
        "mlp.2.bias": "preprocess.net.2.bias",
        "mlp.4.weight": "mu.weight",
        "mlp.4.bias": "mu.bias",
      }
      if set(target) != set(mapping):
        raise RuntimeError(
          "RoboTamer checkpoint requires the Qmini 129x12 tanh actor architecture."
        )
      for target_key, source_key in mapping.items():
        source = qmini_actor[source_key]
        if tuple(source.shape) != tuple(target[target_key].shape):
          raise RuntimeError(
            f"RoboTamer tensor mismatch for {source_key}: "
            f"{tuple(source.shape)} != {tuple(target[target_key].shape)}"
          )
        target[target_key] = source.to(
          device=target[target_key].device, dtype=target[target_key].dtype
        )
      self.alg._raw_actor.load_state_dict(target, strict=True)
      print("[INFO] Loaded RoboTamer Qmini native 129x12 actor adapter.")
      return {
        "stackforceAdapter": "robotamer_qmini_native_129x12_v1",
        "sourceCheckpoint": path,
      }
    sf_sole_actor = _sf_sole_accepted_actor_state(path)
    if sf_sole_actor is not None:
      target = self.alg._raw_actor.state_dict()
      mapping = {
        "distribution.std_param": "std",
        "mlp.0.weight": "actor.0.weight",
        "mlp.0.bias": "actor.0.bias",
        "mlp.2.weight": "actor.2.weight",
        "mlp.2.bias": "actor.2.bias",
        "mlp.4.weight": "actor.4.weight",
        "mlp.4.bias": "actor.4.bias",
        "mlp.6.weight": "actor.6.weight",
        "mlp.6.bias": "actor.6.bias",
      }
      if set(target) != set(mapping):
        raise RuntimeError(
          "Accepted SF-sole checkpoint requires the aligned 40x8 actor architecture."
        )
      for target_key, source_key in mapping.items():
        source = sf_sole_actor[source_key]
        if target_key == "distribution.std_param" and load_cfg is None:
          # The reviewed deployment std is ~0.04. Restore exploration only for
          # cross-engine training; actor-only inference remains byte-equivalent.
          source = torch.full_like(source, 0.25)
        if tuple(source.shape) != tuple(target[target_key].shape):
          raise RuntimeError(
            f"Accepted SF-sole tensor mismatch for {source_key}: "
            f"{tuple(source.shape)} != {tuple(target[target_key].shape)}"
          )
        target[target_key] = source.to(
          device=target[target_key].device, dtype=target[target_key].dtype
        )
      self.alg._raw_actor.load_state_dict(target, strict=True)
      print("[INFO] Loaded accepted SF-sole Isaac actor; reset MJLab critic/optimizer.")
      return {
        "stackforceAdapter": "sf_sole_accepted_reference_residual_v1",
        "sourceCheckpoint": path,
      }
    infos = super().load(
      path, load_cfg=load_cfg, strict=strict, map_location=map_location
    )
    # Actor-only inference and current-project warm starts keep their GUI config.
    if load_cfg is None and isinstance(infos, dict):
      restore_curriculum_checkpoint(self.env.unwrapped, infos.get("velocity_curriculum"))
    return infos

  def save(self, path: str, infos=None):
    infos = dict(infos or {})
    infos["velocity_curriculum"] = curriculum_checkpoint_state(self.env.unwrapped)
    MjlabOnPolicyRunner.save(self, path, infos)
    policy_dir, filename, onnx_path = self._get_export_paths(path)
    try:
      self.export_policy_to_onnx(str(policy_dir), filename)
      run_name = (
        wandb.run.name
        if self.logger.logger_type in ("wandb", "WandbLogWriter") and wandb.run
        else "local"
      )
      attach_metadata_to_onnx(
        str(onnx_path), _stackforce_metadata(self.env.unwrapped, run_name)
      )
      if (
        self.logger.logger_type in ("wandb", "WandbLogWriter")
        and self.cfg["upload_model"]
      ):
        wandb.save(str(onnx_path), base_path=str(policy_dir))
    except Exception as error:
      print(f"[WARN] ONNX export failed (training continues): {error}")
