"""SimReady terrain selection and terrain-relative measurements (MJLab 1.6)."""
from dataclasses import dataclass, replace
from copy import copy
import math
import uuid
import importlib.metadata
import numpy as np
import mujoco
import torch
import warp as wp
import mujoco_warp as mjwarp
from mjlab.terrains import config as presets
from mjlab.terrains.terrain_generator import TerrainGeneratorCfg, SubTerrainCfg, TerrainGeometry, TerrainOutput
from mjlab.terrains.heightfield_terrains import color_by_height

PRESETS = ('plane', 'mixed', 'rough', 'stairs_up', 'stairs_down', 'slope_up',
           'slope_down', 'obstacles', 'waves', 'hills', 'random_stairs',
           'stepping_stones', 'narrow_beams', 'tilted_grid')


def configure_alternating_wave_collision_capacity():
    # MuJoCo Warp 3.11's EPA allocates just 24 horizon edges. Smooth cylindrical
    # tires against heightfield prisms can exhaust this even at coarse grid
    # resolution. Increase scratch capacity, not tolerance or contact pruning.
    # Only new alternating-wave tasks opt in; old tasks keep their allocation.
    if importlib.metadata.version('mujoco-warp') != '3.11.0':
        raise RuntimeError('Alternating-wave collision capacity requires verified mujoco-warp 3.11.0')
    from .hfield_collision import install_heightfield_witness_fix
    if install_heightfield_witness_fix():
        print('[SimReady] Alternating waves: signed heightfield surface witnesses enabled.', flush=True)
    from mujoco_warp._src import collision_convex, collision_flex
    changed = collision_convex.MJ_MAX_EPAHORIZON < 128 or collision_flex.MJ_MAX_EPAHORIZON < 128
    for module in (collision_convex, collision_flex):
        module.MJ_MAX_EPAHORIZON = max(module.MJ_MAX_EPAHORIZON, 128)
    if changed:
        print('[SimReady] Alternating waves: EPA horizon scratch capacity 128; no contact pruning.', flush=True)


@dataclass(kw_only=True)
class AlternatingWaveCfg(SubTerrainCfg):
    height_range: tuple[float, float]
    wavelength: float
    lateral_wavelength: float
    forward_axis: str = 'y'

    def function(self, difficulty, spec, rng):
        height = self.height_range[0] + difficulty * (self.height_range[1] - self.height_range[0])
        # Twelve samples per shortest cycle bound interpolation error without
        # making tiny tires/bodies overlap excessive heightfield prisms.
        # Runtime overflow remains fatal; this never clips contact buffers.
        spacing = min(.04, self.wavelength/12, self.lateral_wavelength/12)
        # MuJoCo heightfields store rows along Y and columns along X.
        x = np.linspace(-self.size[0]/2, self.size[0]/2, math.ceil(self.size[0]/spacing)+1)
        y = np.linspace(-self.size[1]/2, self.size[1]/2, math.ceil(self.size[1]/spacing)+1)
        xx, yy = np.meshgrid(x, y)
        forward, lateral = (xx, yy) if self.forward_axis == 'x' else (yy, xx)
        heights = height/2 * np.sin(2*np.pi*forward/self.wavelength) * np.sin(2*np.pi*lateral/self.lateral_wavelength)
        token = uuid.uuid4().hex
        field = spec.add_hfield(name='alternating_wave_'+token,
            size=[self.size[0]/2, self.size[1]/2, height, max(.001, height/4)],
            nrow=len(y), ncol=len(x), userdata=(heights/height+.5).astype(np.float32).ravel().tolist())
        material = color_by_height(spec, heights, token, heights)
        geom = spec.body('terrain').add_geom(type=mujoco.mjtGeom.mjGEOM_HFIELD,
            hfieldname=field.name, pos=[self.size[0]/2, self.size[1]/2, -height/2], material=material)
        return TerrainOutput(origin=np.array([self.size[0]/2, self.size[1]/2, 0.]),
            geometries=[TerrainGeometry(geom=geom, hfield=field)])


def configure_terrain(cfg, preset, scale=0.5, seed=42, curriculum=False, preview=False, legacy=False, waves=None):
    if preset not in PRESETS:
        raise ValueError('Unknown terrain preset: '+str(preset))
    terrain = cfg.scene.terrain
    if terrain is None:
        raise ValueError('Task has no terrain configuration')
    if preset == 'plane':
        terrain.terrain_type = 'plane'
        terrain.terrain_generator = None
        return
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError('Terrain scale must be a positive standing height')
    # Scale terrain dimensions, never robot geometry, collision or dynamics.
    platform = max(0.6, 2.5 * scale)
    tread = max(0.12, 0.8 * scale)
    stairs = dict(step_height_range=(0.02*scale, 0.25*scale), step_width=tread,
                  platform_width=platform, border_width=0.25)
    choices = {
        'rough': presets.random_rough(noise_range=(0.01*scale, 0.15*scale), noise_step=0.005),
        # MJLab spawns at the central platform: inverted stairs ascend outwards.
        'stairs_up': presets.pyramid_stairs_inv(**stairs),
        'stairs_down': presets.pyramid_stairs(**stairs),
        'slope_up': presets.hf_pyramid_slope_inv(slope_range=(0.0, math.tan(math.radians(20))), platform_width=platform),
        'slope_down': presets.hf_pyramid_slope(slope_range=(0.0, math.tan(math.radians(20))), platform_width=platform),
        'obstacles': presets.random_spread_boxes(num_boxes=24, box_width_range=(0.3*scale, scale),
            box_length_range=(0.5*scale, 1.5*scale), box_height_range=(0.02*scale, 0.25*scale), platform_width=platform),
        'waves': presets.wave_terrain(amplitude_range=(0.0, 0.3*scale), num_waves=3),
        'hills': presets.perlin_noise(height_range=(0.0, 0.5*scale)),
        'random_stairs': presets.random_stairs(**stairs),
        'stepping_stones': presets.stepping_stones(stone_size_range=(0.7*scale, 1.4*scale),
            stone_distance_range=(0.1*scale, 0.4*scale), stone_height=0.2*scale,
            stone_height_variation=0.1*scale, displacement_range=0.1*scale, platform_width=platform),
        'narrow_beams': presets.narrow_beams(beam_width_range=(0.4*scale, scale), platform_width=platform),
        'tilted_grid': presets.tilted_grid(grid_width=max(0.3, scale), tilt_range_deg=15,
            height_range=0.2*scale, platform_width=platform),
    }
    if waves is not None and preset == 'waves':
        heights, wavelength = waves['heightRange'], waves['wavelength']
        if len(heights) != 2 or not all(math.isfinite(h) and 0 < h <= 1 for h in heights) or heights[0] > heights[1] or not math.isfinite(wavelength) or not 0.1 <= wavelength <= 4:
            raise ValueError('Invalid custom wave dimensions')
        tile = max(4.0, 12*scale)
        # MJLab adds two half-amplitude sinusoids: total peak-to-trough = 2*amplitude.
        choices['waves'] = presets.wave_terrain(amplitude_range=tuple(h/2 for h in heights),
            num_waves=max(1, round(tile/wavelength)), horizontal_scale=min(.02, wavelength/20),
            vertical_scale=min(.00025, heights[0]/16))
        pattern = waves.get('pattern', 'cross')
        if pattern not in ('cross', 'alternating') or waves.get('forwardAxis', 'y') not in ('x', 'y'):
            raise ValueError('Invalid wave pattern or forward axis')
        if pattern == 'alternating':
            lateral = waves.get('lateralWavelength', 0)
            if not math.isfinite(lateral) or not .1 <= lateral <= 4:
                raise ValueError('Alternating waves require a lateral wavelength in [0.1, 4] m')
            configure_alternating_wave_collision_capacity()
            choices['waves'] = AlternatingWaveCfg(height_range=tuple(heights), wavelength=wavelength,
                lateral_wavelength=lateral, forward_axis=waves.get('forwardAxis', 'y'))
    if legacy and preset == 'mixed':
        generator = replace(presets.ROUGH_TERRAINS_CFG, curriculum=curriculum, seed=seed)
    else:
        selected = ({'flat': presets.flat(proportion=0.2), **{
            key: replace(choices[key], proportion=0.8/6) for key in
            ('rough', 'stairs_up', 'stairs_down', 'slope_up', 'slope_down', 'obstacles')}}
            if preset == 'mixed' else {preset: choices[preset]})
        if preset == 'waves' and waves is not None:
            flat_fraction = waves.get('flatFraction', 0)
            if not math.isfinite(flat_fraction) or not 0 <= flat_fraction < 1:
                raise ValueError('Flat fraction must be in [0, 1)')
            if flat_fraction > 0:
                selected = {'flat': presets.flat(proportion=flat_fraction),
                            'waves': replace(choices['waves'], proportion=1-flat_fraction)}
        # Fine millimeter heightfields are expensive on every physics step.
        # Independent vector worlds can share a few terrain variants; retain the
        # same wave geometry/resolution and use fewer duplicate tiles, unless a
        # row-based difficulty curriculum was explicitly requested.
        compact_waves = waves is not None and preset == 'waves' and not curriculum
        # Randomly selecting only four tiles does not preserve an explicit mix
        # (and can omit flat ground entirely). MJLab's column layout assigns
        # spawn counts by sub-terrain proportion. Two rows retain both wave
        # difficulty endpoints without enabling an episode-based curriculum.
        fixed_wave_mix = compact_waves and len(selected) > 1
        generator = TerrainGeneratorCfg(size=(max(4.0, 12*scale),)*2, border_width=4.0,
            num_rows=2 if fixed_wave_mix else (1 if compact_waves else 5),
            num_cols=4 if compact_waves else max(8, len(selected)), sub_terrains=selected,
            curriculum=curriculum or fixed_wave_mix, seed=seed, add_lights=True)
    terrain.terrain_type = 'generator'
    terrain.terrain_generator = generator
    if not legacy:
        terrain.max_init_terrain_level = None if fixed_wave_mix else 0
    if preview:
        compact_preview_terrain(cfg, seed)


def compact_preview_terrain(cfg, seed=42):
    terrain = cfg.scene.terrain
    generator = terrain.terrain_generator if terrain else None
    if generator is not None:
        # One column per type ensures mixed preview really contains every type.
        terrain.terrain_generator = replace(generator, seed=seed, num_rows=1,
            num_cols=len(generator.sub_terrains), curriculum=True,
            difficulty_range=(0.5, 0.5), border_width=4.0)
        terrain.max_init_terrain_level = 0
    cfg.curriculum.pop('terrain_levels', None)


def _ground_query(env, points):
    """Vertical rays at current world coordinates; only the terrain entity.

    This measures vertical clearance at each query point, not Euclidean distance
    to an entire sole. No observation channels or physical parameters are added.
    """
    if not torch.isfinite(points).all():
        raise ValueError('nonfinite terrain query coordinates; refusing to treat invalid physics as terrain bounds')
    model = env.sim.mj_model
    cache = getattr(env, '_simready_ground_queries', None)
    if cache is None:
        data = mujoco.MjData(model)
        mujoco.mj_forward(model, data)
        terrain_body = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, 'terrain')
        def belongs_to_terrain(body):
            while body > 0:
                if body == terrain_body:
                    return True
                body = int(model.body_parentid[body])
            return False
        mask = np.array([belongs_to_terrain(int(body)) for body in model.geom_bodyid])
        mask &= (model.geom_contype != 0) | (model.geom_conaffinity != 0)
        ids = np.flatnonzero(mask)
        if not len(ids):
            raise ValueError('terrain_reward_incompatible: no collision terrain entity')
        planes = ids[model.geom_type[ids] == mujoco.mjtGeom.mjGEOM_PLANE]
        flat = (len(ids) == 1 and len(planes) == 1 and
                np.allclose(data.geom_xmat[ids[0]].reshape(3, 3)[:, 2], [0, 0, 1]))
        top = float(np.max(data.geom_xpos[ids, 2] + model.geom_rbound[ids])) + 1.0
        # A shallow query-only model shares immutable physics arrays, with its own
        # ray visibility mask. Imported robots may also use group 0: never change
        # their collision, inertia, render groups or the live simulation model.
        query_model = copy(env.sim.wp_model)
        query_model.geom_group = wp.array(np.where(mask, 0, 1).astype(np.int32), device=str(points.device))
        bounds = None
        if not len(planes):
            rotations = data.geom_xmat[ids].reshape(-1, 3, 3)
            centers = data.geom_xpos[ids] + np.einsum('nij,nj->ni', rotations, model.geom_aabb[ids, :3])
            extents = np.einsum('nij,nj->ni', np.abs(rotations), model.geom_aabb[ids, 3:])
            bounds = torch.as_tensor(np.stack(((centers-extents).min(0), (centers+extents).max(0))), device=points.device, dtype=points.dtype)
        cache = {'flat': float(data.geom_xpos[ids[0], 2]) if flat else None,
                 'top': top, 'buffers': {}, 'model': query_model, 'bounds': bounds}
        env._simready_ground_queries = cache
    if cache['flat'] is not None:
        return torch.full_like(points[..., 2], cache['flat']), torch.ones_like(points[..., 2], dtype=torch.bool)
    shape = tuple(points.shape[:2])
    buffers = cache['buffers'].get(shape)
    if buffers is None:
        device = str(points.device)
        origins = torch.zeros_like(points)
        directions = torch.zeros_like(points); directions[..., 2] = -1
        buffers = (origins, directions, wp.zeros(shape, dtype=float, device=device),
                   wp.zeros(shape, dtype=int, device=device), wp.zeros(shape, dtype=wp.vec3, device=device),
                   wp.array([-1]*shape[1], dtype=int, device=device))
        cache['buffers'][shape] = buffers
    origins, directions, distances, geomids, normals, excludes = buffers
    origins.copy_(points); origins[..., 2] = cache['top']
    context = getattr(env.sim, '_sensor_context', None)
    with wp.ScopedDevice(str(points.device)):
        mjwarp.rays(cache['model'], env.sim.wp_data,
            wp.from_torch(origins, dtype=wp.vec3), wp.from_torch(directions, dtype=wp.vec3),
            wp.types.vector(length=6, dtype=float)(-1, 0, 0, 0, 0, 0), True,
            excludes, distances, geomids, normals,
            rc=context.render_context if context is not None else None)
    distances_t = wp.to_torch(distances)
    if not torch.isfinite(distances_t).all():
        raise ValueError('nonfinite terrain ray distances; refusing to mask invalid simulation results')
    valid = distances_t >= 0
    # Zero is only a masked storage value, never a synthetic collision surface.
    return torch.where(valid, origins[..., 2] - distances_t, 0.), valid


def ground_height(env, points, *, return_valid=False):
    height, valid = _ground_query(env, points[:, None, :])
    height, valid = height[:, 0], valid[:, 0]
    if return_valid:
        return height, valid
    if not valid.all():
        raise ValueError('terrain_reward_incompatible: clearance query left the collision terrain; reset the environment')
    return height


def validate_terrain_queries(env, env_ids=None):
    # Configuration errors must still fail before training. No fallback plane.
    points = env.scene['robot'].data.root_link_pos_w
    if _outside_terrain(env, points).any():
        raise ValueError('terrain_reward_incompatible: initial pose lies outside collision terrain')


def _outside_terrain(env, points):
    ground_height(env, points, return_valid=True)
    bounds = env._simready_ground_queries['bounds']
    if bounds is None:
        return torch.zeros(points.shape[0], dtype=torch.bool, device=points.device)
    # Holes between stepping stones are not the map boundary. Missing local
    # clearance is masked by rewards; it must not reset a robot mid-jump.
    return ((points[:, :2] < bounds[0, :2]) | (points[:, :2] > bounds[1, :2])).any(-1)


def validate_reset_terrain(env, env_ids=None):
    robot = env.scene['robot']
    # Reset events write qpos before forward kinematics. Read the newly authored
    # free-root position, not the previous episode's cached xpos. Terrain is static.
    if robot.is_fixed_base:
        points = robot.data.root_link_pos_w
    else:
        points = env.sim.data.qpos[:, robot.indexing.free_joint_q_adr][:, :3]
    outside = _outside_terrain(env, points)
    if outside[slice(None) if env_ids is None else env_ids].any():
        raise ValueError('terrain_reward_incompatible: reset pose lies outside collision terrain; check initial pose and reset ranges')


def terrain_out_of_bounds(env):
    return _outside_terrain(env, env.scene['robot'].data.root_link_pos_w)


def configure_terrain_boundary(cfg):
    from mjlab.managers.event_manager import EventTermCfg
    from mjlab.managers.termination_manager import TerminationTermCfg
    cfg.events['terrain_query_preflight'] = EventTermCfg(func=validate_terrain_queries, mode='startup')
    cfg.events['terrain_reset_preflight'] = EventTermCfg(func=validate_reset_terrain, mode='reset')
    # Always evaluated, even if users disable fall/height termination or replay
    # on another terrain. Other configured termination conditions stay intact.
    cfg.terminations['terrain_query_out_of_bounds'] = TerminationTermCfg(func=terrain_out_of_bounds)


def root_clearance(env, asset, *, return_valid=False):
    point = asset.data.root_link_pos_w
    height, valid = ground_height(env, point, return_valid=True)
    clearance = torch.where(valid, point[:, 2] - height, 0.)
    if return_valid:
        return clearance, valid
    return clearance
