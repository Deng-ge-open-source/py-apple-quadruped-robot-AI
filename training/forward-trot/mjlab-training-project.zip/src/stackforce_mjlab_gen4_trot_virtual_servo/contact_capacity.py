"""Size contact sensor matching buffers for the assembled rigid-body scene."""
import math
from functools import partial

import mujoco
import numpy as np


def _geoms_for_object(model, kind, object_id):
    if kind == mujoco.mjtObj.mjOBJ_GEOM:
        return np.array([object_id], dtype=int)
    if kind == mujoco.mjtObj.mjOBJ_BODY:
        return np.flatnonzero(model.geom_bodyid == object_id)
    if kind == mujoco.mjtObj.mjOBJ_XBODY:
        bodies = np.zeros(model.nbody, dtype=bool)
        bodies[object_id] = True
        for body in range(object_id + 1, model.nbody):
            bodies[body] = bodies[int(model.body_parentid[body])]
        return np.flatnonzero(bodies[model.geom_bodyid])
    # An unspecified endpoint matches any geom. Site sensors additionally filter
    # by position; considering all geoms safely bounds every possible pose.
    return np.arange(model.ngeom)


def _pair_contact_limits(model, geom, others):
    # MuJoCo Warp 3.11 rigid colliders emit at most 8 contacts per pair (native
    # box-box). Plane colliders have tighter bounds, including 4 for meshes.
    limits = np.full(len(others), 8, dtype=int)
    first_type = int(model.geom_type[geom])
    second_types = model.geom_type[others]
    plane = int(mujoco.mjtGeom.mjGEOM_PLANE)
    if first_type == plane:
        other_types = second_types
        plane_pairs = np.ones(len(others), dtype=bool)
    else:
        other_types = np.full(len(others), first_type)
        plane_pairs = second_types == plane
    for kind, limit in (
        (mujoco.mjtGeom.mjGEOM_PLANE, 0),
        (mujoco.mjtGeom.mjGEOM_SPHERE, 1),
        (mujoco.mjtGeom.mjGEOM_CAPSULE, 2),
        (mujoco.mjtGeom.mjGEOM_ELLIPSOID, 1),
        (mujoco.mjtGeom.mjGEOM_CYLINDER, 3),
        (mujoco.mjtGeom.mjGEOM_BOX, 4),
        (mujoco.mjtGeom.mjGEOM_MESH, 4),
    ):
        limits[plane_pairs & (other_types == int(kind))] = limit
    sdf = int(mujoco.mjtGeom.mjGEOM_SDF)
    limits[(first_type == sdf) | (second_types == sdf)] = max(
        int(mujoco.mjMAXCONPAIR), int(model.opt.sdf_initpoints)
    )
    return limits


def contact_match_bound(model):
    """Conservative per-sensor bound across poses, independent of env count."""
    bounds = {}
    explicit = {}
    for first, second in zip(model.pair_geom1, model.pair_geom2):
        explicit.setdefault(int(first), set()).add(int(second))
        explicit.setdefault(int(second), set()).add(int(first))
    for sensor in np.flatnonzero(model.sensor_type == mujoco.mjtSensor.mjSENS_CONTACT):
        signature = (
            int(model.sensor_objtype[sensor]), int(model.sensor_objid[sensor]),
            int(model.sensor_reftype[sensor]), int(model.sensor_refid[sensor]),
        )
        if signature in bounds:
            continue  # found/force/etc. share the same matching criteria.
        primary = _geoms_for_object(model, *signature[:2])
        secondary = _geoms_for_object(model, *signature[2:])
        primary_mask = np.zeros(model.ngeom, dtype=bool)
        secondary_mask = np.zeros(model.ngeom, dtype=bool)
        primary_mask[primary] = True
        secondary_mask[secondary] = True
        bound = 0
        for first in primary:
            # Count unordered pairs once when the endpoint sets overlap.
            unique = (secondary != first) & ~(
                secondary_mask[first] & primary_mask[secondary] & (secondary < first)
            )
            others = secondary[unique]
            allowed = (
                (model.geom_contype[first] & model.geom_conaffinity[others])
                | (model.geom_contype[others] & model.geom_conaffinity[first])
            ) != 0
            first_body = int(model.geom_bodyid[first])
            other_bodies = model.geom_bodyid[others]
            first_weld = int(model.body_weldid[first_body])
            other_welds = model.body_weldid[other_bodies]
            allowed &= first_weld != other_welds
            if not (model.opt.disableflags & mujoco.mjtDisableBit.mjDSBL_FILTERPARENT):
                parent = int(model.body_weldid[model.body_parentid[first_weld]])
                other_parents = model.body_weldid[model.body_parentid[other_welds]]
                allowed &= ~((first_weld != 0) & (other_welds != 0) & (
                    (first_weld == other_parents) | (other_welds == parent)
                ))
            signatures = (np.minimum(first_body, other_bodies) << 16) + np.maximum(first_body, other_bodies)
            allowed &= ~np.isin(signatures, model.exclude_signature)
            # Explicit pairs override masks, weld/parent filters and exclusions
            # in Warp's broadphase, so apply them after the default filtering.
            if int(first) in explicit:
                allowed |= np.isin(others, list(explicit[int(first)]))
            bound += int(_pair_contact_limits(model, first, others[allowed]).sum())
        bounds[signature] = bound
    return max(bounds.values(), default=0)


def _size_contacts(sim_cfg, previous, spec):
    if previous is not None:
        previous(spec)
    if not any(s.type == mujoco.mjtSensor.mjSENS_CONTACT for s in spec.sensors):
        return
    model = spec.compile()
    sim_cfg.mujoco.apply(model)
    bound = contact_match_bound(model)
    # nconmax is a scene-wide allocation, not a per-sensor minimum. Multiplying
    # that requirement into every sensor can overflow CUDA sort shared memory.
    minimum = max(64, int(sim_cfg.contact_sensor_maxmatch))
    # Preserve native XML minimums, which MJLab's SimulationCfg otherwise
    # replaces when it applies Warp options.
    numeric = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_NUMERIC, "contact_sensor_maxmatch")
    if numeric >= 0:
        minimum = max(minimum, int(model.numeric_data[model.numeric_adr[numeric]]))
    required = max(minimum, math.ceil(bound * 1.25))
    capacity = 1 << (required - 1).bit_length()
    sim_cfg.contact_sensor_maxmatch = capacity
    print(
        f"[contact-capacity] auto contact_sensor_maxmatch={capacity} "
        f"(per-sensor bound={bound}, configured minimum={minimum})"
    )


def configure_contact_capacity(cfg):
    """Chain the scene callback; resolve capacity before GPU data/graph creation.

    Existing configured values are minimums. The geometry bound plus 25% spare
    capacity covers later falls and reset poses, without resizing during a step.
    """
    # Exported tasks work outside the desktop Runner as well.
    from .contact_sort import install_contact_sort
    install_contact_sort()
    from .contact_memory import install_contact_memory_guard
    install_contact_memory_guard()
    # MJLab deep-copies registered configs. A closure would keep updating the
    # original sim config; partial arguments follow deepcopy's shared references.
    cfg.scene.spec_fn = partial(_size_contacts, cfg.sim, cfg.scene.spec_fn)
