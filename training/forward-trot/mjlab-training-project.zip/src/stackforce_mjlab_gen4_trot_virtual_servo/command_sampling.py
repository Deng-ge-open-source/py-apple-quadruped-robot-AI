from dataclasses import dataclass, fields
import math
import torch
from mjlab.tasks.velocity.mdp import UniformVelocityCommand, UniformVelocityCommandCfg

def axis_aligned_commands(commands, ranges, ratio, excluded, boundary_ratio=0., interior_ratio=0., interior_fraction=2./3., axis_weights=None):
  if not 0 <= ratio <= 1:
    raise ValueError("Axis-aligned command ratio must be in [0, 1]")
  if not 0 <= boundary_ratio <= 1:
    raise ValueError("Axis-boundary command ratio must be in [0, 1]")
  if not 0 <= interior_ratio <= 1:
    raise ValueError("Interior command ratio must be in [0, 1]")
  if not 0 < interior_fraction < 1:
    raise ValueError("Interior command fraction must be in (0, 1)")
  if interior_ratio > 0 and (ratio <= 0 or boundary_ratio >= 1):
    raise ValueError("Interior commands require axis coverage and non-boundary samples")
  if axis_weights is not None:
    if not isinstance(axis_weights, (tuple, list)) or len(axis_weights) != 3 or any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0 for v in axis_weights):
      raise ValueError("Axis weights must contain three finite positive numbers")
  result = commands.clone()
  axes = [i for i in range(3) if ranges[i] != (0., 0.) and
          all(low <= 0 <= high for j, (low, high) in enumerate(ranges) if j != i)]
  if not axes:
    return result
  selected = (torch.rand(len(commands), device=commands.device) < ratio) & ~excluded
  ids = selected.nonzero(as_tuple=False).flatten()
  if axis_weights is None:
    axis = torch.tensor(axes, device=commands.device)[torch.randint(len(axes), (len(ids),), device=commands.device)]
  else:
    # Only the opt-in course changes axis exposure; keep every enabled axis.
    weights = commands.new_tensor([axis_weights[i] for i in axes])
    chosen = torch.multinomial(weights / weights.sum(), len(ids), replacement=True) if len(ids) else torch.empty(0, device=commands.device, dtype=torch.long)
    axis = torch.tensor(axes, device=commands.device)[chosen]
  values = result[ids, axis].clone()
  boundary = torch.zeros_like(values, dtype=torch.bool)
  if boundary_ratio > 0:
    boundary = torch.rand(len(ids), device=commands.device) < boundary_ratio
    sides = torch.randint(2, (len(ids),), device=commands.device)
    limits = commands.new_tensor(ranges)[axis, sides]
    values = torch.where(boundary, limits, values)
  if interior_ratio > 0:
    # Conditional on non-boundary axis samples. Keep explicit boundary mass,
    # mixed commands, exclusions and continuous full-range coverage intact.
    interior = (torch.rand(len(ids), device=commands.device) < interior_ratio) & ~boundary
    sides = torch.randint(2, (len(ids),), device=commands.device)
    bounds = commands.new_tensor(ranges)[axis]
    low, high = bounds.unbind(-1)
    crossing_zero = (low <= 0) & (high >= 0)
    signed = torch.where(sides == 0, low, high) * interior_fraction
    alpha = torch.where(sides == 0, 1.-interior_fraction, interior_fraction)
    one_sided = low + (high-low)*alpha
    anchor = torch.where(crossing_zero, signed, one_sided)
    values = torch.where(interior, anchor, values)
  result[ids] = 0
  result[ids, axis] = values
  return result


class AxisAlignedVelocityCommand(UniformVelocityCommand):
  def _resample_command(self, env_ids):
    super()._resample_command(env_ids)
    excluded = self.is_standing_env[env_ids] | self.is_forward_env[env_ids] | self.is_world_env[env_ids]
    if self.cfg.heading_command:
      excluded |= self.is_heading_env[env_ids]
    ranges = (self.cfg.ranges.lin_vel_x, self.cfg.ranges.lin_vel_y, self.cfg.ranges.ang_vel_z)
    self.vel_command_b[env_ids] = axis_aligned_commands(
      self.vel_command_b[env_ids], ranges, self.cfg.axis_aligned_env_ratio, excluded,
      self.cfg.axis_boundary_env_ratio, self.cfg.axis_interior_env_ratio,
      self.cfg.axis_interior_fraction, self.cfg.axis_weights)


@dataclass(kw_only=True)
class AxisAlignedVelocityCommandCfg(UniformVelocityCommandCfg):
  axis_aligned_env_ratio: float = 0.
  axis_boundary_env_ratio: float = 0.
  axis_interior_env_ratio: float = 0.
  axis_interior_fraction: float = 2./3.
  axis_weights: tuple[float, float, float] | None = None

  def build(self, env):
    return AxisAlignedVelocityCommand(self, env)


def with_axis_aligned_sampling(cfg, ratio, axis_boundary_ratio=0., axis_interior_ratio=0., axis_interior_fraction=2./3., axis_weights=None):
  if not isinstance(cfg, UniformVelocityCommandCfg):
    raise TypeError("Axis coverage requires a uniform velocity command")
  values = {field.name: getattr(cfg, field.name) for field in fields(cfg) if field.init}
  values.update(axis_aligned_env_ratio=ratio, axis_boundary_env_ratio=axis_boundary_ratio,
                axis_interior_env_ratio=axis_interior_ratio, axis_interior_fraction=axis_interior_fraction, axis_weights=axis_weights)
  return AxisAlignedVelocityCommandCfg(**values)
