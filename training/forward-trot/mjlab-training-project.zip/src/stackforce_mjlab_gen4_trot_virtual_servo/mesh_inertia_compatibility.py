"""Compatibility for unused volume inertia of tiny CAD meshes.

Only an actual MuJoCo volume failure can trigger this path. Mesh vertices,
collisions, actuators and constraints are retained. All users of the mesh must
have explicit body inertia which the compiler will preserve. The source spec
is never mutated, including when a later compile attempt fails.
"""
import math
import re
import time
import mujoco

POLICY_VERSION = 2
# Each mesh can be repaired only once. Large CAD assemblies routinely contain
# more than 32 eligible surfaces; bound work by model size as well as time.
MAX_REPAIRS = 4096
MAX_REPAIR_SECONDS = 180
VOLUME_ERROR = re.compile(r'^Error: mesh volume is too small: (.+) \. Try setting inertia to shell\s*$', re.M)


def _eligible(spec, mesh):
    if mesh.inertia != mujoco.mjtMeshInertia.mjMESH_INERTIA_LEGACY:
        return False, '模型已明确指定非默认网格惯性算法'
    users = [geom for geom in spec.geoms if geom.meshname == mesh.name]
    if not users:
        return False, '无法确定此网格的使用部件'
    for geom in users:
        if geom.type != mujoco.mjtGeom.mjGEOM_MESH:
            return False, '此网格用于拟合碰撞体，自动修改可能改变碰撞形状'
        body = geom.parent
        if (not getattr(body, 'explicitinertial', False) or
                not math.isfinite(body.mass) or body.mass <= 0):
            return False, '引用此网格的部件没有有效的显式质量和惯性'
        # A true compiler setting overrides even an authored <inertial>.
        compilers = (spec.compiler, getattr(body, 'compiler', spec.compiler))
        if any(c.inertiafromgeom not in (mujoco.mjtInertiaFromGeom.mjINERTIAFROMGEOM_AUTO,
                                        mujoco.mjtInertiaFromGeom.mjINERTIAFROMGEOM_FALSE)
               for c in compilers):
            return False, '模型要求从几何体重新计算连杆惯性'
        if geom.fluid_ellipsoid:
            return False, '此网格参与流体形状计算'
    return True, len(users)


def prepare_mesh_inertia(spec):
    """Return the exact spec to use for preflight, training and native replay.

    The package (source + assets + this policy) is covered by the existing
    preflight fingerprint. This function writes no files and caches no results.
    A fresh process/config always re-evaluates the same authored model.
    """
    report = {'schema': POLICY_VERSION, 'repairs': []}
    if not spec.meshes:
        return spec, report
    candidate = spec.copy()
    first_error = None
    limit = min(len(candidate.meshes), MAX_REPAIRS)
    started = time.monotonic()
    repaired = set()
    for attempt in range(limit + 1):
        if attempt and time.monotonic() - started >= MAX_REPAIR_SECONDS:
            raise ValueError('微小网格兼容达到处理时间上限：已处理 ' + str(attempt) +
                             ' 个，模型共 ' + str(len(candidate.meshes)) +
                             ' 个网格。原始模型保持不变，训练未启动。首次编译错误：' + str(first_error))
        try:
            candidate.compile()
        except ValueError as error:
            first_error = first_error or str(error)
            match = VOLUME_ERROR.search(str(error))
            if not match:
                if report['repairs']:
                    error.add_note('微小网格兼容后仍无法编译；训练未启动。首次编译错误：' + first_error)
                raise
            matches = [(i, mesh) for i, mesh in enumerate(candidate.meshes) if mesh.name == match[1]]
            if len(matches) != 1:
                raise
            index, mesh = matches[0]
            eligible, detail = _eligible(candidate, mesh)
            if not eligible or attempt == limit or index in repaired:
                reason = detail if not eligible else ('超过单次自动兼容数量上限（已处理 ' +
                    str(attempt) + '，上限 ' + str(limit) + '，模型网格 ' + str(len(candidate.meshes)) + '）')
                raise ValueError('微小网格不能自动兼容：' + str(reason) +
                                 '。请在 CAD 工具中修正面片或明确配置部件惯性；未自动改变模型物理参数。') from error
            mesh.inertia = mujoco.mjtMeshInertia.mjMESH_INERTIA_SHELL
            repaired.add(index)
            report['repairs'].append({'meshIndex': index, 'reason': 'mesh_volume_too_small',
                                      'from': 'legacy', 'to': 'shell', 'geomUses': detail})
        else:
            if report['repairs']:
                print(f"[SimReady] 已自动兼容 {len(report['repairs'])} 个微小网格：保留显式连杆质量、惯性和原有碰撞形状；继续本机物理检查。", flush=True)
                return candidate, report
            return spec, report
    raise AssertionError('Unreachable mesh compatibility state')
