# Copyright 2025 The Newton Developers
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
# SimReady modification: signed top-surface witness recovery. Only the
# heightfield CCD entry point is installed; other collision kernels retain
# their upstream implementation. No physical parameters or contacts are removed.
# Source: mujoco-warp 3.11.0, collision_gjk.py (Apache-2.0).
from typing import Tuple
from pathlib import Path
import hashlib
import importlib.metadata
import warp as wp
from mujoco_warp._src import collision_gjk, collision_convex
from mujoco_warp._src.collision_gjk import (
    FLOAT_MAX,
    GJKResult,
    Geom,
    GeomType,
    MIN_EPATOL,
    OverflowType,
    Polytope,
    _add_edge,
    _attach_face,
    _delete_face,
    _discrete_geoms,
    _epa_support,
    _get_edge,
    _get_face_verts,
    _invalidate_face,
    _is_face_deleted,
    _is_invalid_face,
    _polytope2,
    _polytope3,
    _polytope4,
    _tri_affine_coord,
    gjk,
)
wp.set_module_options({"enable_backward": False})

@wp.func
def _epa_witness(
  pt: Polytope, geom1: Geom, geom2: Geom, geomtype1: int, geomtype2: int, face_idx: int
) -> Tuple[wp.vec3, wp.vec3, float]:
  face = _get_face_verts(pt.face[face_idx])
  # compute affine coordinates for witness points on plane defined by face
  v1 = pt.vert[2 * face[0]] - pt.vert[2 * face[0] + 1]
  v2 = pt.vert[2 * face[1]] - pt.vert[2 * face[1] + 1]
  v3 = pt.vert[2 * face[2]] - pt.vert[2 * face[2] + 1]

  coordinates = _tri_affine_coord(v1, v2, v3, pt.face_pr[face_idx])
  l1 = coordinates[0]
  l2 = coordinates[1]
  l3 = coordinates[2]

  # face on geom 2
  v1 = pt.vert[2 * face[0] + 1]
  v2 = pt.vert[2 * face[1] + 1]
  v3 = pt.vert[2 * face[2] + 1]
  x2 = wp.vec3()
  x2[0] = v1[0] * l1 + v2[0] * l2 + v3[0] * l3
  x2[1] = v1[1] * l1 + v2[1] * l2 + v3[1] * l3
  x2[2] = v1[2] * l1 + v2[2] * l2 + v3[2] * l3

  # correct witness points for hfield geoms
  i1 = pt.vert_index[2 * face[0]]
  i2 = pt.vert_index[2 * face[1]]
  i3 = pt.vert_index[2 * face[2]]
  if geomtype1 == GeomType.HFIELD and (i1 != i2 or i1 != i3):
    # Use the existing object witness; a point coordinate is not a support direction.
    a, b, c = geom1.hfprism[3], geom1.hfprism[4], geom1.hfprism[5]
    n = wp.normalize(wp.cross(b-a,c-a))
    n = wp.where(n[2] < 0.0, -n, n)
    signed_distance = wp.dot(x2-a,n)
    x1 = x2-signed_distance*n
    return x1, x2, signed_distance

  # face on geom 1
  v1 = pt.vert[2 * face[0]]
  v2 = pt.vert[2 * face[1]]
  v3 = pt.vert[2 * face[2]]
  x1 = wp.vec3()
  x1[0] = v1[0] * l1 + v2[0] * l2 + v3[0] * l3
  x1[1] = v1[1] * l1 + v2[1] * l2 + v3[1] * l3
  x1[2] = v1[2] * l1 + v2[2] * l2 + v3[2] * l3

  return x1, x2, -wp.sqrt(pt.face_norm2[face_idx])


@wp.func
def _epa(
  # In:
  tolerance: float,
  epa_iterations: int,
  pt: Polytope,
  geom1: Geom,
  geom2: Geom,
  geomtype1: int,
  geomtype2: int,
  is_discrete: bool,
  warn_overflow: bool,
  worldid: int,
  # Data out:
  overflow_out: wp.array[int],
) -> Tuple[float, wp.vec3, wp.vec3, int]:
  """Recover penetration data from two geoms in contact given an initial polytope."""
  upper = FLOAT_MAX
  upper2 = FLOAT_MAX
  idx = int(-1)
  pidx = int(-1)
  epsilon = wp.where(is_discrete, MIN_EPATOL, tolerance)
  nvalid = pt.nface  # number of potential faces for expanding the polytope

  # the face vertices are encoded in 10-bits that index the vertex array,
  # so iterations must be cap to limit the number of generated vertices
  # (one new vertex per iteration)
  epa_iterations = wp.min(epa_iterations, 1000)
  for _ in range(epa_iterations):
    pidx = idx
    idx = int(-1)
    lower2 = float(FLOAT_MAX)

    # find the face closest to the origin (lower bound for penetration depth)
    for i in range(pt.nface):
      if not _is_invalid_face(pt.face[i]) and pt.face_norm2[i] < lower2:
        idx = i
        lower2 = pt.face_norm2[i]

    # face not valid, return previous face
    if lower2 > upper2 or idx < 0:
      idx = pidx
      break

    # check if lower bound is 0
    if lower2 <= 0.0:
      break

    # compute support point w from the closest face's normal
    lower = wp.sqrt(lower2)
    wi = pt.nvert
    face_pr = pt.face_pr[idx]
    i1, i2 = _epa_support(pt, wi, geom1, geom2, geomtype1, geomtype2, face_pr / lower)
    w = pt.vert[2 * wi] - pt.vert[2 * wi + 1]
    geom1.index = i1
    geom2.index = i2
    pt.nvert += 1

    # upper bound for kth iteration (dot product before normalizing for better precision)
    upper_k = wp.dot(face_pr, w) / lower
    if upper_k < upper:
      upper = upper_k
      upper2 = upper * upper

    if upper - lower < epsilon:
      break

    # check if vertex wi is a repeated support point
    if is_discrete:
      found_repeated = bool(False)
      for i in range(pt.nvert - 1):
        if pt.vert_index[2 * i] == pt.vert_index[2 * wi] and pt.vert_index[2 * i + 1] == pt.vert_index[2 * wi + 1]:
          found_repeated = True
          break
      if found_repeated:
        break

    nvalid -= 1
    pt.face[idx] = _delete_face(pt.face[idx])
    face = _get_face_verts(pt.face[idx])
    pt.nhorizon = _add_edge(pt, face[0], face[1])
    pt.nhorizon = _add_edge(pt, face[1], face[2])
    pt.nhorizon = _add_edge(pt, face[2], face[0])
    if pt.nhorizon == -1:
      if warn_overflow:
        wp.printf("Warning: EPA horizon = %d isn't large enough.\n", pt.horizon.shape[0])
      wp.atomic_or(overflow_out, worldid, OverflowType.EPA_HORIZON)
      idx = -1
      break

    # compute horizon for w
    for i in range(pt.nface):
      if _is_face_deleted(pt.face[i]):
        continue

      if wp.dot(pt.face_pr[i], w) - pt.face_norm2[i] > 1e-10:
        nvalid = wp.where(_is_invalid_face(pt.face[i]), nvalid, nvalid - 1)
        pt.face[i] = _delete_face(pt.face[i])
        face = _get_face_verts(pt.face[i])
        pt.nhorizon = _add_edge(pt, face[0], face[1])
        pt.nhorizon = _add_edge(pt, face[1], face[2])
        pt.nhorizon = _add_edge(pt, face[2], face[0])
        if pt.nhorizon == -1:
          if warn_overflow:
            wp.printf("Warning: EPA horizon = %d isn't large enough.\n", pt.horizon.shape[0])
          wp.atomic_or(overflow_out, worldid, OverflowType.EPA_HORIZON)
          idx = -1
          break

    # insert w as new vertex and attach faces along the horizon
    for i in range(pt.nhorizon):
      edge = _get_edge(pt.horizon[i])
      dist2 = _attach_face(pt, pt.nface, wi, edge[0], edge[1])
      if dist2 == 0.0:
        idx = -1
        break

      pt.nface += 1

      if dist2 >= lower2 and dist2 <= upper2:
        nvalid += 1
      else:
        pt.face[pt.nface - 1] = _invalidate_face(pt.face[pt.nface - 1])

    # no face candidates left
    if nvalid == 0 or idx == -1:
      break

    # clear horizon
    pt.nhorizon = 0

  # return from valid face
  if idx > -1:
    x1, x2, dist = _epa_witness(pt, geom1, geom2, geomtype1, geomtype2, idx)
    return dist, x1, x2, idx
  return 0.0, wp.vec3(), wp.vec3(), -1


@wp.func
def _inflate(
  result: GJKResult, geom1: Geom, geom2: Geom, geomtype1: int, geomtype2: int, margin1: float, margin2: float
) -> Tuple[float, wp.vec3, wp.vec3]:
  dist = result.dist
  x1 = result.x1
  x2 = result.x2

  if geomtype1 == GeomType.HFIELD:
    v = result.simplex_index1[0]
    is_side = bool(False)
    for i in range(result.dim):
      if result.simplex_index1[i] != v:
        is_side = True
        break

    if is_side:
      a, b, c = geom1.hfprism[3], geom1.hfprism[4], geom1.hfprism[5]
      n = wp.normalize(wp.cross(b-a,c-a))
      n = wp.where(n[2] < 0.0, -n, n)
      x2 = x2-margin2*n
      signed_distance = wp.dot(x2-a,n)
      x1 = x2-signed_distance*n
      return signed_distance, x1, x2

  n = wp.normalize(x2 - x1)
  if margin1 > 0.0:
    x1 += margin1 * n

  if margin2 > 0.0:
    x2 -= margin2 * n
  dist -= margin1 + margin2
  return dist, x1, x2


@wp.func
def gjk_phase(
  # In:
  tolerance: float,
  cutoff: float,
  gjk_iterations: int,
  geom1: Geom,
  geom2: Geom,
  geomtype1: int,
  geomtype2: int,
  x_1: wp.vec3,
  x_2: wp.vec3,
) -> Tuple[bool, float, int, wp.vec3, wp.vec3, GJKResult, Geom, Geom]:
  """Run GJK phase of CCD."""
  full_margin1 = 0.0
  full_margin2 = 0.0
  size1 = 0.0
  size2 = 0.0
  empty = GJKResult()

  # determine if the geoms being tested are discrete
  is_discrete = _discrete_geoms(geomtype1, geomtype2) and (geom1.margin == 0.0 and geom2.margin == 0.0)

  # special handling for sphere and capsule (shrink to point and line respectively)
  if geomtype1 == GeomType.SPHERE or geomtype1 == GeomType.CAPSULE:
    size1 = geom1.size[0]
    full_margin1 = size1 + 0.5 * geom1.margin
    geom1.margin = 0.0
    geom1.size = wp.vec3(0.0, geom1.size[1], geom1.size[2])

  if geomtype2 == GeomType.SPHERE or geomtype2 == GeomType.CAPSULE:
    size2 = geom2.size[0]
    full_margin2 = size2 + 0.5 * geom2.margin
    geom2.margin = 0.0
    geom2.size = wp.vec3(0.0, geom2.size[1], geom2.size[2])

  if size1 + size2 > 0.0:
    cutoff += full_margin1 + full_margin2
    result = gjk(tolerance, gjk_iterations, geom1, geom2, x_1, x_2, geomtype1, geomtype2, cutoff, is_discrete)
    geom1.index = result.index1
    geom2.index = result.index2

    # shallow penetration, inflate contact
    if result.dist > tolerance:
      if result.dist == FLOAT_MAX:
        return False, result.dist, 1, result.x1, result.x2, empty, geom1, geom2
      dist, x1, x2 = _inflate(result, geom1, geom2, geomtype1, geomtype2, full_margin1, full_margin2)
      return False, dist, 1, x1, x2, empty, geom1, geom2

    # deep penetration: reset initial conditions and rerun GJK + EPA
    geom1.margin = full_margin1 - size1
    geom1.size = wp.vec3(size1, geom1.size[1], geom1.size[2])
    geom2.margin = full_margin2 - size2
    geom2.size = wp.vec3(size2, geom2.size[1], geom2.size[2])
    cutoff -= full_margin1 + full_margin2

  result = gjk(tolerance, gjk_iterations, geom1, geom2, x_1, x_2, geomtype1, geomtype2, cutoff, is_discrete)
  geom1.index = result.index1
  geom2.index = result.index2

  # no penetration depth to recover
  if result.dist > tolerance or result.dim < 2:
    return False, result.dist, 1, result.x1, result.x2, empty, geom1, geom2

  return True, result.dist, 1, result.x1, result.x2, result, geom1, geom2


@wp.func
def epa_phase(
  # In:
  tolerance: float,
  epa_iterations: int,
  result: GJKResult,
  geom1: Geom,
  geom2: Geom,
  geomtype1: int,
  geomtype2: int,
  vert: wp.array[wp.vec3],
  vert_index: wp.array[int],
  face: wp.array[int],
  face_pr: wp.array[wp.vec3],
  face_norm2: wp.array[float],
  horizon: wp.array[int],
  warn_overflow: bool,
  worldid: int,
  # Data out:
  overflow_out: wp.array[int],
) -> Tuple[float, int, wp.vec3, wp.vec3, int]:
  """Run EPA given GJK result. Returns (dist, ncontact, x1, x2, multiccd_idx)."""
  pt = Polytope()
  pt.nface = 0
  pt.nvert = 0
  pt.nhorizon = 0
  pt.vert = vert
  pt.vert_index = vert_index
  pt.face = face
  pt.face_pr = face_pr
  pt.face_norm2 = face_norm2
  pt.horizon = horizon

  if result.dim == 2:
    pt, new_result = _polytope2(
      pt,
      result.simplex,
      result.simplex1,
      result.simplex2,
      result.simplex_index1,
      result.simplex_index2,
      geom1,
      geom2,
      geomtype1,
      geomtype2,
    )
    if pt.status == -1:
      result.simplex = new_result.simplex
      result.simplex1 = new_result.simplex1
      result.simplex2 = new_result.simplex2
      result.simplex_index1 = new_result.simplex_index1
      result.simplex_index2 = new_result.simplex_index2
      result.dim = 3
  elif result.dim == 4:
    pt, new_result = _polytope4(
      pt,
      result.simplex,
      result.simplex1,
      result.simplex2,
      result.simplex_index1,
      result.simplex_index2,
    )
    if pt.status == -1:
      result.simplex = new_result.simplex
      result.simplex1 = new_result.simplex1
      result.simplex2 = new_result.simplex2
      result.simplex_index1 = new_result.simplex_index1
      result.simplex_index2 = new_result.simplex_index2
      result.dim = 3

  # polytope2 and polytope4 may need to fallback here
  if result.dim == 3:
    pt = _polytope3(
      pt,
      result.dist,
      result.simplex,
      result.simplex1,
      result.simplex2,
      result.simplex_index1,
      result.simplex_index2,
      geom1,
      geom2,
      geomtype1,
      geomtype2,
    )

  # origin on boundary (objects are not considered penetrating)
  if pt.status:
    return result.dist, 1, result.x1, result.x2, -1

  is_discrete = _discrete_geoms(geomtype1, geomtype2) and (geom1.margin == 0.0 and geom2.margin == 0.0)
  dist, x1, x2, idx = _epa(
    tolerance, epa_iterations, pt, geom1, geom2, geomtype1, geomtype2, is_discrete, warn_overflow, worldid, overflow_out
  )
  if idx == -1:
    return FLOAT_MAX, 0, wp.vec3(), wp.vec3(), -1

  # multicontact not supported for margin
  if geom1.margin != 0.0 or geom2.margin != 0.0:
    idx = -1

  # multicontact only supported for boxes and meshes
  if (geomtype1 != GeomType.BOX and geomtype1 != GeomType.MESH) or (geomtype2 != GeomType.BOX and geomtype2 != GeomType.MESH):
    idx = -1

  return dist, 1, x1, x2, idx


@wp.func
def ccd(
  # In:
  tolerance: float,
  cutoff: float,
  gjk_iterations: int,
  epa_iterations: int,
  geom1: Geom,
  geom2: Geom,
  geomtype1: int,
  geomtype2: int,
  x_1: wp.vec3,
  x_2: wp.vec3,
  vert: wp.array[wp.vec3],
  vert_index: wp.array[int],
  face: wp.array[int],
  face_pr: wp.array[wp.vec3],
  face_norm2: wp.array[float],
  horizon: wp.array[int],
  warn_overflow: bool,
  worldid: int,
  # Data out:
  overflow_out: wp.array[int],
) -> Tuple[float, int, wp.vec3, wp.vec3, int]:
  """General convex collision detection via GJK/EPA."""
  needs_epa, dist, ncontact, x1, x2, result, geom1, geom2 = gjk_phase(
    tolerance, cutoff, gjk_iterations, geom1, geom2, geomtype1, geomtype2, x_1, x_2
  )
  if not needs_epa:
    return dist, ncontact, x1, x2, -1
  return epa_phase(
    tolerance,
    epa_iterations,
    result,
    geom1,
    geom2,
    geomtype1,
    geomtype2,
    vert,
    vert_index,
    face,
    face_pr,
    face_norm2,
    horizon,
    warn_overflow,
    worldid,
    overflow_out,
  )


def install_heightfield_witness_fix():
    """Install before CUDA graph compilation; opt-in alternating-wave jobs only."""
    if getattr(collision_convex, '_simready_signed_hfield_witness', False):
        return False
    if importlib.metadata.version('mujoco-warp') != '3.11.0':
        raise RuntimeError('Heightfield witness correction requires verified mujoco-warp 3.11.0')
    expected = '82e719593331e6ef01c0cf04ec89254c0a4fc6d76ebcc64c6f604cd3a7899f56'
    if hashlib.sha256(Path(collision_gjk.__file__).read_bytes()).hexdigest() != expected:
        raise RuntimeError('Unrecognized heightfield collision source; revalidate before training')
    collision_convex.ccd = ccd
    collision_convex._simready_signed_hfield_witness = True
    return True
