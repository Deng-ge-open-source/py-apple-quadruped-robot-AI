"""Velocity telemetry adapter; does not change commands, observations or rewards."""
from dataclasses import dataclass, fields
import torch
from mjlab.tasks.velocity.mdp.velocity_command import UniformVelocityCommand, UniformVelocityCommandCfg


class RobotFrameVelocityCommand(UniformVelocityCommand):
    def _update_metrics(self):
        divisor = self.cfg.resampling_time_range[1] / self._env.step_dt
        actual = self.robot.data.root_link_lin_vel_b
        axis = self.cfg.metric_forward_axis_index
        logical = torch.stack((actual[:, axis] * self.cfg.metric_forward_axis_sign,
                               actual[:, 1 - axis]), dim=-1)
        self.metrics['error_vel_xy'] += torch.linalg.vector_norm(
            self.vel_command_b[:, :2] - logical, dim=-1) / divisor
        self.metrics['error_vel_yaw'] += torch.abs(
            self.vel_command_b[:, 2] - self.robot.data.root_link_ang_vel_b[:, 2]) / divisor


@dataclass(kw_only=True)
class RobotFrameVelocityCommandCfg(UniformVelocityCommandCfg):
    metric_forward_axis_index: int = 0
    metric_forward_axis_sign: float = 1.0

    def build(self, env):
        return RobotFrameVelocityCommand(self, env)


def configure_command_frame_metrics(cfg, forward_axis_index, forward_axis_sign):
    if forward_axis_index not in (0, 1) or forward_axis_sign not in (-1, 1):
        raise ValueError('Invalid command metric forward axis or sign')
    if forward_axis_index == 0 and forward_axis_sign == 1:
        return  # Preserve the default command implementation unchanged.
    command = cfg.commands['twist']
    if type(command) not in (UniformVelocityCommandCfg, RobotFrameVelocityCommandCfg):
        raise ValueError('Robot-frame metrics require a uniform velocity command')
    values = {field.name: getattr(command, field.name)
              for field in fields(UniformVelocityCommandCfg) if field.init}
    cfg.commands['twist'] = RobotFrameVelocityCommandCfg(
        **values, metric_forward_axis_index=forward_axis_index,
        metric_forward_axis_sign=forward_axis_sign)
