"""Generic GUI-owned, performance-gated velocity curriculum for MJLab 1.6."""
from copy import deepcopy
import torch

GAIT_TERMS = ('phase_foot_swing_direction', 'phase_foot_contact', 'phase_foot_clearance', 'air_time', 'foot_clearance', 'foot_swing_height')
SMOOTH_TERMS = ('body_ang_vel', 'angular_momentum', 'action_rate_l2', 'ground_contact_point_slip', 'foot_slip', 'soft_landing')


def failure_termination(env, per_event=False):
    # A physical failure on the timeout step is still a failure. Pure timeouts are not.
    value = env.termination_manager.terminated.float()
    if per_event and env.cfg.scale_rewards_by_dt:
        value = value / env.step_dt
    return value


def stage_command_mode(stage):
    # Older projects represented standing with a zero longitudinal range.
    # An explicit velocity mode keeps intentional lateral/turn-in-place tasks.
    return stage.get('commandMode', 'stand' if list(stage['linearX']) == [0, 0] else 'velocity')


def configure_stage_command(cfg, stage):
    if not hasattr(cfg, '_simready_base_velocity'):
        cfg._simready_base_velocity = deepcopy({
            name: getattr(cfg, name) for name in ('ranges', 'heading_command',
                'rel_heading_envs', 'rel_standing_envs', 'rel_world_envs', 'rel_forward_envs')
            if hasattr(cfg, name)})
    for name, value in cfg._simready_base_velocity.items():
        setattr(cfg, name, deepcopy(value))
    cfg.ranges.lin_vel_x = tuple(stage['linearX'])
    if stage_command_mode(stage) == 'stand':
        cfg.ranges.lin_vel_x = cfg.ranges.lin_vel_y = cfg.ranges.ang_vel_z = (0., 0.)
        cfg.heading_command = False
        cfg.rel_heading_envs = cfg.rel_world_envs = cfg.rel_forward_envs = 0.
        cfg.rel_standing_envs = 1.


def apply_stage_command(command, stage):
    configure_stage_command(command.cfg, stage)
    # Stage changes also affect live commands; waiting for the next resample
    # leaves stale targets in ongoing episodes. Such episodes are not evaluated.
    if hasattr(command, 'vel_command_b'):
        ids = torch.arange(command.vel_command_b.shape[0], device=command.vel_command_b.device)
        command.is_heading_env.fill_(False)
        command._resample_command(ids)
        command._update_command()


def apply_velocity_stage(env, settings, state):
    stage = settings['stages'][state['stage']]
    command = env.command_manager.get_term('twist')
    apply_stage_command(command, stage)
    env.reward_manager.get_term_cfg('track_linear_velocity').params['std'] = stage['trackingStd']
    for name, weight in state['base_weights'].items():
        scale = stage['gaitRewardScale'] if name in GAIT_TERMS else stage['smoothnessRewardScale'] if name in SMOOTH_TERMS else 1.0
        env.reward_manager.get_term_cfg(name).weight = weight * scale


def restore_preview_stage(env, settings, saved):
    """Follow the loaded checkpoint, without enabling training/evaluation in play."""
    if not settings or not settings.get('enabled', True):
        return None
    if not isinstance(saved, dict) or type(saved.get('stage')) is not int:
        raise ValueError('Checkpoint has no velocity curriculum stage; use independent playback or save a new checkpoint.')
    index = saved['stage']
    if not 0 <= index < len(settings['stages']):
        raise ValueError('Checkpoint velocity stage is outside the saved GUI curriculum')
    stage = settings['stages'][index]
    if 'evaluations' not in saved:
        # Historical packages changed Vx only. Show their actual command
        # semantics, never pretend an old training run used the new stand fix.
        stage = {**stage, 'commandMode': 'velocity'}
    apply_stage_command(env.command_manager.get_term('twist'), stage)
    return index


def gated_velocity_curriculum(env, env_ids, settings):
    """Evaluate completed episodes before manager reset; never advance on falls.

    Command metrics integrate error / maximum command duration. Convert back to
    error per elapsed second (not per configured episode). Discard episodes that
    straddle a stage change, and collect a fresh full batch after each decision.
    """
    state = getattr(env, '_stackforce_velocity_curriculum', None)
    if state is None:
        state = dict(stage=settings['startStage'], count=0, successes=0, last_rate=0.0, evaluations=0, last_stage=-1,
                     assigned=torch.full((env.num_envs,), -1, device=env.device, dtype=torch.long),
                     base_weights={name: env.reward_manager.get_term_cfg(name).weight for name in env.reward_manager.active_terms})
        env._stackforce_velocity_curriculum = state
        apply_velocity_stage(env, settings, state)
    ids = torch.arange(env.num_envs, device=env.device)[env_ids if env_ids is not None else slice(None)]
    elapsed = env.episode_length_buf[ids].float() * env.step_dt
    eligible = (elapsed > 0) & (state['assigned'][ids] == state['stage'])
    if bool(eligible.any()):
        valid_ids = ids[eligible]
        duration = elapsed[eligible]
        command = env.command_manager.get_term('twist')
        error = command.metrics['error_vel_xy'][valid_ids] * command.cfg.resampling_time_range[1] / duration
        success = (~env.termination_manager.terminated[valid_ids]
                   & (duration >= settings['minimumEpisodeSeconds'])
                   & torch.isfinite(error)
                   & (error <= settings['stages'][state['stage']]['maxTrackingError']))
        yaw_limit = settings['stages'][state['stage']].get('maxYawTrackingError', 0)
        if yaw_limit > 0:
            yaw_error = command.metrics['error_vel_yaw'][valid_ids] * command.cfg.resampling_time_range[1] / duration
            success &= torch.isfinite(yaw_error) & (yaw_error <= yaw_limit)
        state['count'] += int(success.numel())
        state['successes'] += int(success.sum())
        if state['count'] >= settings['requiredEpisodes']:
            state['last_rate'] = state['successes'] / state['count']
            state['last_stage'] = state['stage']
            state['evaluations'] += 1
            if state['last_rate'] >= settings['successRate'] and state['stage'] + 1 < len(settings['stages']):
                state['stage'] += 1
                apply_velocity_stage(env, settings, state)
                print(f"[CURRICULUM] stage={state['stage']} name={settings['stages'][state['stage']]['name']} success={state['last_rate']:.3f}", flush=True)
            state['count'] = state['successes'] = 0
    state['assigned'][ids] = state['stage']
    stage = settings['stages'][state['stage']]
    return {'stage': float(state['stage']), 'success_rate': state['last_rate'],
            'evaluation_ready': float(state['evaluations'] > 0), 'evaluated_stage': float(state['last_stage']),
            'required_episodes': float(settings['requiredEpisodes']), 'successful_episodes': float(state['successes']),
            'standing': float(stage_command_mode(stage) == 'stand'),
            'evaluated_episodes': float(state['count']), 'vx_min': stage['linearX'][0],
            'vx_max': stage['linearX'][1], 'tracking_std': stage['trackingStd']}


def curriculum_checkpoint_state(env):
    state = getattr(env, '_stackforce_velocity_curriculum', None)
    if state is None:
        return None
    return {key: state[key] for key in ('stage', 'last_rate', 'evaluations', 'last_stage')}


def restore_curriculum_checkpoint(env, saved):
    if not saved or 'velocity_stages' not in env.curriculum_manager.active_terms:
        return
    settings = env.curriculum_manager.get_term_cfg('velocity_stages').params['settings']
    stage = int(saved['stage'])
    if stage < 0 or stage >= len(settings['stages']):
        raise ValueError('Checkpoint velocity stage is outside the saved GUI curriculum')
    if not hasattr(env, '_stackforce_velocity_curriculum'):
        gated_velocity_curriculum(env, torch.empty(0, dtype=torch.long, device=env.device), settings)
    state = env._stackforce_velocity_curriculum
    state.update(stage=stage, count=0, successes=0, last_rate=float(saved.get('last_rate', 0)),
                 evaluations=int(saved.get('evaluations', 0)), last_stage=int(saved.get('last_stage', -1)))
    state['assigned'].fill_(-1)
    apply_velocity_stage(env, settings, state)
