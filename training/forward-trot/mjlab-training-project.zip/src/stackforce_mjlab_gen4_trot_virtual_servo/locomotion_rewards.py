"""Optional generic reward memories; no policy inputs or plant writes."""
import torch
from mjlab.sensor import ContactSensor, TerrainHeightSensor
_EXACT_PHASE_STEP_CLOCK = True

def fixed_step_phase_cycles(env, period_s, dtype=torch.float32):
  """Modulo integer episode ticks before converting to bounded phase values."""
  ratio = float(period_s) / float(env.step_dt)
  steps = round(ratio)
  if steps < 1 or abs(ratio - steps) > 1.e-7:
    raise ValueError("Exact phase clock needs an integer number of environment steps")
  ticks = env.episode_length_buf
  if ticks.dtype not in (torch.int32, torch.int64):
    raise ValueError("Exact phase clock needs integer episode counters")
  # CUDA float32 division uses reciprocal multiplication. Divide the bounded
  # integers in float64 before the final cast so CPU, CUDA and native NumPy
  # round the same rational phase, including policy/physics shared boundaries.
  return (torch.remainder(ticks, steps).to(torch.float64) / steps).to(dtype)


def collision_reward_indices(env, asset_cfg, foot_geom_names):
  asset = env.scene[asset_cfg.name]
  if not foot_geom_names or len(set(foot_geom_names)) != len(foot_geom_names):
    raise ValueError("Unique collision geoms are required for reward feet")
  cache = getattr(env, "_stackforce_reward_geom_indices", None)
  if cache is None:
    cache = {}; env._stackforce_reward_geom_indices = cache
  key = (asset_cfg.name, tuple(foot_geom_names), repr(asset_cfg.site_ids))
  if key not in cache:
    local = [asset.geom_names.index(name) for name in foot_geom_names]
    world = asset.indexing.geom_ids[local]
    sites = asset.indexing.site_ids[asset_cfg.site_ids]
    model = env.sim.mj_model
    gi = world.detach().cpu().numpy(); si = sites.detach().cpu().numpy()
    if len(gi) != len(si) or not (model.geom_bodyid[gi] == model.site_bodyid[si]).all():
      raise ValueError("Reward collision geoms must follow the mapped contact-foot body order")
    if not ((model.geom_contype[gi] != 0) | (model.geom_conaffinity[gi] != 0)).all():
      raise ValueError("Reward feet must use collidable geoms")
    cache[key] = (local, world)
  return cache[key]


def sphere_bottom_heights(env, foot_geom_names):
  """True sphere support height; independent of the foot frame's orientation.

  This explicitly supports horizontal plane terrain and one sphere per foot.
  Unsupported terrain/geometry fails rather than silently using a link origin.
  """
  import numpy as np
  import mujoco
  robot = env.scene["robot"]
  key = tuple(foot_geom_names)
  cache = getattr(env, "_stackforce_sphere_height_geometry", None)
  if cache is None or cache[0] != key:
    model = env.sim.mj_model
    planes = np.flatnonzero(model.geom_type == mujoco.mjtGeom.mjGEOM_PLANE)
    if len(planes) != 1 or not np.allclose(model.geom_quat[planes[0]], [1, 0, 0, 0]):
      raise ValueError("Sphere-bottom height requires one horizontal terrain plane")
    ids = [model.geom("robot/" + name).id for name in foot_geom_names]
    if any(model.geom_type[i] != mujoco.mjtGeom.mjGEOM_SPHERE or not (model.geom_contype[i] or model.geom_conaffinity[i]) for i in ids):
      raise ValueError("Sphere-bottom height requires one collidable sphere per foot")
    local = [robot.geom_names.index(name) for name in foot_geom_names]
    radii = torch.as_tensor(model.geom_size[ids, 0].copy(), device=env.device, dtype=torch.float32)
    world_ids = robot.indexing.geom_ids[torch.as_tensor(local, device=env.device, dtype=torch.long)]
    cache = (key, world_ids, radii, float(model.geom_pos[planes[0], 2]))
    env._stackforce_sphere_height_geometry = cache
  _, world_ids, radii, ground_z = cache
  # Access geom_xpos directly: computing a quaternion for every geom is wasteful.
  return env.sim.data.geom_xpos[:, world_ids, 2] - radii - ground_z


def resolved_foot_height_targets(env, heights, command, target_heights, peak_tolerances,
                                 direction_target_heights=None, direction_peak_tolerances=None, direction_command_scales=None):
  """Cache configuration tensors; blend signed BODY command axes on device.

  Zero commands use base targets. Mixed commands use normalized magnitudes of
  x/y/yaw relative to their configured maximum command ranges.
  """
  import math
  count = heights.shape[1]
  directional = direction_target_heights is not None
  if (direction_peak_tolerances is not None) != directional or (direction_command_scales is not None) != directional:
    raise ValueError("Directional height targets, tolerances and command scales must be supplied together")
  if peak_tolerances is None:
    raise ValueError("Per-foot peak tolerances are required")
  key = (tuple(target_heights), tuple(peak_tolerances),
         tuple(tuple(row) for row in direction_target_heights) if directional else None,
         tuple(tuple(row) for row in direction_peak_tolerances) if directional else None,
         tuple(direction_command_scales) if directional else None, heights.device, heights.dtype)
  cache = getattr(env, "_stackforce_foot_height_targets", None)
  if cache is None or cache[0] != key:
    limit = torch.finfo(heights.dtype).max
    def vector(values, length, positive=False):
      if len(values) != length or any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v > limit or (v < torch.finfo(heights.dtype).tiny if positive else v < 0) for v in values):
        raise ValueError("Invalid finite per-foot target vector")
    def pair(goals, tolerances):
      vector(goals, count, True)
      vector(tolerances, count)
      if any(t >= g for g, t in zip(goals, tolerances)):
        raise ValueError("Foot tolerance must be smaller than target height")
    pair(target_heights, peak_tolerances)
    base = torch.tensor([list(target_heights) + list(peak_tolerances)], device=heights.device, dtype=heights.dtype)
    rows, scales = None, None
    if directional:
      if len(direction_target_heights) != 6 or len(direction_peak_tolerances) != 6:
        raise ValueError("Expected six signed body command directions")
      for goals, tolerances in zip(direction_target_heights, direction_peak_tolerances):
        pair(goals, tolerances)
      vector(direction_command_scales, 3, True)
      rows = torch.tensor([list(g) + list(t) for g, t in zip(direction_target_heights, direction_peak_tolerances)], device=heights.device, dtype=heights.dtype)
      scales = torch.tensor(direction_command_scales, device=heights.device, dtype=heights.dtype)
    cache = (key, base, rows, scales)
    env._stackforce_foot_height_targets = cache
  _, values, rows, scales = cache
  if rows is not None:
    normalized = command[:, :3] / scales
    weights = torch.stack((normalized.clamp_min(0.), (-normalized).clamp_min(0.)), dim=-1).flatten(1)
    total = weights.sum(dim=1, keepdim=True)
    values = torch.where(total > 0., (weights @ rows) / total.clamp_min(torch.finfo(heights.dtype).tiny), values)
  return values[:, :count], values[:, count:]


def targeted_foot_cycle_peak_cost(env, heights, local_phase, swing_fraction, targets, tolerances, active, aggregation):
  """Pair each completed peak with its goal AT THAT PEAK, across commands.

  Unequal goals use normalized peak spread, so accurately meeting different
  requested heights is not penalized as absolute height asymmetry.
  """
  targets = targets.expand_as(heights)
  tolerances = tolerances.expand_as(heights)
  state = getattr(env, "_stackforce_targeted_foot_cycle_peaks", None)
  if state is None or state["peaks"].shape != heights.shape:
    state = {"peaks": torch.zeros_like(heights), "last": torch.zeros_like(heights),
             "goals": targets.clone(), "last_goals": targets.clone(),
             "tolerances": tolerances.clone(), "last_tolerances": tolerances.clone(),
             "valid": torch.zeros_like(heights, dtype=torch.bool),
             "previous_swing": torch.zeros_like(heights, dtype=torch.bool),
             "previous_tick": torch.full_like(env.episode_length_buf, -1)}
    env._stackforce_targeted_foot_cycle_peaks = state
  ticks = env.episode_length_buf
  reset = (ticks < state["previous_tick"]) | (ticks == 0)
  if active is not None:
    reset |= ~active
  state["peaks"] = torch.where(reset[:, None], 0., state["peaks"])
  state["last"] = torch.where(reset[:, None], 0., state["last"])
  state["valid"] &= ~reset[:, None]
  previous = state["previous_swing"] & ~reset[:, None]
  swing = local_phase < swing_fraction
  start = swing & ~previous
  finished = ~swing & previous
  for last, current in (("last", "peaks"), ("last_goals", "goals"), ("last_tolerances", "tolerances")):
    state[last] = torch.where(finished, state[current], state[last])
  new_peak = swing & (start | (heights > state["peaks"]))
  state["goals"] = torch.where(new_peak, targets, state["goals"])
  state["tolerances"] = torch.where(new_peak, tolerances, state["tolerances"])
  state["peaks"] = torch.where(swing, torch.where(start, heights, torch.maximum(state["peaks"], heights)), 0.)
  state["valid"] |= finished
  state["previous_swing"] = swing.clone()
  state["previous_tick"] = ticks.clone()
  valid = state["valid"]
  error = torch.relu(torch.abs(state["last"] - state["last_goals"]) - state["last_tolerances"]) / state["last_goals"]
  tracking = (error * valid).amax(dim=1) if aggregation == "worst_valid" else (error * valid).sum(dim=1) / valid.sum(dim=1).clamp_min(1)
  relative = state["last"] / state["last_goals"]
  symmetry = torch.where(valid.all(dim=1), relative.amax(dim=1) - relative.amin(dim=1), 0.)
  return tracking, symmetry


def foot_cycle_peak_cost(env, heights, local_phase, swing_fraction, target_height, tolerance, active=None, aggregation="mean"):
  """Remember each foot's last completed swing, with per-environment reset.

  Opposite-phase feet are compared across completed swings, never at the same
  instant. This avoids rewarding four legs lifting together.
  """
  if aggregation not in ("mean", "worst_valid"):
    raise ValueError("Unknown completed foot peak aggregation")
  if torch.is_tensor(target_height):
    return targeted_foot_cycle_peak_cost(env, heights, local_phase, swing_fraction, target_height, tolerance, active, aggregation)
  state = getattr(env, "_stackforce_foot_cycle_peaks", None)
  if state is None or state["peaks"].shape != heights.shape:
    state = {"peaks": torch.zeros_like(heights), "last": torch.zeros_like(heights),
             "valid": torch.zeros_like(heights, dtype=torch.bool),
             "previous_swing": torch.zeros_like(heights, dtype=torch.bool),
             "previous_tick": torch.full_like(env.episode_length_buf, -1)}
    env._stackforce_foot_cycle_peaks = state
  ticks = env.episode_length_buf
  reset = (ticks < state["previous_tick"]) | (ticks == 0)
  if active is not None:
    reset |= ~active
  state["peaks"] = torch.where(reset[:, None], 0., state["peaks"])
  state["last"] = torch.where(reset[:, None], 0., state["last"])
  state["valid"] &= ~reset[:, None]
  previous = state["previous_swing"] & ~reset[:, None]
  swing = local_phase < swing_fraction
  start = swing & ~previous
  peaks = torch.where(start, heights, torch.maximum(state["peaks"], heights))
  finished = ~swing & previous
  state["last"] = torch.where(finished, state["peaks"], state["last"])
  state["valid"] |= finished
  state["peaks"] = torch.where(swing, peaks, 0.)
  state["previous_swing"] = swing.clone()
  state["previous_tick"] = ticks.clone()
  valid = state["valid"]
  error = torch.relu(torch.abs(state["last"] - target_height) - tolerance) / target_height
  tracking = (error * valid).sum(dim=1) / valid.sum(dim=1).clamp_min(1)
  if aggregation == "worst_valid":
    # Focus on the least accurate completed foot without changing peak memory,
    # target, tolerance or symmetry. Unmeasured feet remain excluded.
    tracking = (error * valid).amax(dim=1)
  spread = (state["last"].amax(dim=1) - state["last"].amin(dim=1)) / target_height
  symmetry = torch.where(valid.all(dim=1), spread, 0.)
  return tracking, symmetry


def phase_foot_clearance(
  env, height_sensor_name: str, target_height: float, period_s: float,
  phase_offsets: list[float], aggregation: str, command_name: str,
  command_threshold: float, swing_fraction: float = 0.5,
  height_source: str = "site", foot_geom_names: list[str] | None = None,
  worst_foot_weight: float = 0., peak_tracking_weight: float = 0.,
  peak_symmetry_weight: float = 0., peak_tolerance: float = 0.003,
  profile_tracking_weight: float = 1.,
  peak_tracking_aggregation: str = "mean",
  target_heights: list[float] | None = None, peak_tolerances: list[float] | None = None,
  direction_target_heights: list[list[float]] | None = None,
  direction_peak_tolerances: list[list[float]] | None = None,
  direction_command_scales: list[float] | None = None,
) -> torch.Tensor:
  if peak_tracking_aggregation not in ("mean", "worst_valid"):
    raise ValueError("Unknown completed foot peak aggregation")
  if isinstance(profile_tracking_weight, bool) or not isinstance(profile_tracking_weight, (int, float)) or not 0. <= profile_tracking_weight <= 1.:
    raise ValueError("Foot height profile weight must be finite and in [0, 1]")
  if height_source == "sphere_bottom":
    if not foot_geom_names or len(foot_geom_names) != len(phase_offsets):
      raise ValueError("One sphere geom per phase foot is required")
    heights = sphere_bottom_heights(env, foot_geom_names).clamp_min(0.)
  elif height_source == "site":
    sensor = env.scene[height_sensor_name]
    assert isinstance(sensor, TerrainHeightSensor)
    heights = torch.clamp(sensor.data.heights, min=0.0)
  else:
    raise ValueError("Unknown foot height source")
  if heights.shape[1] != len(phase_offsets):
    raise ValueError("phase_offsets must match foot height frames")
  offsets = torch.as_tensor(phase_offsets, device=heights.device, dtype=heights.dtype)
  if globals().get("_EXACT_PHASE_STEP_CLOCK", False):
    phase = fixed_step_phase_cycles(env, period_s, heights.dtype)
  else:
    phase = env.episode_length_buf.to(heights.dtype) * env.step_dt / max(period_s, 1.e-6)
  if not 0. < swing_fraction < 1.:
    raise ValueError("swing_fraction must be between zero and one")
  local_phase = torch.remainder(phase[:, None] + offsets[None, :], 1.)
  if swing_fraction == 0.5:
    swing = torch.clamp(torch.sin(2.*torch.pi*(phase[:, None]+offsets[None, :])), min=0.)
  else:
    swing = torch.where(local_phase < swing_fraction, torch.sin(torch.pi*local_phase/swing_fraction), 0.)
  command = env.command_manager.get_command(command_name)
  assert command is not None
  if target_heights is not None:
    target_height, peak_tolerance = resolved_foot_height_targets(env, heights, command, target_heights, peak_tolerances,
      direction_target_heights, direction_peak_tolerances, direction_command_scales)
  elif peak_tolerances is not None or any(value is not None for value in (direction_target_heights, direction_peak_tolerances, direction_command_scales)):
    raise ValueError("Per-foot target heights are required")
  target = target_height * swing
  active = (torch.linalg.vector_norm(command[:, :2], dim=1) + torch.abs(command[:, 2]) > command_threshold).to(heights.dtype)
  error = torch.abs(heights-target) / (target_height if torch.is_tensor(target_height) else max(target_height, 1.e-6))
  if aggregation == "worst_foot":
    cost = torch.amax(error, dim=1)
  elif aggregation == "mean":
    cost = torch.mean(error, dim=1)
  else:
    raise ValueError("Unsupported foot error aggregation")
  cost = cost + worst_foot_weight * error.amax(dim=1)
  # Optional training-only freedom around the within-swing height profile.
  # Completed peak height and cross-foot peak symmetry retain their full costs.
  # Skip multiplication at one to preserve legacy arithmetic exactly.
  if profile_tracking_weight != 1.:
    cost = cost * profile_tracking_weight
  if peak_tracking_weight or peak_symmetry_weight:
    tracking, symmetry = foot_cycle_peak_cost(env, heights, local_phase, swing_fraction, target_height, peak_tolerance, active > 0, peak_tracking_aggregation)
    cost = cost + peak_tracking_weight * tracking + peak_symmetry_weight * symmetry
  return cost * active


def stationary_support_cost(heights, forces, linear_velocity, angular_velocity, joint_velocity, command,
    height_scale=.035, force_threshold=.2, linear_deadband=.005, angular_deadband=.02,
    height_weight=1., contact_weight=.5, motion_weight=1., joint_motion_weight=.1,
    worst_foot_weight=.25, linear_speed_std=.02, angular_speed_std=.1, motion_cost_mode="bounded"):
  import math
  for name, value in dict(height_scale=height_scale, linear_speed_std=linear_speed_std, angular_speed_std=angular_speed_std).items():
    if not math.isfinite(value) or value <= 0: raise ValueError(name + " must be finite and positive")
  for name, value in dict(force_threshold=force_threshold, linear_deadband=linear_deadband, angular_deadband=angular_deadband,
      height_weight=height_weight, contact_weight=contact_weight, motion_weight=motion_weight,
      joint_motion_weight=joint_motion_weight, worst_foot_weight=worst_foot_weight).items():
    if not math.isfinite(value) or value < 0: raise ValueError(name + " must be finite and nonnegative")
  if motion_cost_mode not in ("bounded", "logarithmic"): raise ValueError("Unknown stationary motion cost mode")
  if heights.ndim != 2 or heights.shape[1] < 1 or forces.shape != heights.shape:
    raise ValueError("Stationary support needs matching mapped foot heights and contact forces")
  error = heights.clamp_min(0) / height_scale
  height_cost = error.mean(dim=-1) + worst_foot_weight * error.amax(dim=-1)
  contact_cost = (~(forces > force_threshold)).to(heights.dtype).mean(dim=-1)
  linear = linear_velocity[:, :2].square().sum(dim=-1) / linear_speed_std**2
  angular = angular_velocity.square().sum(dim=-1) / angular_speed_std**2
  if motion_cost_mode == "logarithmic":
    motion = torch.log1p(linear) + .5 * torch.log1p(angular)
  else:
    motion = 1. - torch.exp(-linear) + .5 * (1. - torch.exp(-angular))
  motion = motion + joint_motion_weight * torch.tanh(joint_velocity.square().mean(dim=-1))
  idle = (command[:, :2].norm(dim=-1) <= linear_deadband) & (command[:, 2].abs() <= angular_deadband)
  return (height_weight * height_cost + contact_weight * contact_cost + motion_weight * motion) * idle


def stance_support(env, sensor_name, height_sensor_name, asset_cfg, command_name="twist",
    height_source="site", foot_geom_names=None, **parameters):
  robot = env.scene[asset_cfg.name]
  if height_source == "sphere_bottom":
    collision_reward_indices(env, asset_cfg, foot_geom_names)
    heights = sphere_bottom_heights(env, foot_geom_names)
  elif height_source == "site":
    heights = env.scene[height_sensor_name].data.heights
  else:
    raise ValueError("Unsupported stationary support height source")
  forces = env.scene[sensor_name].data.force
  if forces is None: raise ValueError("Stationary support requires mapped foot contact forces")
  return stationary_support_cost(heights, forces.norm(dim=-1), robot.data.root_link_lin_vel_b,
    robot.data.root_link_ang_vel_b, robot.data.joint_vel[:, asset_cfg.joint_ids],
    env.command_manager.get_command(command_name), **parameters)


def phase_foot_contact(
  env,
  sensor_name: str,
  period_s: float,
  phase_offsets: list[float],
  force_threshold: float,
  aggregation: str,
  command_name: str,
  command_threshold: float,
  swing_fraction: float = 0.5,
  load_transfer_weight: float = 0.0,
  swing_unload_weight: float = 0.0,
  phase_zero_is_swing: bool = False,
) -> torch.Tensor:
  """Penalize real ground contact during swing and absent contact during stance."""
  sensor: ContactSensor = env.scene[sensor_name]
  if sensor.data.force is None:
    raise RuntimeError(f"Foot-contact sensor {sensor_name} has no force field")
  force = torch.linalg.vector_norm(sensor.data.force, dim=-1)
  if force.shape[1] != len(phase_offsets):
    raise ValueError("phase_offsets must match the number of contact-sensor feet")
  offsets = torch.as_tensor(phase_offsets, device=force.device, dtype=force.dtype)
  if globals().get("_EXACT_PHASE_STEP_CLOCK", False):
    phase = fixed_step_phase_cycles(env, period_s, force.dtype)
  else:
    phase = env.episode_length_buf.to(force.dtype) * env.step_dt / max(period_s, 1.0e-6)
  if not 0.0 < swing_fraction < 1.0:
    raise ValueError("swing_fraction must be between zero and one")
  if not isinstance(phase_zero_is_swing, bool):
    raise ValueError("phase_zero_is_swing must be boolean")
  if phase_zero_is_swing:
    # Match clearance, stride and swing-advance: phase zero starts swing.
    # Keep the legacy exact-boundary rule unless a recipe opts in.
    local_phase = torch.remainder(phase[:, None] + offsets[None, :], 1.0)
    desired_swing = local_phase < swing_fraction
  elif swing_fraction == 0.5:
    desired_swing = torch.sin(2.0 * torch.pi * (phase[:, None] + offsets[None, :])) > 0.0
  else:
    local_phase = torch.remainder(phase[:, None] + offsets[None, :], 1.0)
    desired_swing = (local_phase > 0.0) & (local_phase < swing_fraction)
  touching = force > force_threshold
  mismatch = torch.logical_xor(desired_swing, ~touching).float()
  if not 0.0 <= load_transfer_weight < float("inf"):
    raise ValueError("load_transfer_weight must be finite and non-negative")
  if not 0.0 <= swing_unload_weight < float("inf"):
    raise ValueError("swing_unload_weight must be finite and non-negative")
  if load_transfer_weight > 0.0:
    # Supply dense feedback before a loaded swing foot crosses the binary
    # contact threshold. Retain the binary term: unloading alone is not lift.
    stance = (~desired_swing).to(force.dtype)
    desired_share = stance / stance.sum(dim=1, keepdim=True).clamp(min=1.0)
    actual_share = force / force.sum(dim=1, keepdim=True).clamp(min=max(force_threshold, 1.0e-6))
    mismatch = mismatch + load_transfer_weight * torch.abs(actual_share - desired_share)
  command = env.command_manager.get_command(command_name)
  assert command is not None
  active = (torch.linalg.vector_norm(command[:, :2], dim=1) + torch.abs(command[:, 2]) > command_threshold).float()
  if aggregation == "worst_foot":
    cost = torch.amax(mismatch, dim=1)
  elif aggregation == "mean":
    cost = torch.mean(mismatch, dim=1)
  else:
    raise ValueError(f"Unsupported foot contact aggregation: {aggregation}")
  # Dense unloading feedback does not require equal load on the support feet.
  # This matters for a tripod whose mass projection is near an edge.
  swing_load = (force * desired_swing).sum(dim=1) / force.sum(dim=1).clamp(min=max(force_threshold, 1.e-6))
  return (cost + swing_unload_weight * swing_load) * active



class SwingAdvanceMemory:
  """Track net foot transport in a frame fixed to the other support feet.

  The support identities and frame pair are frozen at takeoff. Changing load
  distribution cannot move the reference. Common translation/rotation of all
  feet leaves these coordinates unchanged. Completed error persists through
  stance, so reversing a good mid-swing stroke cannot escape the penalty.
  """
  def __init__(self, period_s, swing_fraction, force_threshold, target_step_ratio,
               max_target_advance, advance_std, dense_weight, aggregation,
               minimum_reference_feet, command_threshold, exclude_swing_references=False):
    for value in (period_s, target_step_ratio, max_target_advance, advance_std):
      if not 0 < value < float("inf"):
        raise ValueError("Swing advance scales must be finite and positive")
    for value in (force_threshold, dense_weight, command_threshold):
      if not 0 <= value < float("inf"):
        raise ValueError("Swing advance thresholds/weights must be finite and nonnegative")
    if not 0 < swing_fraction < 1 or aggregation not in ("mean", "worst_foot"):
      raise ValueError("Invalid swing advance phase or aggregation")
    if isinstance(minimum_reference_feet, bool) or not isinstance(minimum_reference_feet, int) or minimum_reference_feet < 2:
      raise ValueError("At least two reference feet are required")
    if not isinstance(exclude_swing_references, bool):
      raise ValueError("exclude_swing_references must be a boolean")
    self.period_s = period_s
    self.swing_fraction = swing_fraction
    self.force_threshold = force_threshold
    self.target_step_ratio = target_step_ratio
    self.max_target_advance = max_target_advance
    self.advance_std = advance_std
    self.dense_weight = dense_weight
    self.aggregation = aggregation
    self.minimum_reference_feet = minimum_reference_feet
    self.command_threshold = command_threshold
    self.exclude_swing_references = exclude_swing_references
    self.state = None

  @staticmethod
  def _coordinates(position, weights, first, second):
    rows = torch.arange(position.shape[0], device=position.device)[:, None]
    center = torch.einsum("nif,nfc->nic", weights, position[:, :, :2])
    axis = position[rows, second, :2] - position[rows, first, :2]
    length = torch.linalg.vector_norm(axis, dim=-1)
    ex = axis / length[:, :, None].clamp_min(1.e-6)
    ey = torch.stack((-ex[:, :, 1], ex[:, :, 0]), dim=-1)
    delta = position[:, :, :2] - center
    coords = torch.stack(((delta*ex).sum(-1), (delta*ey).sum(-1)), dim=-1)
    return coords, ex, ey, length > 1.e-6

  def update(self, position, force, command, direction_w, phase, step, foot_speed=None, active_mask=None):
    n, count, _ = position.shape
    direction_shape = (n, 2) if foot_speed is None else (n, count, 2)
    if position.shape[-1] != 3 or force.shape != (n, count) or phase.shape != (n, count) or command.shape != (n, 3) or direction_w.shape != direction_shape or step.shape != (n,):
      raise ValueError("Swing advance positions/forces/phases/commands must have matching shapes")
    if foot_speed is not None and foot_speed.shape != (n, count):
      raise ValueError("One twist-derived planar speed is required per foot")
    if self.minimum_reference_feet >= count:
      raise ValueError("Not enough other feet for the requested reference")
    speed = torch.linalg.vector_norm(command[:, :2], dim=-1) if foot_speed is None else foot_speed
    if self.state is None:
      zeros = position.new_zeros((n, count))
      flags = torch.zeros((n, count), device=position.device, dtype=torch.bool)
      self.state = {
        "step": torch.full_like(step, -1), "command": command.clone(),
        "previous": position.clone(), "force": force.clone(), "direction": direction_w.clone(), "speed": speed.clone(),
        "have_previous": torch.zeros(n, device=position.device, dtype=torch.bool),
        "swing": flags.clone(), "started": flags.clone(), "anchor_valid": flags.clone(),
        "unloaded": flags.clone(), "completed_valid": flags.clone(), "completed": zeros.clone(),
        "target": zeros.clone(), "anchor": position.new_zeros((n, count, 2)),
        "direction_support": position.new_zeros((n, count, 2)),
        "weights": position.new_zeros((n, count, count)),
        "first": torch.zeros((n, count), device=position.device, dtype=torch.long),
        "second": torch.zeros((n, count), device=position.device, dtype=torch.long),
      }
    state = self.state
    if state["previous"].shape != position.shape:
      raise ValueError("Swing advance batch/foot shape changed within one environment")
    if state["direction"].shape != direction_w.shape:
      raise ValueError("Swing advance direction mode changed within one environment")
    active = (speed[:, None] if foot_speed is None else speed) > self.command_threshold
    if active_mask is not None:
      if foot_speed is None or active_mask.shape != (n, count) or active_mask.dtype != torch.bool:
        raise ValueError("Twist command activity must be one boolean per foot")
      active = active_mask
    moving = active.any(-1)
    dimensions = 2 if foot_speed is None else 3
    changed = (command[:, :dimensions]-state["command"][:, :dimensions]).abs().amax(-1) > 1.e-6
    clear = (step <= state["step"]) | changed | ~moving
    previous_valid = state["have_previous"] & ~clear
    for name in ("started", "anchor_valid", "unloaded", "completed_valid"):
      state[name] = state[name] & ~(clear[:, None] | ~active)
    swing = phase < self.swing_fraction
    start = swing & ~state["swing"] & previous_valid[:, None] & active

    # Select reference identities and a well-separated pair at takeoff only.
    other = 1.-torch.eye(count, device=position.device, dtype=position.dtype)
    mask = (state["force"] > self.force_threshold).to(position.dtype)[:, None, :] * other[None]
    if self.exclude_swing_references:
      # A loaded foot can be the simultaneously lifting diagonal partner.
      # Freeze only loaded feet whose current commanded phase is stance.
      # Contact truth is still required; phase alone cannot create support.
      mask = mask * (~swing).to(position.dtype)[:, None, :]
    total = mask.sum(-1)
    weights = mask / total[:, :, None].clamp_min(1.)
    delta = state["previous"][:, :, None, :2] - state["previous"][:, None, :, :2]
    score = delta.square().sum(-1)[:, None] * mask[:, :, :, None] * mask[:, :, None, :]
    pair = score.flatten(-2).argmax(-1)
    first, second = pair//count, pair % count
    anchor, ex, ey, pair_valid = self._coordinates(state["previous"], weights, first, second)
    direction = state["direction"][:, None] if foot_speed is None else state["direction"]
    direction_support = torch.stack(((direction*ex).sum(-1), (direction*ey).sum(-1)), dim=-1)
    for name, value in (("weights", weights), ("anchor", anchor), ("direction_support", direction_support)):
      state[name] = torch.where(start[(...,)+(None,)*(value.ndim-2)], value, state[name])
    for name, value in (("first", first), ("second", second)):
      state[name] = torch.where(start, value, state[name])
    state["anchor_valid"] = torch.where(start, (total >= self.minimum_reference_feet) & pair_valid, state["anchor_valid"])
    state["started"] = state["started"] | start
    target_speed = speed[:, None] if foot_speed is None else state["speed"]
    target = (target_speed*self.period_s*self.target_step_ratio).clamp(max=self.max_target_advance)
    state["target"] = torch.where(start, target, state["target"])
    unloaded_now = force <= self.force_threshold
    state["unloaded"] = torch.where(start, unloaded_now, state["unloaded"] | (swing & unloaded_now & state["anchor_valid"]))

    coords, _, _, valid_now = self._coordinates(position, state["weights"], state["first"], state["second"])
    advance = ((coords-state["anchor"])*state["direction_support"]).sum(-1)
    shortfall = (state["target"]-advance).clamp_min(0.)/self.advance_std
    cost = 1.-torch.exp(-shortfall)
    valid = state["anchor_valid"] & valid_now
    end = ~swing & state["swing"] & state["started"] & previous_valid[:, None] & active
    completed = torch.where(valid & state["unloaded"], cost, torch.ones_like(cost))
    state["completed"] = torch.where(end, completed, state["completed"])
    state["completed_valid"] = state["completed_valid"] | end
    dense = torch.where(valid & unloaded_now, cost, torch.ones_like(cost))
    foot_cost = state["completed"]*state["completed_valid"] + self.dense_weight*dense*swing*state["started"]
    foot_cost *= active
    result = foot_cost.mean(-1) if self.aggregation == "mean" else foot_cost.amax(-1)
    state.update(step=step.clone(), command=command.detach().clone(), previous=position.detach().clone(),
                 force=force.detach().clone(), direction=direction_w.detach().clone(), speed=speed.detach().clone(),
                 have_previous=moving.clone(), swing=swing.clone())
    return result


class BodySwingAdvanceMemory:
  """Straight-command reward in each foot's instantaneous body frame.

  The body-frame return stroke equals speed * stance duration. This is reward
  shaping, not a joint trajectory, teacher, extra actor input, or air detector.
  Actual-air excursion remains measured by the separate horizontal-stride term.
  """
  def __init__(self, period_s, swing_fraction, force_threshold, target_step_ratio,
               max_target_advance, advance_std, dense_weight, aggregation,
               command_threshold, minimum_target_advance=0., minimum_target_reference_speed=0., planar_straight=False):
    if not 0 < swing_fraction < 1 or aggregation not in ("mean", "worst_foot"):
      raise ValueError("Invalid body swing phase or aggregation")
    if any(not 0 < v < float("inf") for v in (period_s, target_step_ratio, max_target_advance, advance_std)):
      raise ValueError("Body swing scales must be finite and positive")
    if any(not 0 <= v < float("inf") for v in (force_threshold, dense_weight, command_threshold)):
      raise ValueError("Body swing thresholds must be finite and nonnegative")
    self.period_s, self.swing_fraction = period_s, swing_fraction
    self.force_threshold, self.target_step_ratio = force_threshold, target_step_ratio
    self.max_target_advance, self.advance_std = max_target_advance, advance_std
    self.dense_weight, self.aggregation = dense_weight, aggregation
    self.command_threshold = command_threshold
    if any(isinstance(v, bool) or not 0 <= v < float("inf") for v in (minimum_target_advance, minimum_target_reference_speed)):
      raise ValueError("Body target floor scales must be finite and nonnegative")
    if minimum_target_advance > 0 and (minimum_target_reference_speed <= 0 or minimum_target_advance > max_target_advance):
      raise ValueError("Body target floor needs a positive reference speed and must not exceed the cap")
    self.minimum_target_advance = minimum_target_advance
    self.minimum_target_reference_speed = minimum_target_reference_speed
    if not isinstance(planar_straight, bool):
      raise ValueError("Planar body swing flag must be boolean")
    self.planar_straight = planar_straight
    self.state = None

  def update(self, body_x, force, command, phase, step):
    if body_x.ndim != 2 or force.shape != body_x.shape or phase.shape != body_x.shape or command.shape != (body_x.shape[0], 3) or step.shape != body_x.shape[:1]:
      raise ValueError("Body swing positions/force/phase/command/step must match")
    if step.dtype not in (torch.int32, torch.int64):
      raise ValueError("Body swing steps must be integers")
    active = ((command[:, 0].abs() > self.command_threshold) &
              (command[:, 1] == 0) & (command[:, 2] == 0))
    if self.planar_straight:
      active = (torch.linalg.vector_norm(command[:, :2], dim=-1) > self.command_threshold) & (command[:, 2] == 0)
    if self.state is None:
      flags = torch.zeros_like(body_x, dtype=torch.bool)
      self.state = dict(step=torch.full_like(step, -1), command=command.clone(),
        previous=body_x.clone(), phase=phase.clone(), anchor=body_x.clone(), target=torch.zeros_like(body_x),
        have_previous=torch.zeros_like(active), swing=flags.clone(), started=flags.clone(),
        unloaded=flags.clone(), completed_valid=flags.clone(), completed=torch.zeros_like(body_x),
        cost=body_x.new_zeros(body_x.shape[0]))
    s = self.state
    if s["previous"].shape != body_x.shape:
      raise ValueError("Body swing batch/foot shape changed")
    changed = (command-s["command"]).abs().amax(-1) > 1.e-6
    duplicate = (step == s["step"]) & ~changed
    clear = ((step < s["step"]) | (step > s["step"]+1) | changed | ~active) & ~duplicate
    previous_valid = s["have_previous"] & ~clear & ~duplicate
    for name in ("started", "unloaded", "completed_valid"):
      s[name] &= ~clear[:, None]
    swing = phase < self.swing_fraction
    start = swing & ~s["swing"] & previous_valid[:, None] & active[:, None]
    # Interpolate only the reward boundary position, not the policy clock.
    # A float phase just below1 must not turn one earlier sample into a full
    # extra swing increment. Exact phase0 selects the current position.
    phase_delta = (1.-s["phase"]+phase).clamp_min(1.e-6)
    fraction = ((1.-s["phase"])/phase_delta).clamp(0., 1.)
    boundary_x = s["previous"]+fraction*(body_x-s["previous"])
    s["anchor"] = torch.where(start, boundary_x, s["anchor"])
    target = (command[:, 0].abs()*self.period_s*(1-self.swing_fraction)*self.target_step_ratio).clamp(max=self.max_target_advance)
    if self.planar_straight:
      target = (torch.linalg.vector_norm(command[:, :2], dim=-1)*self.period_s*(1-self.swing_fraction)*self.target_step_ratio).clamp(max=self.max_target_advance)
    if self.minimum_target_advance > 0:
      # Optional training-only floor. The legacy speed*stance target can end
      # before the independently required useful actual-air stroke. This is
      # one-sided guidance, not an IK trajectory or a change to measurement.
      floor_scale = (command[:, 0].abs()/self.minimum_target_reference_speed).clamp(max=1.)
      if self.planar_straight:
        floor_scale = (torch.linalg.vector_norm(command[:, :2], dim=-1)/self.minimum_target_reference_speed).clamp(max=1.)
      target = torch.maximum(target, self.minimum_target_advance*floor_scale)
    s["target"] = torch.where(start, target[:, None], s["target"])
    s["started"] |= start
    unloaded_now = force <= self.force_threshold
    s["unloaded"] = torch.where(start, unloaded_now, s["unloaded"] | (swing & unloaded_now & s["started"] & ~duplicate[:, None]))
    advance = (body_x-s["anchor"])*torch.sign(command[:, 0, None])
    if self.planar_straight:
      advance = body_x-s["anchor"]
    end = ~swing & s["swing"] & s["started"] & previous_valid[:, None] & active[:, None]
    end_fraction = ((self.swing_fraction-s["phase"])/(phase-s["phase"]).clamp_min(1.e-6)).clamp(0., 1.)
    end_x = s["previous"]+end_fraction*(body_x-s["previous"])
    end_advance = (end_x-s["anchor"])*torch.sign(command[:, 0, None])
    if self.planar_straight:
      end_advance = end_x-s["anchor"]
    full_cost = 1.-torch.exp(-torch.relu(s["target"]-end_advance)/self.advance_std)
    s["completed"] = torch.where(end, torch.where(s["unloaded"], full_cost, torch.ones_like(full_cost)), s["completed"])
    s["completed_valid"] |= end
    # A phase-progress target supplies feedback before landing; no foot target
    # is written to the robot. Being loaded cannot earn swing-unload success.
    progress = (phase/self.swing_fraction).clamp(0., 1.)
    dense = 1.-torch.exp(-torch.relu(s["target"]*progress-advance)/self.advance_std)
    dense = torch.where(unloaded_now, dense, torch.ones_like(dense))
    foot_cost = (s["completed"]*s["completed_valid"] + self.dense_weight*dense*swing*s["started"])*active[:, None]
    result = foot_cost.mean(-1) if self.aggregation == "mean" else foot_cost.amax(-1)
    s["cost"] = torch.where(duplicate, s["cost"], result)
    s["step"] = torch.where(duplicate, s["step"], step)
    s["command"] = torch.where(duplicate[:, None], s["command"], command.detach())
    s["previous"] = torch.where(duplicate[:, None], s["previous"], body_x.detach())
    s["phase"] = torch.where(duplicate[:, None], s["phase"], phase.detach())
    s["swing"] = torch.where(duplicate[:, None], s["swing"], swing)
    s["have_previous"] = torch.where(duplicate, s["have_previous"], active)
    return s["cost"].clone()


def phase_foot_swing_advance(env, asset_cfg, sensor_name, period_s, phase_offsets,
                           swing_fraction, command_threshold, force_threshold,
                           target_step_ratio, max_target_advance, advance_std,
                           dense_weight, aggregation, minimum_reference_feet,
                           command_name, forward_axis_index=0, forward_axis_sign=1.,
                           command_mode="translation", point_source="site", foot_geom_names=None,
                           exclude_swing_references=False, straight_body_frame=False,
                           minimum_target_advance=0., minimum_target_reference_speed=0.,
                           angular_command_threshold=None, planar_body_frame=False):
  if not isinstance(straight_body_frame, bool):
    raise ValueError("straight_body_frame must be boolean")
  if not isinstance(planar_body_frame, bool) or (planar_body_frame and not straight_body_frame):
    raise ValueError("planar_body_frame requires boolean True and straight_body_frame=True")
  if any(isinstance(v, bool) or not 0 <= v < float("inf") for v in (minimum_target_advance, minimum_target_reference_speed)):
    raise ValueError("Body target floor scales must be finite and nonnegative")
  if minimum_target_advance > 0 and (not straight_body_frame or minimum_target_reference_speed <= 0 or minimum_target_advance > max_target_advance):
    raise ValueError("Body target floor requires straight_body_frame, a positive speed reference and a compatible cap")
  if command_mode not in ("translation", "planar_twist"):
    raise ValueError("Swing advance command mode must be translation or planar_twist")
  if angular_command_threshold is not None and (command_mode != "planar_twist" or isinstance(angular_command_threshold, bool) or not 0 <= angular_command_threshold < float("inf")):
    raise ValueError("Angular command threshold requires planar_twist and a finite nonnegative rad/s value")
  if forward_axis_index not in (0, 1) or forward_axis_sign not in (-1, 1):
    raise ValueError("Invalid swing advance forward axis")
  if any(not 0 <= value < 1 for value in phase_offsets):
    raise ValueError("Invalid swing advance phase offsets")
  asset = env.scene[asset_cfg.name]
  if point_source == "site":
    position = asset.data.site_pos_w[:, asset_cfg.site_ids]
  elif point_source == "collision_geom":
    _, world = collision_reward_indices(env, asset_cfg, foot_geom_names)
    position = env.sim.data.geom_xpos[:, world]
  else:
    raise ValueError("Invalid swing reward point source")
  force = torch.linalg.vector_norm(env.scene[sensor_name].data.force, dim=-1)
  if position.shape[1] != len(phase_offsets) or force.shape[1] != len(phase_offsets):
    raise ValueError("Swing advance sites/contact feet must match phase order and count")
  command = env.command_manager.get_command(command_name)
  speed = torch.linalg.vector_norm(command[:, :2], dim=-1)
  body = torch.zeros_like(command[:, :2])
  body[:, forward_axis_index] = command[:, 0]*forward_axis_sign
  body[:, 1-forward_axis_index] = command[:, 1]
  w, x, y, z = asset.data.root_link_quat_w.unbind(-1)
  forward = torch.stack((1-2*(y*y+z*z), 2*(x*y+w*z)), dim=-1)
  forward = forward/torch.linalg.vector_norm(forward, dim=-1, keepdim=True).clamp_min(1.e-6)
  translation = torch.stack((forward[:, 0]*body[:, 0]-forward[:, 1]*body[:, 1],
                             forward[:, 1]*body[:, 0]+forward[:, 0]*body[:, 1]), dim=-1)
  foot_speed = None
  active_mask = None
  if command_mode == "planar_twist":
    # Planar rigid-body twist at each foot: v + wz * (-ry, rx).
    # This is privileged reward geometry, not a joint trajectory or actor input.
    lever = position[:, :, :2] - asset.data.root_link_pos_w[:, None, :2]
    tangent = torch.stack((-lever[:, :, 1], lever[:, :, 0]), dim=-1)
    velocity = translation[:, None, :] + command[:, 2, None, None]*tangent
    foot_speed = torch.linalg.vector_norm(velocity, dim=-1)
    direction = velocity/foot_speed[:, :, None].clamp_min(1.e-6)
    if angular_command_threshold is not None:
      # Linear activity is in m/s; angular activity is independently in rad/s.
      # Foot geometry sets the target size, not the global command deadband.
      moving = (speed > command_threshold) | (command[:, 2].abs() > angular_command_threshold)
      active_mask = moving[:, None] & (foot_speed > 1.e-6)
  else:
    direction = translation/speed[:, None].clamp_min(1.e-6)
  if globals().get("_EXACT_PHASE_STEP_CLOCK", False):
    phase = torch.remainder(fixed_step_phase_cycles(env, period_s, position.dtype)[:, None] + torch.as_tensor(phase_offsets, device=position.device, dtype=position.dtype)[None], 1.)
  else:
    phase = torch.remainder(env.episode_length_buf[:, None]*env.step_dt/period_s +
                            torch.as_tensor(phase_offsets, device=position.device, dtype=position.dtype)[None], 1.)
  key = (asset_cfg.name, repr(asset_cfg.site_ids), sensor_name, period_s, tuple(phase_offsets),
         swing_fraction, command_threshold, force_threshold, target_step_ratio, max_target_advance,
         advance_std, dense_weight, aggregation, minimum_reference_feet, forward_axis_index, forward_axis_sign, command_mode,
         point_source, tuple(foot_geom_names or []), exclude_swing_references, straight_body_frame)
  if minimum_target_advance > 0:
    key = (*key, minimum_target_advance, minimum_target_reference_speed)
  if angular_command_threshold is not None:
    key = (*key, "angular_command_threshold", angular_command_threshold)
  cache = getattr(env, "_stackforce_swing_advance_states", None)
  if cache is None:
    cache = {}; env._stackforce_swing_advance_states = cache
  if key not in cache:
    cache[key] = SwingAdvanceMemory(period_s, swing_fraction, force_threshold, target_step_ratio,
                                    max_target_advance, advance_std, dense_weight, aggregation,
                                    minimum_reference_feet, command_threshold, exclude_swing_references)
  if active_mask is None:
    support_cost = cache[key].update(position, force, command[:, :3], direction, phase, env.episode_length_buf, foot_speed)
  else:
    support_cost = cache[key].update(position, force, command[:, :3], direction, phase, env.episode_length_buf, foot_speed, active_mask)
  if not straight_body_frame:
    return support_cost
  # Full body axis, including roll/pitch, as used by horizontal-stride reward.
  ex = torch.stack((1-2*(y*y+z*z), 2*(x*y+w*z), 2*(x*z-w*y)), dim=-1)
  ey = torch.stack((2*(x*y-w*z), 1-2*(x*x+z*z), 2*(y*z+w*x)), dim=-1)
  axis = (ex if forward_axis_index == 0 else ey)*forward_axis_sign
  body_x = ((position-asset.data.root_link_pos_w[:, None, :])*axis[:, None, :]).sum(-1)
  body_cache = getattr(env, "_stackforce_body_swing_advance_states", None)
  if body_cache is None:
    body_cache = {}; env._stackforce_body_swing_advance_states = body_cache
  if key not in body_cache:
    body_cache[key] = BodySwingAdvanceMemory(period_s, swing_fraction, force_threshold,
      target_step_ratio, max_target_advance, advance_std, dense_weight, aggregation, command_threshold,
      minimum_target_advance, minimum_target_reference_speed)
  body_cost = body_cache[key].update(body_x, force, command[:, :3], phase, env.episode_length_buf)
  straight = ((command[:, 0].abs() > command_threshold) &
              (command[:, 1] == 0) & (command[:, 2] == 0))
  result = torch.where(straight, body_cost, support_cost)
  if not planar_body_frame:
    return result
  # Reward-only extension: project full body XY onto the straight command.
  # Keep X and all yaw paths byte-exact; raw commands remain in the new memory
  # so equal-speed direction switches cannot reuse an old phase anchor.
  unit = body/speed[:, None].clamp_min(1.e-9)
  planar_axis = ex*unit[:, 0, None] + ey*unit[:, 1, None]
  projected = ((position-asset.data.root_link_pos_w[:, None, :])*planar_axis[:, None, :]).sum(-1)
  planar_cache = getattr(env, "_stackforce_planar_body_swing_advance_states", None)
  if planar_cache is None:
    planar_cache = {}; env._stackforce_planar_body_swing_advance_states = planar_cache
  if key not in planar_cache:
    planar_cache[key] = BodySwingAdvanceMemory(period_s, swing_fraction, force_threshold,
      target_step_ratio, max_target_advance, advance_std, dense_weight, aggregation, command_threshold,
      minimum_target_advance, minimum_target_reference_speed, planar_straight=True)
  planar_cost = planar_cache[key].update(projected, force, command[:, :3], phase, env.episode_length_buf)
  planar = (speed > command_threshold) & (command[:, 1] != 0) & (command[:, 2] == 0)
  return torch.where(planar, planar_cost, result)


def resolved_stride_cycle_targets(env, sample, command, minimums, spread_limit,
                                  direction_minimums, direction_limits, command_limits):
  count=sample.shape[1]
  key=(tuple(minimums),spread_limit,tuple(tuple(v) for v in direction_minimums),
       tuple(direction_limits),tuple(command_limits),sample.device,sample.dtype)
  cache=getattr(env,'_stackforce_stride_cycle_target_table',None)
  if cache is None or cache[0]!=key:
    import math
    def vector(values,size,positive=False):
      if len(values)!=size or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or (v<1.e-6 if positive else v<0) or v>1.e3 for v in values):
        raise ValueError('Invalid finite stride target table')
    vector(minimums,count,True);vector([spread_limit],1)
    if len(direction_minimums)!=6:raise ValueError('Six signed stride directions required')
    for row in direction_minimums:vector(row,count,True)
    vector(direction_limits,6);vector(command_limits,6,True)
    base=sample.new_tensor([list(minimums)+[spread_limit]])
    rows=sample.new_tensor([list(row)+[limit] for row,limit in zip(direction_minimums,direction_limits)])
    scales=sample.new_tensor(command_limits)
    cache=(key,base,rows,scales);env._stackforce_stride_cycle_target_table=cache
  _,base,rows,scales=cache
  weights=torch.stack((command.clamp_min(0),(-command).clamp_min(0)),dim=-1).flatten(1)/scales
  total=weights.sum(-1,keepdim=True)
  goals=torch.where(total>0,weights@rows/total.clamp_min(1.e-9),base)
  # L1 blend of normalized signed axes; cap amplitude at configured endpoints.
  # Spread is dimensionless and does not shrink with speed. Stop gating remains
  # in the stride memories; a tiny positive denominator only prevents 0/0.
  minimum=(goals[:,:count]*total.clamp(max=1)).clamp_min(1.e-6)
  return minimum,goals[:,count],key


def remember_stride_cycle_targets(state, minimum, limit, boundary, completed):
  if minimum.ndim!=2 or limit.shape!=minimum.shape[:1] or boundary.shape!=minimum.shape or completed.shape!=minimum.shape:
    raise ValueError('Mapped stride cycle target shapes must match feet')
  if 'mapped_goal' not in state:
    state['mapped_goal']=minimum.clone();state['mapped_last_goal']=minimum.clone()
    state['mapped_limit']=limit[:,None].expand_as(minimum).clone()
    state['mapped_last_limit']=state['mapped_limit'].clone()
  state['mapped_last_goal']=torch.where(completed,state['mapped_goal'],state['mapped_last_goal'])
  state['mapped_last_limit']=torch.where(completed,state['mapped_limit'],state['mapped_last_limit'])
  state['mapped_goal']=torch.where(boundary,minimum,state['mapped_goal'])
  state['mapped_limit']=torch.where(boundary,limit[:,None],state['mapped_limit'])


def mapped_completed_stride_cost(state, value, known, symmetry_weight, maximum_ratio=None):
  deficit=torch.relu(1-value/state['mapped_last_goal'])*known
  floor=deficit.amax(-1)
  spread=(value.amax(-1)-value.amin(-1))/value.abs().mean(-1).clamp_min(1.e-6)
  symmetry=torch.relu(spread-state['mapped_last_limit'].mean(-1))*known.all(-1)
  cost=floor+symmetry_weight*symmetry
  if maximum_ratio is not None:
    if isinstance(maximum_ratio,bool) or not isinstance(maximum_ratio,(int,float)) or not 1. <= maximum_ratio <= 4.:
      raise ValueError('Mapped stride maximum ratio must be finite and in [1,4]')
    # Each bound stays paired with the measured completed cycle's own goal.
    # Penalize excessive raw diameter, without clipping the measurement or
    # letting one foot's shortfall cancel another foot's overshoot.
    overshoot=torch.relu(value/(state['mapped_last_goal']*maximum_ratio)-1)*known
    cost=cost+overshoot.amax(-1)
  return cost


class TurnStrideMemory:
  """Full-cycle XY support diameter, plus qualified air (never support-frame net).

  Sixteen unoriented axes give cos(pi/32)*D <= estimate <= exact XY diameter D.
  The <0.482% conservative approximation is training feedback only. The native
  evaluator retains exact pairwise diameter and actual contact rhythm separately.
  No historical policy, trace or robot-specific reference enters this memory.
  """
  def __init__(self, period_s, swing_fraction, target_ratio, tolerance, symmetry_weight,
               force_threshold, angular_threshold, minimum, reference_yaw,
               minimum_air_seconds, minimum_air_height, maximum_air_fraction,
               air_weight):
    if any(not 0 < v < float('inf') for v in (period_s,target_ratio,tolerance,force_threshold,angular_threshold,minimum,reference_yaw)):
      raise ValueError('Turn stride parameters must be finite and positive')
    if any(not 0 <= v < float('inf') for v in (symmetry_weight,minimum_air_seconds,minimum_air_height,maximum_air_fraction,air_weight)) or maximum_air_fraction > 1:
      raise ValueError('Invalid turn stride air or symmetry parameters')
    if not 0 < swing_fraction < 1:
      raise ValueError('Turn stride swing fraction must be in (0,1)')
    self.period,self.swing,self.ratio,self.tolerance=period_s,swing_fraction,target_ratio,tolerance
    self.symmetry,self.force_threshold=symmetry_weight,force_threshold
    self.angular_threshold,self.minimum,self.reference_yaw=angular_threshold,minimum,reference_yaw
    self.air_seconds,self.air_height,self.air_fraction,self.air_weight=minimum_air_seconds,minimum_air_height,maximum_air_fraction,air_weight
    self.state=None

  def update(self, xy, force, height, phase, command, ticks, dt, cycle_minimum=None, cycle_spread_limit=None, cycle_maximum_ratio=None):
    if xy.ndim != 3 or xy.shape[-1] != 2 or force.shape != xy.shape[:2] or height.shape != force.shape or phase.shape != force.shape or command.shape != (xy.shape[0],3) or ticks.shape != (xy.shape[0],) or not 0 < dt < float('inf'):
      raise ValueError('Turn stride shapes and physical dt must agree')
    if self.state is None:
      angles=torch.arange(16,device=xy.device,dtype=xy.dtype)*(torch.pi/16)
      self.axes=torch.stack((angles.cos(),angles.sin()),dim=-1)
      projection=xy@self.axes.T
      flags=torch.zeros_like(force,dtype=torch.bool)
      self.state=dict(ticks=torch.full_like(ticks,-1),command=command.clone(),phase=phase.clone(),
          low=projection.clone(),high=projection.clone(),started=flags.clone(),known=flags.clone(),
          excursion=torch.zeros_like(force),target=torch.ones_like(force),last_target=torch.ones_like(force),
          previous_force=force.clone(),air=flags.clone(),air_tick=torch.zeros_like(force,dtype=torch.long),
          peak=torch.zeros_like(force),qualified_cycle=flags.clone(),last_qualified=flags.clone(),
          result=torch.zeros_like(ticks,dtype=xy.dtype))
    s=self.state
    active=command[:,2].abs()>=self.angular_threshold
    changed=(command-s['command']).abs().amax(-1)>1.e-3
    fresh=(ticks!=s['ticks'])|changed
    reset=(ticks<s['ticks'])|(s['ticks']<0)|changed|~active
    mask=fresh[:,None]
    resetfoot=reset[:,None]&mask
    start=(phase<s['phase'])&~reset[:,None]&mask
    projection=xy@self.axes.T
    measured=(s['high']-s['low']).amax(-1)
    completed=start&s['started']
    s['excursion']=torch.where(completed,measured,torch.where(resetfoot,0.,s['excursion']))
    s['last_target']=torch.where(completed,s['target'],s['last_target'])
    s['last_qualified']=torch.where(completed,s['qualified_cycle'],s['last_qualified'])&~resetfoot
    s['known']=(s['known']|completed)&~resetfoot
    s['started']=(s['started']|start)&~resetfoot
    boundary=start|resetfoot
    if cycle_minimum is not None:
      remember_stride_cycle_targets(s,cycle_minimum,cycle_spread_limit,boundary,completed)
    new_low=torch.where(boundary[...,None],projection,torch.minimum(s['low'],projection))
    new_high=torch.where(boundary[...,None],projection,torch.maximum(s['high'],projection))
    s['low']=torch.where(mask[...,None],new_low,s['low'])
    s['high']=torch.where(mask[...,None],new_high,s['high'])
    # Command v + omega cross foot radius, in the same physical body XY frame.
    tangent=command[:,None,:2]+command[:,None,2,None]*torch.stack((-xy[...,1],xy[...,0]),dim=-1)
    floor=self.minimum*(command[:,2].abs()/self.reference_yaw).clamp(0.,1.)
    target=torch.maximum(tangent.norm(dim=-1)*self.period*self.ratio,floor[:,None]).clamp_min(1.e-6)
    s['target']=torch.where(boundary,target,s['target'])
    unloaded=force<=self.force_threshold
    takeoff=unloaded&(s['previous_force']>self.force_threshold)&~reset[:,None]&mask
    air=(s['air']|takeoff)&~resetfoot
    s['air_tick']=torch.where(takeoff,ticks[:,None],s['air_tick'])
    s['peak']=torch.where(takeoff,height,torch.where(air,torch.maximum(s['peak'],height),s['peak']))
    duration=(ticks[:,None]-s['air_tick'])*dt
    touchdown=air&~unloaded&mask
    qualified=touchdown&(duration>=self.air_seconds)&(s['peak']>=self.air_height)
    if self.air_fraction>0:
      qualified&=duration<=self.period*self.air_fraction
      air&=duration<=self.period*self.air_fraction
    s['qualified_cycle']=((s['qualified_cycle']&~boundary)|qualified)&~resetfoot
    s['air']=air&~touchdown
    normalized=s['excursion']/s['last_target'].clamp_min(1.e-6)
    shortfall=torch.relu(1-self.tolerance-normalized)*s['known']
    # A low-error foot cannot compensate a deficient mapped foot.
    cost=shortfall.amax(-1)
    ratios=torch.maximum(normalized,torch.ones_like(normalized))
    spread=torch.relu(ratios.amax(-1)-ratios.amin(-1)-self.tolerance)*s['known'].all(-1)
    cost=cost+self.symmetry*spread
    if cycle_minimum is not None:
      cost=mapped_completed_stride_cost(s,s['excursion'],s['known'],self.symmetry,cycle_maximum_ratio)
    missing_air=(s['known']&~s['last_qualified']).to(xy.dtype).mean(-1)
    cost=cost+self.air_weight*missing_air
    current=(s['high']-s['low']).amax(-1)/s['target'].clamp_min(1.e-6)
    progress=(phase/self.swing).clamp(0.,1.)
    dense=(torch.relu(progress-current)*s['started']).amax(-1)
    cost=(cost+.25*dense)*active
    s['result']=torch.where(fresh,cost,s['result'])
    s['ticks']=ticks.clone();s['command']=command.clone();s['phase']=phase.clone();s['previous_force']=force.clone()
    return s['result'].clone()


class HorizontalStrideMemory:
  def __init__(self, period_s, swing_fraction, min_excursion, target_ratio,
               relative_tolerance, symmetry_weight, force_threshold,
               command_threshold, lateral_threshold, yaw_threshold,
               min_excursion_reference_speed=0., minimum_air_seconds=0.,
               minimum_air_height=0., maximum_air_fraction=0., actual_air_weight=1.,
               symmetry_floor_at_target=False, symmetry_floor_reference="target", actual_air_dense_weight=0.,
               actual_air_dense_aggregation="mean", actual_air_shortfall_cost="squared", actual_air_shortfall_aggregation="mean", actual_air_dense_linear_weight=0., actual_air_backtracking_weight=1., actual_air_completed_backtracking_weight=0., planar_straight=False, actual_air_completed_floor_weight=1., cycle_shortfall_aggregation="mean"):
    values = (period_s, min_excursion, target_ratio, relative_tolerance, symmetry_weight,
              force_threshold, command_threshold, lateral_threshold, yaw_threshold)
    if any(not 0 < value < float('inf') for value in values) or not 0 < swing_fraction < 1:
      raise ValueError('Horizontal stride parameters must be finite and positive')
    self.period_s, self.swing_fraction = period_s, swing_fraction
    self.min_excursion, self.target_ratio = min_excursion, target_ratio
    self.relative_tolerance, self.symmetry_weight = relative_tolerance, symmetry_weight
    self.force_threshold, self.command_threshold = force_threshold, command_threshold
    self.lateral_threshold, self.yaw_threshold = lateral_threshold, yaw_threshold
    if not 0 <= min_excursion_reference_speed < float('inf'):
      raise ValueError('Stride reference speed must be finite and nonnegative')
    self.reference_speed = min_excursion_reference_speed
    if any(not 0 <= v < float('inf') for v in (minimum_air_seconds, minimum_air_height, maximum_air_fraction)) or maximum_air_fraction > 1:
      raise ValueError('Invalid qualified-air duration or height filter')
    self.minimum_air_seconds = minimum_air_seconds
    self.minimum_air_height = minimum_air_height
    self.maximum_air_fraction = maximum_air_fraction
    self.filter_air = any(v > 0 for v in (minimum_air_seconds, minimum_air_height, maximum_air_fraction))
    if isinstance(actual_air_dense_weight, bool) or not 0 <= actual_air_dense_weight < float('inf'):
      raise ValueError('Actual air dense weight must be finite and nonnegative')
    if actual_air_dense_weight > 0 and not all(v > 0 for v in (minimum_air_seconds, minimum_air_height, maximum_air_fraction)):
      raise ValueError('Actual air dense feedback requires qualified air duration, height and expiry filters')
    self.actual_air_dense_weight = actual_air_dense_weight
    if isinstance(actual_air_dense_linear_weight, bool) or not isinstance(actual_air_dense_linear_weight, (int, float)) or not 0 <= actual_air_dense_linear_weight < float('inf'):
      raise ValueError('Actual air dense linear weight must be finite and nonnegative')
    if actual_air_dense_linear_weight > 0 and actual_air_dense_weight <= 0:
      raise ValueError('Actual air dense linear weight requires enabled qualified dense feedback')
    self.actual_air_dense_linear_weight = actual_air_dense_linear_weight
    if isinstance(actual_air_backtracking_weight, bool) or not isinstance(actual_air_backtracking_weight, (int, float)) or not 1 <= actual_air_backtracking_weight < float('inf'):
      raise ValueError('Actual air backtracking weight must be finite and at least one')
    if actual_air_backtracking_weight > 1 and actual_air_dense_weight <= 0:
      raise ValueError('Extra air backtracking cost requires qualified dense feedback')
    self.actual_air_backtracking_weight = actual_air_backtracking_weight
    if isinstance(actual_air_completed_backtracking_weight, bool) or not isinstance(actual_air_completed_backtracking_weight, (int, float)) or not 0 <= actual_air_completed_backtracking_weight < float('inf'):
      raise ValueError('Completed air backtracking weight must be finite and nonnegative')
    if actual_air_completed_backtracking_weight > 0 and actual_air_dense_weight <= 0:
      raise ValueError('Completed air backtracking cost requires qualified dense feedback')
    self.actual_air_completed_backtracking_weight = actual_air_completed_backtracking_weight
    if not isinstance(planar_straight, bool):
      raise ValueError('Planar straight stride flag must be boolean')
    self.planar_straight = planar_straight
    if isinstance(actual_air_completed_floor_weight, bool) or not isinstance(actual_air_completed_floor_weight, (int, float)) or not 1 <= actual_air_completed_floor_weight <= 16:
      raise ValueError('Completed actual-air floor weight must be finite in [1,16]')
    self.actual_air_completed_floor_weight = actual_air_completed_floor_weight
    self._completed_memo = None
    if actual_air_dense_aggregation not in ("mean", "worst_valid"):
      raise ValueError('Unknown actual-air dense aggregation')
    self.actual_air_dense_aggregation = actual_air_dense_aggregation
    if actual_air_shortfall_cost not in ("squared", "linear"):
      raise ValueError("Unknown actual-air shortfall cost")
    self.actual_air_shortfall_cost = actual_air_shortfall_cost
    if actual_air_shortfall_aggregation not in ("mean", "worst_valid"):
      raise ValueError("Unknown actual-air shortfall aggregation")
    self.actual_air_shortfall_aggregation = actual_air_shortfall_aggregation
    if cycle_shortfall_aggregation not in ("mean", "worst_valid"):
      raise ValueError("Unknown completed-cycle shortfall aggregation")
    self.cycle_shortfall_aggregation = cycle_shortfall_aggregation
    if isinstance(actual_air_weight, bool) or not 0 <= actual_air_weight < float('inf'):
      raise ValueError('Actual air weight must be finite and nonnegative')
    self.actual_air_weight = actual_air_weight
    if not isinstance(symmetry_floor_at_target, bool):
      raise ValueError('Target-floor symmetry flag must be boolean')
    if symmetry_floor_reference not in ("target", "minimum"):
      raise ValueError("Unknown symmetry floor reference")
    self.symmetry_floor_reference = symmetry_floor_reference
    self.symmetry_floor_at_target = symmetry_floor_at_target
    self.state = None

  def update(self, x, force, phase, command, ticks, heights=None, step_dt=0., unique_sample_token=None, cycle_minimum=None, cycle_spread_limit=None, cycle_maximum_ratio=None):
    if x.ndim != 2 or x.shape != phase.shape or x.shape != force.shape or command.shape != (x.shape[0],3):
      raise ValueError('Stride positions, forces, phases and command shapes must match')
    if self.filter_air and (not 0 < step_dt < float('inf') or (self.minimum_air_height > 0 and heights is None)):
      raise ValueError('Qualified air needs the actual control dt and requested sole heights')
    if heights is not None and heights.shape != x.shape:
      raise ValueError('Stride sole heights must match foot positions')
    height = torch.zeros_like(x) if heights is None else heights
    # Opt-in event feedback must survive repeated reward queries at one tick.
    # Preserve the legacy update path and cache arithmetic when disabled.
    duplicate = None
    saved = None
    # The physics collector already rejects duplicate/missing global callbacks.
    # A verified Python token avoids two CUDA->host boolean synchronizations and
    # unused memo copies per millisecond. Ordinary callers retain the old guard.
    if unique_sample_token is not None:
      previous_token = getattr(self, '_unique_sample_token', None)
      if isinstance(unique_sample_token, bool) or not isinstance(unique_sample_token, int) or (previous_token is not None and unique_sample_token != previous_token + 1):
        raise RuntimeError('Stride unique sampling tokens must be consecutive integers')
      self._unique_sample_token = unique_sample_token
    if unique_sample_token is None and self.actual_air_completed_backtracking_weight > 0 and self._completed_memo is not None:
      memo = self._completed_memo
      duplicate = (ticks == memo['ticks'])
      for name, value in (('x',x),('force',force),('phase',phase),('command',command),('height',height)):
        duplicate &= (value == memo[name]).all(-1)
      if step_dt != memo['step_dt']:
        duplicate &= False
      if duplicate.all():
        return memo['result'].clone()
      if duplicate.any():
        saved = {name:value.clone() for name,value in self.state.items()}
    directional_command = command[:,0]
    if self.planar_straight:
      directional_command = torch.where(command[:,1].abs()>self.lateral_threshold,
          torch.linalg.vector_norm(command[:,:2],dim=-1),directional_command)
    active=(directional_command.abs() >= self.command_threshold) & ((command[:,1].abs() <= self.lateral_threshold) | self.planar_straight) & (command[:,2].abs() <= self.yaw_threshold)
    if self.state is None:
      flags=torch.zeros_like(x,dtype=torch.bool)
      self.state=dict(ticks=torch.full_like(ticks,-1),command=command.clone(),previous=x.clone(),
          phase=phase.clone(),minimum=x.clone(),maximum=x.clone(),cycle_started=flags.clone(),
          range=torch.zeros_like(x),range_valid=flags.clone(),swing_started=flags.clone(),
          anchor=x.clone(),net=torch.zeros_like(x),net_valid=flags.clone(),
          previous_force=force.clone(),air=flags.clone(),air_anchor=x.clone(),landed_cycle=flags.clone(),
          previous_height=height.clone(),air_peak=height.clone(),air_start_tick=torch.zeros_like(x,dtype=torch.long))
      if self.actual_air_dense_weight > 0:
        self.state['air_max_advance']=torch.zeros_like(x)
    s=self.state
    changed=(command-s['command']).abs().amax(-1)>1.e-3
    reset=(ticks<s['ticks']) | (ticks==0) | changed | ~active
    valid=~reset[:,None]
    for name in ('cycle_started','range_valid','swing_started','net_valid','air','landed_cycle'):
      s[name] &= valid
    start=(phase<s['phase']) & valid
    if cycle_minimum is not None:
      remember_stride_cycle_targets(s,cycle_minimum,cycle_spread_limit,start|~valid,start&s['cycle_started'])
    s['landed_cycle'] &= ~start
    s['range']=torch.where(start & s['cycle_started'],s['maximum']-s['minimum'],s['range'])
    s['range_valid'] |= start & s['cycle_started']
    s['minimum']=torch.where(start | ~valid,x,torch.minimum(s['minimum'],x))
    s['maximum']=torch.where(start | ~valid,x,torch.maximum(s['maximum'],x))
    s['cycle_started'] |= start
    # Actual contact transitions can precede the ideal phase by one control tick.
    # Gate the takeoff window, then preserve the anchor through actual touchdown.
    window=(phase<self.swing_fraction) | (phase>.8)
    unloaded=force<=self.force_threshold
    takeoff=unloaded & (s['previous_force']>self.force_threshold) & window & valid
    s['air_anchor']=torch.where(takeoff,s['previous'],s['air_anchor'])
    s['air'] |= takeoff
    landed=~unloaded & s['air'] & valid
    net=(x-s['air_anchor'])*torch.sign(directional_command[:,None])
    qualified=landed
    if self.filter_air:
      s['air_start_tick']=torch.where(takeoff,ticks[:,None]-1,s['air_start_tick'])
      s['air_peak']=torch.where(takeoff,torch.maximum(s['previous_height'],height),
                                torch.where(s['air'],torch.maximum(s['air_peak'],height),s['air_peak']))
      duration=(ticks[:,None]-s['air_start_tick']).to(x.dtype)*step_dt
      qualified=landed & (duration >= self.minimum_air_seconds-1.e-7)
      if self.minimum_air_height > 0:
        qualified &= s['air_peak'] > self.minimum_air_height
      if self.maximum_air_fraction > 0:
        qualified &= duration <= self.period_s*self.maximum_air_fraction+1.e-7
      # A rejected micro-contact must not overwrite a real stroke. If no
      # qualified stroke exists this cycle, it must not retain an older success.
      rejected=landed & ~qualified & ~s['landed_cycle']
      expired=(s['air'] & ~s['landed_cycle'] & valid &
               (duration > self.period_s*self.maximum_air_fraction+1.e-7)) if self.maximum_air_fraction > 0 else torch.zeros_like(landed)
      s['net']=torch.where(rejected | expired,0.,s['net'])
      s['net_valid'] |= rejected | expired
    if self.actual_air_dense_weight > 0:
      # Physical takeoff, not the ideal phase boundary, starts this reward clock.
      # Include the landing sample before clearing air; qualify ongoing strokes
      # with the same duration/sole-height/expiry filters as actual-air metrics.
      s['air_max_advance']=torch.where(takeoff,torch.relu(net),
          torch.where(s['air'],torch.maximum(s['air_max_advance'],net),s['air_max_advance']))
      dense_valid=(s['air'] & valid & (duration >= self.minimum_air_seconds-1.e-7) &
          (s['air_peak'] > self.minimum_air_height) &
          (duration <= self.period_s*self.maximum_air_fraction+1.e-7))
    s['net']=torch.where(qualified,net,s['net'])
    s['net_valid'] |= qualified
    s['landed_cycle'] |= qualified
    s['air'] &= ~landed
    # No air phase is a real failure, not a missing value with zero cost.
    end=(phase>=self.swing_fraction) & (s['phase']<self.swing_fraction) & valid
    no_lift=end & s['cycle_started'] & ~s['landed_cycle'] & ~s['air']
    s['net']=torch.where(no_lift,0.,s['net']);s['net_valid'] |= no_lift
    speed=directional_command.abs()
    # Opt-in command-scaled floor: a slow command cannot be required to take
    # the same fixed stroke as the reference speed. Zero preserves legacy jobs.
    floor_scale=(speed/self.reference_speed).clamp(max=1.) if self.reference_speed > 0 else torch.ones_like(speed)
    minimum=(self.min_excursion*floor_scale).clamp_min(1.e-6)
    target=torch.maximum(speed*self.period_s*(1-self.swing_fraction)*self.target_ratio,minimum)
    result=torch.zeros_like(target)
    if self.actual_air_dense_weight > 0:
      # Privileged reward only. No foot trajectory, actor feedback, plant state
      # or deployment observer is changed. Shortfall encourages useful advance;
      # backtracking exposes withdrawal before actual touchdown. The completed
      # stroke and cycle objectives below retain their original target/floors.
      progress=(duration/(self.period_s*self.swing_fraction)).clamp(0.,1.)
      shortfall=torch.relu(target[:,None]*progress-net)/target[:,None]
      backtracking=torch.relu(s['air_max_advance']-net)/target[:,None]
      per_foot=(shortfall.square()+backtracking.square())*dense_valid
      if self.actual_air_backtracking_weight != 1.:
        # Optional reward-only emphasis on advance withdrawn before physical
        # touchdown. Keep the original useful-stroke shortfall, qualified-air
        # detector, caches and legacy arithmetic unchanged at the default one.
        per_foot += (self.actual_air_backtracking_weight-1.)*backtracking.square()*dense_valid
      if self.actual_air_dense_linear_weight > 0:
        # Optional finishing sensitivity on the same qualified physical air.
        # Retain every squared term, measurement and validity rule; this only
        # adds nonnegative cost. The zero default is bit-exact legacy behavior.
        per_foot += self.actual_air_dense_linear_weight*(shortfall+backtracking)*dense_valid
      if self.actual_air_dense_aggregation == "worst_valid":
        # Prioritize the weakest currently qualified air stroke. Preserve the
        # legacy mean when qualified costs are equal, including a single air
        # foot; do not multiply the cost merely because two feet are airborne.
        dense=per_foot.amax(-1)*dense_valid.to(x.dtype).mean(-1)
      else:
        dense=per_foot.mean(-1)
      result += self.actual_air_weight*self.actual_air_dense_weight*dense
      if self.actual_air_completed_backtracking_weight > 0:
        # Extra withdrawal cost is settled only at a qualified physical landing.
        # Mid-air reversals that recover before touchdown incur no extra cost.
        # Existing dense, useful-stroke and symmetry terms remain unchanged.
        completed = (backtracking.square()*qualified).mean(-1)
        result += self.actual_air_weight*self.actual_air_completed_backtracking_weight*completed
    for kind,value,known in (('range',s['range'],s['range_valid']),('net',s['net'],s['net_valid'])):
      if kind == 'range' and cycle_minimum is not None:
        result += mapped_completed_stride_cost(s,value,known,self.symmetry_weight,cycle_maximum_ratio)
        continue
      shortfall=torch.relu(target[:,None]-value)/target[:,None]
      # Optional finishing feedback for the completed physical air stroke.
      # Keep cycle/dense costs and all raw measurements/validity unchanged.
      # Linear cost retains sensitivity near the target; squared is legacy.
      penalty = shortfall if kind == 'net' and self.actual_air_shortfall_cost == "linear" else shortfall.square()
      if ((kind == "net" and self.actual_air_shortfall_aggregation == "worst_valid") or
          (kind == "range" and self.cycle_shortfall_aggregation == "worst_valid")):
        # A short leg cannot be compensated by lengthening another leg.
        # Preserve uniform-cost magnitude and ignore unobserved strokes.
        floor=(penalty*known).amax(-1)
      else:
        floor=(penalty*known).sum(-1)/known.sum(-1).clamp_min(1)
      # Reward shaping only: below-target legs must improve the shortfall
      # instead of competing with symmetry by shortening other short legs.
      # Preserve actual measured caches and the legacy arithmetic by default.
      # Keep the original target shortfall unchanged. Optional minimum floor
      # exposes inequality once all feet exceed the useful-stroke floor, even
      # when the command-derived ideal target is larger. Measurements stay raw.
      reference = minimum if self.symmetry_floor_reference == "minimum" else target
      symmetry_value = torch.maximum(value,reference[:,None]) if self.symmetry_floor_at_target else value
      spread=(symmetry_value.amax(-1)-symmetry_value.amin(-1))/torch.maximum(symmetry_value.abs().mean(-1),minimum)
      symmetry=torch.relu(spread-self.relative_tolerance)*known.all(-1)
      component = floor + self.symmetry_weight*symmetry
      if kind == "net" and self.actual_air_completed_floor_weight != 1.:
        # Optional emphasis ONLY on the already-qualified completed-NET deficit.
        # Keep raw measurements, validity, target, cycle/symmetry/dense/landing
        # terms and the default arithmetic unchanged. No actor inputs change.
        component += (self.actual_air_completed_floor_weight-1.)*floor
      # Opt-in relative emphasis; default path retains the exact legacy sum.
      if kind == 'net' and self.actual_air_weight != 1.:
        component = component*self.actual_air_weight
      result += component
    s.update(ticks=ticks.clone(),command=command.detach().clone(),previous=x.detach().clone(),
             phase=phase.clone(),previous_force=force.detach().clone(),previous_height=height.detach().clone())
    result = result*active
    if unique_sample_token is None and self.actual_air_completed_backtracking_weight > 0:
      if saved is not None:
        for name,value in s.items():
          mask=duplicate.reshape((duplicate.shape[0],)+(1,)*(value.ndim-1))
          s[name]=torch.where(mask,saved[name],value)
        result=torch.where(duplicate,self._completed_memo['result'],result)
      self._completed_memo=dict(ticks=ticks.clone(),x=x.detach().clone(),force=force.detach().clone(),
          phase=phase.detach().clone(),command=command.detach().clone(),height=height.detach().clone(),
          step_dt=step_dt,result=result.detach().clone())
    return result


def phase_foot_horizontal_stride(env, foot_geom_names, sensor_name, command_name,
                               period_s, phase_offsets, swing_fraction,
                               min_excursion, target_ratio, relative_tolerance,
                               symmetry_weight, force_threshold, command_threshold,
                               lateral_threshold, yaw_threshold,
                               min_excursion_reference_speed=0., minimum_air_seconds=0.,
                               minimum_air_height=0., maximum_air_fraction=0., actual_air_weight=1.,
                               symmetry_floor_at_target=False, symmetry_floor_reference="target", actual_air_dense_weight=0.,
                               actual_air_dense_aggregation="mean", actual_air_shortfall_cost="squared", actual_air_shortfall_aggregation="mean", actual_air_dense_linear_weight=0., actual_air_backtracking_weight=1., actual_air_completed_backtracking_weight=0., planar_straight=False, planar_straight_weight=1., actual_air_completed_floor_weight=1., forward_axis_index=0, forward_axis_sign=1., command_mode="translation", angular_command_threshold=.01, turn_min_excursion=.03, turn_reference_yaw_rate=.4, cycle_shortfall_aggregation="mean",
                               cycle_minimum_excursions=None, cycle_spread_limit=None,
                               direction_cycle_minimum_excursions=None, direction_cycle_spread_limits=None, cycle_command_limits=None, cycle_maximum_ratio=None):
  if command_mode not in ("translation", "planar_twist"):
    raise ValueError('Unknown stride command mode')
  if cycle_maximum_ratio is not None:
    if cycle_minimum_excursions is None or isinstance(cycle_maximum_ratio,bool) or not isinstance(cycle_maximum_ratio,(int,float)) or not 1. <= cycle_maximum_ratio <= 4.:
      raise ValueError('Cycle maximum ratio requires mapped minima and a finite ratio in [1,4]')
  if not isinstance(planar_straight, bool):
    raise ValueError('Planar straight stride flag must be boolean')
  if isinstance(planar_straight_weight, bool) or not isinstance(planar_straight_weight, (int, float)) or not 0. < planar_straight_weight <= 1.:
    raise ValueError('planar_straight_weight must be a finite number in (0, 1]')
  if planar_straight_weight != 1. and not planar_straight:
    raise ValueError('planar_straight_weight requires planar_straight=True')
  if forward_axis_index not in (0, 1) or forward_axis_sign not in (-1, 1):
    raise ValueError('Invalid horizontal stride command frame')
  robot=env.scene['robot']
  # Immutable mapping tensors are created once, not copied from Python lists
  # to CUDA on each of the twenty physics samples.
  geometry=getattr(env,'_stackforce_stride_geometry',None)
  geometry_key=(tuple(foot_geom_names),tuple(phase_offsets))
  if geometry is None or geometry[0] != geometry_key:
    local=[robot.geom_names.index(name) for name in foot_geom_names]
    indices=robot.indexing.geom_ids[torch.as_tensor(local,device=env.device,dtype=torch.long)]
    offsets=torch.as_tensor(phase_offsets,device=env.device,dtype=env.sim.data.geom_xpos.dtype)
    geometry=(geometry_key,indices,offsets);env._stackforce_stride_geometry=geometry
  world=env.sim.data.geom_xpos[:,geometry[1]]
  delta=world-robot.data.root_link_pos_w[:,None,:]
  w,x,y,z=robot.data.root_link_quat_w.unbind(-1)
  # Body x projection, including roll and pitch. Never world displacement.
  ex=torch.stack((1-2*(y*y+z*z),2*(x*y+w*z),2*(x*z-w*y)),dim=-1)
  body_x = ex
  if forward_axis_index == 1:
    ex=torch.stack((2*(x*y-w*z),1-2*(x*x+z*z),2*(y*z+w*x)),dim=-1)
  if forward_axis_sign == -1:
    ex=-ex
  position=(delta*ex[:,None,:]).sum(-1)
  command=env.command_manager.get_command(command_name)[:,:3]
  cycle_minimum,cycle_limit,cycle_key=None,None,None
  if cycle_minimum_excursions is not None:
    if command_mode!='planar_twist' or not planar_straight:
      raise ValueError('Mapped cycle stride requires planar_twist and planar_straight')
    if any(v is None for v in (cycle_spread_limit,direction_cycle_minimum_excursions,direction_cycle_spread_limits,cycle_command_limits)):
      raise ValueError('Mapped stride configuration must be complete')
    cycle_minimum,cycle_limit,cycle_key=resolved_stride_cycle_targets(env,position,command,cycle_minimum_excursions,
        cycle_spread_limit,direction_cycle_minimum_excursions,direction_cycle_spread_limits,cycle_command_limits)
  elif any(v is not None for v in (cycle_spread_limit,direction_cycle_minimum_excursions,direction_cycle_spread_limits,cycle_command_limits)):
    raise ValueError('Mapped stride minima are required')
  if planar_straight:
    # Project body XY onto a constant straight command. Preserve the exact
    # legacy arithmetic for X commands; yaw still disables equal-foot costs.
    ey=torch.stack((2*(x*y-w*z),1-2*(x*x+z*z),2*(y*z+w*x)),dim=-1)
    if forward_axis_index == 1:
      ey=body_x
    unit=command[:,:2]/torch.linalg.vector_norm(command[:,:2],dim=-1).clamp_min(1.e-9)[:,None]
    axis=ex*unit[:,0,None]+ey*unit[:,1,None]
    projected=(delta*axis[:,None,:]).sum(-1)
    position=torch.where((command[:,1].abs()>lateral_threshold)[:,None],projected,position)
  force=torch.linalg.vector_norm(env.scene[sensor_name].data.force,dim=-1)
  if globals().get("_EXACT_PHASE_STEP_CLOCK", False):
    phase = torch.remainder(fixed_step_phase_cycles(env, period_s, position.dtype)[:, None] + geometry[2].to(position.dtype)[None], 1.)
  else:
    phase=torch.remainder(env.episode_length_buf[:,None]*env.step_dt/period_s+
        geometry[2].to(position.dtype)[None],1.)
  key=(tuple(foot_geom_names),period_s,tuple(phase_offsets),swing_fraction,min_excursion,
       target_ratio,relative_tolerance,symmetry_weight,force_threshold,command_threshold,
       lateral_threshold,yaw_threshold,min_excursion_reference_speed,
       minimum_air_seconds,minimum_air_height,maximum_air_fraction,actual_air_weight,symmetry_floor_at_target,symmetry_floor_reference,actual_air_dense_weight,actual_air_dense_aggregation)
  if actual_air_shortfall_cost != "squared":
    key = (*key, actual_air_shortfall_cost)
  if actual_air_shortfall_aggregation != "mean":
    key = (*key, actual_air_shortfall_aggregation)
  if cycle_shortfall_aggregation != "mean":
    key = (*key, "cycle_shortfall_aggregation", cycle_shortfall_aggregation)
  if forward_axis_index != 0 or forward_axis_sign != 1:
    key = (*key, 'frame', forward_axis_index, forward_axis_sign)
  cache=getattr(env,'_stackforce_horizontal_stride',None)
  if cache is None:cache={};env._stackforce_horizontal_stride=cache
  if actual_air_dense_linear_weight != 0.:
    key = (*key, actual_air_dense_linear_weight)
  if actual_air_backtracking_weight != 1.:
    key = (*key, "actual_air_backtracking_weight", actual_air_backtracking_weight)
  if actual_air_completed_backtracking_weight != 0.:
    key = (*key, "actual_air_completed_backtracking_weight", actual_air_completed_backtracking_weight)
  if actual_air_completed_floor_weight != 1.:
    key = (*key, "actual_air_completed_floor_weight", actual_air_completed_floor_weight)
  if planar_straight:
    key = (*key, "planar_straight", True)
  if cycle_key is not None:
    key = (*key, "mapped_cycle_targets",cycle_key)
  if cycle_maximum_ratio is not None:
    key = (*key, "cycle_maximum_ratio",cycle_maximum_ratio)
  if key not in cache:
    cache[key]=HorizontalStrideMemory(period_s,swing_fraction,min_excursion,target_ratio,
        relative_tolerance,symmetry_weight,force_threshold,command_threshold,lateral_threshold,yaw_threshold,
        min_excursion_reference_speed,minimum_air_seconds,minimum_air_height,maximum_air_fraction,actual_air_weight,symmetry_floor_at_target,symmetry_floor_reference,actual_air_dense_weight,actual_air_dense_aggregation,actual_air_shortfall_cost,actual_air_shortfall_aggregation,actual_air_dense_linear_weight,actual_air_backtracking_weight,actual_air_completed_backtracking_weight,planar_straight,actual_air_completed_floor_weight,cycle_shortfall_aggregation)
  height=sphere_bottom_heights(env,foot_geom_names) if minimum_air_height > 0 else None
  cost=cache[key].update(position,force,phase,command,env.episode_length_buf,
                         heights=height,step_dt=env.step_dt,unique_sample_token=getattr(env,'_stackforce_unique_sample_token',None),cycle_minimum=cycle_minimum,cycle_spread_limit=cycle_limit,cycle_maximum_ratio=cycle_maximum_ratio)
  if command_mode == "planar_twist":
    ey=torch.stack((2*(x*y-w*z),1-2*(x*x+z*z),2*(y*z+w*x)),dim=-1)
    body_xy=torch.stack(((delta*body_x[:,None,:]).sum(-1),(delta*ey[:,None,:]).sum(-1)),dim=-1)
    turn_key=(tuple(foot_geom_names),period_s,swing_fraction,tuple(phase_offsets),target_ratio,relative_tolerance,
              symmetry_weight,force_threshold,angular_command_threshold,turn_min_excursion,turn_reference_yaw_rate,
              minimum_air_seconds,minimum_air_height,maximum_air_fraction,actual_air_weight)
    if cycle_key is not None:
      turn_key=(*turn_key,"mapped_cycle_targets",cycle_key)
    if cycle_maximum_ratio is not None:
      turn_key=(*turn_key,"cycle_maximum_ratio",cycle_maximum_ratio)
    turns=getattr(env,'_stackforce_turn_stride',None)
    if turns is None:turns={};env._stackforce_turn_stride=turns
    if turn_key not in turns:
      turns[turn_key]=TurnStrideMemory(period_s,swing_fraction,target_ratio,relative_tolerance,symmetry_weight,
          force_threshold,angular_command_threshold,turn_min_excursion,turn_reference_yaw_rate,
          minimum_air_seconds,minimum_air_height,maximum_air_fraction,actual_air_weight)
    if height is None:height=sphere_bottom_heights(env,foot_geom_names)
    body_command=command
    if forward_axis_index != 0 or forward_axis_sign != 1:
      body_command=command.clone()
      body_command[:,forward_axis_index]=command[:,0]*forward_axis_sign
      body_command[:,1-forward_axis_index]=command[:,1]
    turn=turns[turn_key].update(body_xy,force,height,phase,body_command,env.episode_length_buf,env.step_dt,cycle_minimum=cycle_minimum,cycle_spread_limit=cycle_limit,cycle_maximum_ratio=cycle_maximum_ratio)
    cost=cost+turn
  # Scale only opt-in Y/XY feedback after the shared raw memory result. Never
  # mutate the memoized result; queries with another weight use the same state.
  if planar_straight and planar_straight_weight != 1.:
    return torch.where(command[:,1].abs()>lateral_threshold, cost*planar_straight_weight, cost)
  return cost

import math

class CycleMeanVelocityMemory:
  """Window-mean tracking, with optional extra cost on zero-command axes.

  Existing instantaneous tracking terms still constrain within-cycle variance.
  This optional term makes a persistent directional bias visible separately.
  Resets, step gaps and command jumps clear the window; opt-in zero commands are tracked.
  Repeated evaluation at the same control step is idempotent per environment.
  """
  def __init__(self, dt, window_seconds, grace_seconds, linear_std, angular_std,
               command_threshold, command_change_threshold, off_axis_weight=0.,
               cost_mode="bounded_huber", track_zero_commands=False):
    for value in (dt, window_seconds, linear_std, angular_std):
      if isinstance(value, bool) or not math.isfinite(value) or value <= 0:
        raise ValueError("Cycle-mean tracking time/scales must be finite and positive")
    for value in (grace_seconds, command_threshold, command_change_threshold, off_axis_weight):
      if isinstance(value, bool) or not math.isfinite(value) or value < 0:
        raise ValueError("Cycle-mean tracking grace/thresholds/weights must be finite and nonnegative")
    if window_seconds > 10 or grace_seconds > 10:
      raise ValueError("Cycle-mean tracking window/grace cannot exceed10 seconds")
    self.window = max(1, math.ceil(window_seconds/dt-1.e-9))
    if self.window > 2048:
      raise ValueError("Cycle-mean tracking window exceeds2048 control steps")
    self.grace = max(0, math.ceil(grace_seconds/dt-1.e-9))
    self.linear_std, self.angular_std = linear_std, angular_std
    self.threshold = command_threshold
    self.change_threshold = command_change_threshold
    self.off_axis_weight = off_axis_weight
    if not isinstance(cost_mode, str) or cost_mode not in ("bounded_huber", "axis_log_huber", "axis_huber"):
      raise ValueError("Invalid cycle-mean tracking cost_mode")
    self.cost_mode = cost_mode
    if not isinstance(track_zero_commands, bool):
      raise ValueError("track_zero_commands must be boolean")
    self.track_zero_commands = track_zero_commands
    self.state = None

  def update(self, velocity, command, step):
    if velocity.ndim != 2 or velocity.shape[1] != 3 or command.shape != velocity.shape or step.shape != velocity.shape[:1]:
      raise ValueError("Cycle-mean tracking requires matching[N,3] velocities/commands and[N] steps")
    if step.dtype not in (torch.int32, torch.int64):
      raise ValueError("Cycle-mean tracking requires integer control steps")
    n = velocity.shape[0]
    if self.state is None:
      integer = torch.zeros_like(step)
      self.state = {
        "buffer": velocity.new_zeros((n, self.window, 3)),
        "sum": torch.zeros_like(velocity), "command": torch.zeros_like(command),
        "cursor": integer.clone(), "count": integer.clone(), "age": integer.clone(),
        "step": torch.full_like(step, -1),
        "active": torch.zeros(n, device=velocity.device, dtype=torch.bool),
        "cost": velocity.new_zeros(n),
      }
    s = self.state
    if s["sum"].shape != velocity.shape or s["sum"].dtype != velocity.dtype or s["sum"].device != velocity.device:
      raise ValueError("Cycle-mean tracking batch/dtype/device changed")
    active = torch.linalg.vector_norm(command[:, :2], dim=-1)+command[:, 2].abs() > self.threshold
    if self.track_zero_commands:
      active = torch.ones_like(active)
    changed = (command-s["command"]).abs().amax(-1) > self.change_threshold
    duplicate = (step == s["step"]) & ~changed & (active == s["active"])
    clear = (~active | ~s["active"] | changed | (s["step"] < 0)
             | (step < s["step"]) | (step > s["step"]+1)) & ~duplicate
    s["sum"] = s["sum"].masked_fill(clear[:, None], 0)
    for key in ("cursor", "count", "age"):
      s[key] = s[key].masked_fill(clear, 0)
    new = active & ~duplicate
    rows = torch.arange(n, device=velocity.device)
    old = s["buffer"][rows, s["cursor"]]
    error = (velocity-command).detach()
    total = s["sum"]+error-old*(s["count"] >= self.window)[:, None]
    s["sum"] = torch.where(new[:, None], total, s["sum"])
    s["buffer"][rows, s["cursor"]] = torch.where(new[:, None], error, old)
    s["cursor"] = torch.where(new, (s["cursor"]+1) % self.window, s["cursor"])
    s["count"] = torch.where(new, (s["count"]+1).clamp_max(self.window), s["count"])
    s["age"] = torch.where(new, s["age"]+1, s["age"])
    scales = velocity.new_tensor([self.linear_std, self.linear_std, self.angular_std])
    normalized = (s["sum"]/self.window/scales).abs()
    per_axis_huber = torch.where(normalized <= 1, .5*normalized.square(), normalized-.5)
    huber = per_axis_huber.sum(-1)
    ready = active & (s["count"] >= self.window) & (s["age"] >= self.grace)
    # The opt-in logarithmic mode retains a signal for large persistent errors.
    # Separate axes prevent a large yaw error from hiding a forward-speed bias.
    # This is reward shaping, not a measured motor or sensor characteristic.
    if self.cost_mode == "axis_huber":
      # Opt-in linear tails retain a constant marginal penalty for persistent
      # large bias. This is an artificial training hypothesis, not a sensor
      # specification, a physical-state change or a relaxed acceptance gate.
      tracking = huber
    else:
      tracking = (torch.log1p(per_axis_huber).sum(-1) if self.cost_mode == "axis_log_huber"
                  else huber/(1.+huber))
    if self.off_axis_weight > 0:
      # Penalize persistent motion on uncommanded axes, while preserving
      # commanded motion and zero-mean within-cycle oscillations. Cap each
      # normalized squared error at25 so fall transients remain finite.
      uncommanded = command.abs() <= self.threshold
      off_axis = (normalized.clamp_max(5.).square()*uncommanded).sum(-1)
      tracking = tracking + self.off_axis_weight*off_axis
    cost = torch.where(ready, tracking, 0.)
    s["cost"] = torch.where(duplicate, s["cost"], cost)
    s["step"] = torch.where(duplicate, s["step"], step)
    s["command"] = torch.where(duplicate[:, None], s["command"], command.detach())
    s["active"] = active.clone()
    return s["cost"].clone()


class HeadingDeltaVelocityMemory:
  """Reward-only interval yaw rate, immune to control-boundary gyro aliasing.

  Uses privileged simulator orientation; never adds heading to actor inputs.
  A reset/gap/first sample cannot be paired with another episode. Duplicate
  reward reads at one control step return the cached value without advancing.
  """
  def __init__(self, dt):
    if isinstance(dt, bool) or not math.isfinite(dt) or dt <= 0:
      raise ValueError("Heading-delta dt must be finite and positive")
    self.dt = dt
    self.state = None

  def update(self, heading, step):
    if heading.ndim != 1 or step.shape != heading.shape or step.dtype not in (torch.int32, torch.int64):
      raise ValueError("Heading-delta needs matching[N] headings and integer steps")
    if self.state is None:
      self.state = dict(heading=heading.detach().clone(), step=step.clone(),
                        rate=torch.zeros_like(heading))
      return self.state["rate"].clone()
    s = self.state
    if s["heading"].shape != heading.shape or s["heading"].dtype != heading.dtype or s["heading"].device != heading.device:
      raise ValueError("Heading-delta batch/dtype/device changed")
    duplicate = step == s["step"]
    continuous = step == s["step"]+1
    delta = heading-s["heading"]
    rate = torch.atan2(torch.sin(delta), torch.cos(delta))/self.dt
    rate = torch.where(continuous, rate, torch.zeros_like(rate))
    s["rate"] = torch.where(duplicate, s["rate"], rate)
    s["heading"] = torch.where(duplicate, s["heading"], heading.detach())
    s["step"] = torch.where(duplicate, s["step"], step)
    return s["rate"].clone()


def cycle_mean_velocity_error(env, asset_cfg, command_name, window_seconds=.4,
                              grace_seconds=1., linear_std=.005, angular_std=.02,
                              command_threshold=1.e-6, command_change_threshold=.001,
                              forward_axis_index=0, forward_axis_sign=1., off_axis_weight=0.,
                              cost_mode="bounded_huber", angular_reference="body", track_zero_commands=False):
  if forward_axis_index not in (0, 1) or forward_axis_sign not in (-1, 1):
    raise ValueError("Invalid cycle-mean tracking forward axis")
  if not isinstance(angular_reference, str) or angular_reference not in ("body", "heading_delta"):
    raise ValueError("Invalid cycle-mean angular_reference")
  if not isinstance(track_zero_commands, bool):
    raise ValueError("track_zero_commands must be boolean")
  robot = env.scene[asset_cfg.name]
  linear = robot.data.root_link_lin_vel_b
  angular = robot.data.root_link_ang_vel_b
  yaw_rate = angular[:, 2]
  if angular_reference == "heading_delta":
    w, x, y, z = robot.data.root_link_quat_w.unbind(-1)
    heading = torch.atan2(2*(w*z+x*y), 1-2*(y.square()+z.square()))
    heading_cache = getattr(env, "_stackforce_cycle_heading_delta_states", None)
    if heading_cache is None:
      heading_cache = {}; env._stackforce_cycle_heading_delta_states = heading_cache
    heading_key = (asset_cfg.name, env.step_dt)
    if heading_key not in heading_cache:
      heading_cache[heading_key] = HeadingDeltaVelocityMemory(env.step_dt)
    yaw_rate = heading_cache[heading_key].update(heading, env.episode_length_buf)
  velocity = torch.stack((linear[:, forward_axis_index]*forward_axis_sign,
                          linear[:, 1-forward_axis_index], yaw_rate), dim=-1)
  command = env.command_manager.get_command(command_name)
  key = (asset_cfg.name, command_name, env.step_dt, window_seconds, grace_seconds,
         linear_std, angular_std, command_threshold, command_change_threshold,
         forward_axis_index, forward_axis_sign, off_axis_weight, cost_mode)
  if angular_reference != "body":
    key = key+(angular_reference,)
  key = key+(track_zero_commands,)
  cache = getattr(env, "_stackforce_cycle_mean_velocity_states", None)
  if cache is None:
    cache = {}; env._stackforce_cycle_mean_velocity_states = cache
  if key not in cache:
    cache[key] = CycleMeanVelocityMemory(env.step_dt, window_seconds, grace_seconds,
      linear_std, angular_std, command_threshold, command_change_threshold, off_axis_weight, cost_mode, track_zero_commands)
  return cache[key].update(velocity, command, env.episode_length_buf)

import math
import torch
from mjlab.managers.scene_entity_config import SceneEntityCfg


def track_planar_velocity(env, std, command_name, asset_cfg=SceneEntityCfg("robot"),
                          stop_std=0., lateral_std=0., separable_lateral=False,
                          forward_axis_index=None, forward_axis_sign=1.):
  if not math.isfinite(std) or std <= 0 or not math.isfinite(stop_std) or stop_std < 0 or not math.isfinite(lateral_std) or lateral_std < 0:
    raise ValueError("Velocity tolerances must be finite; moving std must be positive")
  if not isinstance(separable_lateral, bool):
    raise ValueError("separable_lateral must be boolean")
  command = env.command_manager.get_command(command_name)
  actual = env.scene[asset_cfg.name].data.root_link_lin_vel_b
  axis = 0 if forward_axis_index is None else forward_axis_index
  sign = 1. if forward_axis_index is None else forward_axis_sign
  forward_error = (command[:, 0] - actual[:, axis]*sign).square()
  lateral_error = (command[:, 1] - actual[:, 1-axis]).square()
  variance = torch.full_like(forward_error, std**2)
  if stop_std > 0:
    variance = torch.where(torch.all(command[:, :3] == 0, dim=1), stop_std**2, variance)
  lateral_variance = lateral_std**2 if lateral_std > 0 else variance
  if separable_lateral:
    return torch.exp(-forward_error/variance) + torch.exp(-lateral_error/lateral_variance) - 1.
  return torch.exp(-forward_error/variance-lateral_error/lateral_variance)


def track_yaw_velocity(env, std, command_name, asset_cfg=SceneEntityCfg("robot")):
  if not math.isfinite(std) or std <= 0:
    raise ValueError("Yaw tolerance must be finite and positive")
  command = env.command_manager.get_command(command_name)
  actual = env.scene[asset_cfg.name].data.root_link_ang_vel_b
  return torch.exp(-(command[:, 2]-actual[:, 2]).square()/std**2)

