"""Bounded-shared-memory contact sorting for the pinned MuJoCo Warp runtime.

MuJoCo Warp 3.11 allocates two tiles of maxmatch elements even when the
sensor's reduction does not sort. Large scene bounds therefore fail at kernel
compile time. Keep the upstream fast sort for small buffers; sort large buffers
in their existing global scratch storage without dropping any contact.
"""
import importlib.metadata

import warp as wp


@wp.kernel(module="unique", enable_backward=False)
def _global_contact_sort(
    sensor_intprm: wp.array2d[int],
    sensor_contact_adr: wp.array[int],
    sensor_contact_nmatch: wp.array2d[int],
    matchids: wp.array3d[int],
    criteria: wp.array3d[float],
    result: wp.array3d[int],
):
    world, sensor, lane = wp.tid()
    # launch_tiled assigns a block to each sensor. Only one lane owns its
    # in-place heap; no shared allocation, barriers, or inter-block races.
    if lane != 0:
        return
    reduction = sensor_intprm[sensor_contact_adr[sensor], 1]
    if reduction == 0 or reduction == 3:
        return
    # The unused suffix contains only upstream sentinels. Sorting actual matches
    # avoids O(capacity log capacity) work for sparse contacts in a large bound.
    # Neither the allocation nor the upstream overflow count is changed.
    count = matchids.shape[2]
    matched = sensor_contact_nmatch[world, sensor]
    if matched < count:
        count = matched
    if count <= 1:
        return
    for i in range(count):
        result[world, sensor, i] = matchids[world, sensor, i]
    # In-place heapsort: O(n log n), O(1) additional memory. Criteria are a
    # temporary upstream buffer discarded after sorting, safe to reorder.
    start = count // 2 - 1
    end = count - 1
    while end > 0:
        parent = int(0)
        if start >= 0:
            parent = start
            start -= 1
        else:
            key = criteria[world, sensor, end]
            value = result[world, sensor, end]
            criteria[world, sensor, end] = criteria[world, sensor, 0]
            result[world, sensor, end] = result[world, sensor, 0]
            criteria[world, sensor, 0] = key
            result[world, sensor, 0] = value
            end -= 1
        while parent * 2 + 1 <= end:
            child = parent * 2 + 1
            if child < end and criteria[world, sensor, child] < criteria[world, sensor, child + 1]:
                child += 1
            if criteria[world, sensor, parent] >= criteria[world, sensor, child]:
                break
            key = criteria[world, sensor, parent]
            value = result[world, sensor, parent]
            criteria[world, sensor, parent] = criteria[world, sensor, child]
            result[world, sensor, parent] = result[world, sensor, child]
            criteria[world, sensor, child] = key
            result[world, sensor, child] = value
            parent = child


def install_contact_sort():
    """Adapt only the verified dependency in memory, never installed files."""
    from mujoco_warp._src import sensor
    if getattr(sensor._contact_sort, "_simready_bounded_shared_memory", False):
        return
    if importlib.metadata.version("mujoco-warp") != "3.11.0":
        raise RuntimeError("Contact sorting adapter requires the verified mujoco-warp 3.11.0 runtime")
    original = sensor._contact_sort

    def contact_sort(capacity):
        # Two 4-byte tiles plus compiler overhead stay well below 48 KiB.
        return original(capacity) if capacity <= 2048 else _global_contact_sort

    contact_sort._simready_bounded_shared_memory = True
    sensor._contact_sort = contact_sort
