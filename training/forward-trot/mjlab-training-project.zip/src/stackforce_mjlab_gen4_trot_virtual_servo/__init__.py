from mjlab.tasks.registry import register_mjlab_task

from .env_cfgs import stackforce_env_cfg
from .rl_cfg import stackforce_ppo_runner_cfg
from .runner import StackForceVelocityOnPolicyRunner

register_mjlab_task(
  task_id="Mjlab-Velocity-Flat-Gen4TrotVirtualServo",
  env_cfg=stackforce_env_cfg(),
  play_env_cfg=stackforce_env_cfg(play=True),
  rl_cfg=stackforce_ppo_runner_cfg(),
  runner_cls=StackForceVelocityOnPolicyRunner,
)
