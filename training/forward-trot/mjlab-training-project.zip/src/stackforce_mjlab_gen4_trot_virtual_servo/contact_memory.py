"""Check final contact scratch requirements before MJLab allocates simulation data.

This is a lower bound, not a promise that the rest of training fits. In particular,
cached CUDA pool memory makes driver free-memory telemetry unsuitable as a hard
limit. Only an impossible request exceeding total device memory is rejected.
"""
import functools
import importlib.metadata
import inspect
import math
from types import FunctionType
from copy import copy


def contact_scratch_capacity(configured, global_contacts):
    # A sensor can match each stored contact at most once. The global contact
    # array (across ALL worlds, not nconmax per world) is a rigorous upper bound.
    # Keep power-of-two alignment required by the upstream tiled sort.
    upper = 1 << max(0, int(global_contacts) - 1).bit_length()
    return min(int(configured), upper)


def install_contact_scratch_bound():
    from mujoco_warp._src import sensor
    original = sensor.sensor_acc
    if getattr(original, '_simready_contact_scratch_bound', False):
        return
    if importlib.metadata.version('mujoco-warp') != '3.11.0':
        raise RuntimeError('Contact scratch adapter requires verified mujoco-warp 3.11.0')

    @functools.wraps(original)
    def sensor_acc(m, d):
        capacity = contact_scratch_capacity(m.opt.contact_sensor_maxmatch, d.naconmax)
        if m.nsensorcontact and capacity < m.opt.contact_sensor_maxmatch:
            # A local view changes only scratch dimensions. The public model,
            # authored capacity, contact buffers and overflow flags stay intact.
            view = copy(m)
            view.opt = copy(m.opt)
            view.opt.contact_sensor_maxmatch = capacity
            return original(view, d)
        return original(m, d)

    sensor_acc._simready_contact_scratch_bound = True
    sensor.sensor_acc = sensor_acc


def epa_horizon_capacity(iterations):
    """Worst-case edge insertions into the existing EPA face storage.

    Warp 3.11 has 6 + 5*N triangular face slots; each can contribute 3 edges.
    Processing faces in arbitrary order can exceed the final horizon length.
    EPA itself caps iterations at 1000 (10-bit vertex indices). This changes
    scratch storage only, never iteration counts, contacts or the solver law.
    """
    return max(24, 3 * (6 + 5 * min(max(int(iterations), 0), 1000)))


def install_epa_capacity():
    """Replace only the pinned rigid-convex horizon allocation, in memory.

    Each cached function has private immutable globals: concurrent scenes cannot
    overwrite one another's buffer size. All upstream collision code and its
    overflow checks are retained. Flex collisions retain the upstream guard.
    """
    from mujoco_warp._src import collision_convex, collision_driver
    original = collision_convex.convex_narrowphase
    if getattr(original, '_simready_epa_capacity', False):
        return
    if importlib.metadata.version('mujoco-warp') != '3.11.0':
        raise RuntimeError('EPA capacity adapter requires the verified mujoco-warp 3.11.0 runtime')
    implementation = inspect.unwrap(original)  # upstream @event_scope profiler
    existing_capacity = implementation.__globals__.get('MJ_MAX_EPAHORIZON')
    if (not isinstance(existing_capacity, int) or existing_capacity < 24
            or implementation.__globals__.get('MJ_MAX_EPAFACES') != 5
            or 'MJ_MAX_EPAHORIZON' not in implementation.__code__.co_names):
        raise RuntimeError('Unrecognized EPA allocator; refusing to guess its storage layout')

    @functools.lru_cache(maxsize=32)
    def sized(capacity, ccd):
        namespace = dict(implementation.__globals__, MJ_MAX_EPAHORIZON=capacity)
        function = FunctionType(implementation.__code__, namespace, implementation.__name__, implementation.__defaults__, implementation.__closure__)
        return collision_convex.event_scope(function)

    @functools.wraps(original)
    def convex(m, d, ctx, collision_table):
        # The upstream box-only path uses 16 iterations. Using the larger model
        # budget there is safe; leave every execution/termination condition alone.
        capacity = max(implementation.__globals__['MJ_MAX_EPAHORIZON'], epa_horizon_capacity(max(16, m.opt.ccd_iterations)))
        required = int(d.naccdmax) * capacity * 4
        device = d.qpos.device
        if device.is_cuda and device.total_memory > 0 and required > device.total_memory:
            raise RuntimeError(f'Simulation capacity memory budget exceeded: EPA horizon scratch alone requires {required} bytes; '
                               'reduce parallel environments and rerun validation. Contacts are not truncated.')
        # Exported terrain tasks can also install the verified signed-witness
        # adapter. Refresh the private globals when that callable changes.
        return sized(capacity, implementation.__globals__['ccd'])(m, d, ctx, collision_table)

    convex._simready_epa_capacity = True
    collision_convex.convex_narrowphase = convex
    collision_driver.convex_narrowphase = convex


def size_initial_capacity(sim, requested_num_envs=None):
    """Use the exact assembled initial state, before Warp allocates data/graphs.

    These are storage capacities, not physical parameters. Preserve larger
    authored minima; grow only an insufficient buffer with 25% spare space.
    Later poses remain protected by the normal overflow guard and step probe.
    """
    if not all(hasattr(sim, name) for name in ('cfg', '_mj_data', '_mj_model')):
        return  # No assembled model (e.g. a diagnostic-only memory probe).
    plan = {}
    for name, demand in (('nconmax', int(sim._mj_data.ncon)), ('njmax', int(sim._mj_data.nefc))):
        configured = getattr(sim.cfg, name)
        # None delegates to the verified upstream default; invalid settings are
        # still rejected upstream, never silently converted into valid numbers.
        if configured is None or isinstance(configured, bool) or not isinstance(configured, int) or configured < 0:
            continue
        required = max(configured, math.ceil(demand * 1.25)) if demand > configured else configured
        if required >= 2**31:
            raise RuntimeError(f"Simulation capacity exceeds the supported allocation range: {name}={required}")
        plan[name] = {'configured': configured, 'initialRequired': demand, 'effective': required}
    if sim.wp_device.is_cuda and plan:
        worlds = max(int(sim.num_envs), int(requested_num_envs or 0))
        # Guaranteed lower bound only: contact position/frame and one constraint
        # scalar. Do not mistake this for a full allocator or a free-VRAM limit.
        lower_bound = worlds * 4 * (12 * plan.get('nconmax', {}).get('effective', 0)
                                   + plan.get('njmax', {}).get('effective', 0))
        total = int(sim.wp_device.total_memory)
        if total > 0 and lower_bound > total:
            raise RuntimeError(f"Simulation capacity memory budget exceeded: at least {lower_bound} bytes "
                               f"for {worlds} environments, device total {total}. "
                               "Reduce parallel environments and rerun validation; the physical model is unchanged.")
    for name, item in plan.items():
        setattr(sim.cfg, name, item['effective'])
        print(f"[SimReady diagnostic] simulation_check capacity {name}={item['effective']} "
              f"configured={item['configured']} initialRequired={item['initialRequired']}", flush=True)
    sim._simready_capacity_plan = plan


def contact_scratch_bytes(worlds, sensors, capacity):
    # MuJoCo Warp 3.11 sensor_acc keeps matchid, direction, criteria (4 bytes
    # each), and one nmatch integer per sensor/world alive simultaneously.
    return int(worlds) * int(sensors) * (int(capacity) * 12 + 4)


def check_contact_memory(sim, requested_num_envs=None):
    device = sim.wp_device
    if not device.is_cuda:
        return
    model = sim._wp_model
    sensors, capacity = int(model.nsensorcontact), int(model.opt.contact_sensor_maxmatch)
    if not sensors:
        return
    worlds = max(int(sim.num_envs), int(requested_num_envs or 0))
    nconmax = getattr(getattr(sim, 'cfg', None), 'nconmax', None)
    if nconmax is None and getattr(sim, '_mj_model', None) is not None:
        from mujoco_warp._src.io import _default_nconmax
        nconmax = _default_nconmax(sim._mj_model)
    effective = contact_scratch_capacity(capacity, nconmax * worlds) if isinstance(nconmax, int) and nconmax > 0 else capacity
    required = contact_scratch_bytes(worlds, sensors, effective)
    total = int(device.total_memory)
    free = int(device.free_memory)
    print(f"[SimReady diagnostic] simulation_check contact_memory worlds={worlds} sensors={sensors} "
          f"contact_sensor_maxmatch={capacity} effectiveScratchCapacity={effective} scratchBytes={required} totalBytes={total} freeBytes={free}", flush=True)
    if total > 0 and required > total * .6:
        # A recommendation, not a guarantee or automatic change: leave room for
        # all other simulation, policy, optimizer and driver allocations.
        suggested = worlds
        while suggested > 1:
            suggested = max(1, suggested // 2)
            bound = contact_scratch_capacity(capacity, nconmax * suggested) if isinstance(nconmax, int) and nconmax > 0 else capacity
            if contact_scratch_bytes(suggested, sensors, bound) <= total * .6:
                break
        print(f'[SimReady diagnostic] simulation_check contact_memory suggestedNumEnvs={suggested}; '
              'estimate only; other simulation and policy buffers need memory', flush=True)
    if total > 0 and required > total:
        # Do not silently change environments, collision capacity or the model.
        raise RuntimeError(
            f"SimReady contact memory budget exceeded: {worlds} environments require at least "
            f"{required / 2**30:.2f} GiB of contact scratch memory; GPU total is {total / 2**30:.2f} GiB. "
            "Reduce parallel environments explicitly and rerun validation. "
            "Other simulation and policy buffers need additional memory; contact capacity is unchanged.")
    if required > free:
        print("[SimReady diagnostic] simulation_check contact_memory pressure=true; "
              "scratch exceeds current driver free memory; cached pool reuse is not known", flush=True)


def install_contact_memory_guard(requested_num_envs=None):
    """Shared by the Runner and exported tasks; idempotent across module copies."""
    from mjlab.sim.sim import Simulation
    install_epa_capacity()
    install_contact_scratch_bound()
    original = Simulation._finish_init
    if getattr(original, "_simready_contact_memory", False) is True:
        if requested_num_envs is not None:
            original._simready_requested_envs = int(requested_num_envs)
        return
    if (importlib.metadata.version("mujoco-warp") != "3.11.0"
            or importlib.metadata.version("mjlab") != "1.6.0"):
        raise RuntimeError("Contact memory preflight requires the verified MJLab 1.6.0 / MuJoCo Warp 3.11.0 runtime")

    @functools.wraps(original)
    def finish(sim):
        size_initial_capacity(sim, finish._simready_requested_envs)
        check_contact_memory(sim, finish._simready_requested_envs)
        return original(sim)

    finish._simready_contact_memory = True
    finish._simready_requested_envs = requested_num_envs
    Simulation._finish_init = finish
