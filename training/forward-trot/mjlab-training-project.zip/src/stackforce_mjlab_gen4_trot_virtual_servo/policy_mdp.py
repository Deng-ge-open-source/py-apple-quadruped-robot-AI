"""StackForce policy MDP terms shared across MJLab robot profiles."""

from dataclasses import dataclass

import torch

from mjlab.entity import Entity
from mjlab.envs import mdp as envs_mdp
from mjlab.managers.action_manager import ActionTerm, ActionTermCfg
from mjlab.managers.scene_entity_config import SceneEntityCfg
from mjlab.sensor import ContactSensor, TerrainHeightSensor
from rsl_rl.modules.distribution import GaussianDistribution
from .terrain import root_clearance

_EXACT_PHASE_STEP_CLOCK = True

def fixed_step_phase_cycles(env, period_s, dtype=torch.float32):
  """Modulo integer episode ticks before converting to bounded phase values."""
  ratio = float(period_s) / float(env.step_dt)
  steps = round(ratio)
  if steps < 1 or abs(ratio - steps) > 1.e-7:
    raise ValueError("Exact phase clock needs an integer number of environment steps")
  ticks = env.episode_length_buf
  if ticks.dtype not in (torch.int32, torch.int64):
    raise ValueError("Exact phase clock needs integer episode counters")
  # CUDA float32 division uses reciprocal multiplication. Divide the bounded
  # integers in float64 before the final cast so CPU, CUDA and native NumPy
  # round the same rational phase, including policy/physics shared boundaries.
  return (torch.remainder(ticks, steps).to(torch.float64) / steps).to(dtype)



class BoundedMeanModule(torch.nn.Module):
  def __init__(self, bound):
    super().__init__()
    self.bound = float(bound)

  def forward(self, value):
    return self.bound * torch.tanh(value / self.bound)


class BoundedGaussianDistribution(GaussianDistribution):
  """GUI-bounded mean with identical training, playback and ONNX semantics."""
  def __init__(self, output_dim, mean_bound=2.0, **kwargs):
    super().__init__(output_dim, **kwargs)
    if mean_bound <= 0:
      raise ValueError("Mean bound must be positive")
    self.mean_bound = float(mean_bound)

  def update(self, mlp_output):
    super().update(self.deterministic_output(mlp_output))

  def deterministic_output(self, mlp_output):
    return self.mean_bound * torch.tanh(mlp_output / self.mean_bound)

  def as_deterministic_output_module(self):
    return BoundedMeanModule(self.mean_bound)


def yaw_rate_error(env, command_name="twist"):
  command = env.command_manager.get_command(command_name)
  return torch.square(env.scene["robot"].data.root_link_ang_vel_b[:, 2] - command[:, 2])


class QminiTanhGaussianDistribution(GaussianDistribution):
  """Gaussian whose mean matches RoboTamer's tanh-bounded actor head."""

  def update(self, mlp_output: torch.Tensor) -> None:
    super().update(torch.tanh(mlp_output))

  def deterministic_output(self, mlp_output: torch.Tensor) -> torch.Tensor:
    return torch.tanh(mlp_output)

  def as_deterministic_output_module(self) -> torch.nn.Module:
    return torch.nn.Tanh()


@dataclass(kw_only=True)
class QminiNativeActionCfg(ActionTermCfg):
  """RoboTamer Qmini 12-D ABI: two leg frequencies plus ten target increments."""

  joint_names: tuple[str, ...]
  target_rate: float = 15.0
  frequency_bias: float = 0.5
  frequency_scale: float = 1.5
  frequency_calibration: float = 1.0
  heading_damping: float = 0.02

  def build(self, env) -> "QminiNativeAction":
    return QminiNativeAction(self, env)


class QminiNativeAction(ActionTerm):
  """Integrate the native Qmini policy outputs into absolute joint targets."""

  cfg: QminiNativeActionCfg

  def __init__(self, cfg: QminiNativeActionCfg, env):
    super().__init__(cfg=cfg, env=env)
    joint_ids, matched_names = self._entity.find_joints(
      cfg.joint_names, preserve_order=True
    )
    if tuple(matched_names) != tuple(cfg.joint_names) or len(joint_ids) != 10:
      raise ValueError(
        f"Qmini native joint order mismatch: requested={cfg.joint_names}, "
        f"matched={tuple(matched_names)}"
      )
    self._joint_ids = torch.tensor(joint_ids, dtype=torch.long, device=self.device)
    self._raw_actions = torch.zeros(self.num_envs, 12, device=self.device)
    self._scale = torch.ones((1, 12), dtype=torch.float, device=self.device)
    self._phase = torch.zeros((self.num_envs, 2), device=self.device)
    self._frequency = torch.full(
      (self.num_envs, 2), cfg.frequency_bias, device=self.device
    )
    default = self._entity.data.default_joint_pos[:, self._joint_ids]
    self._current_target = default.clone()
    self._position_target = default.clone()

  @property
  def action_dim(self) -> int:
    return 12

  @property
  def raw_action(self) -> torch.Tensor:
    return self._raw_actions

  @property
  def phase(self) -> torch.Tensor:
    return self._phase

  @property
  def frequency(self) -> torch.Tensor:
    return self._frequency

  @property
  def current_target(self) -> torch.Tensor:
    return self._current_target

  @property
  def joint_ids(self) -> torch.Tensor:
    return self._joint_ids

  def process_actions(self, actions: torch.Tensor) -> None:
    self._raw_actions.copy_(actions)
    bounded = torch.clamp(actions, -1.0, 1.0)
    self._frequency.copy_(
      (
        self.cfg.frequency_bias
        + self.cfg.frequency_scale * (bounded[:, :2] + 1.0)
      ) * self.cfg.frequency_calibration
    )
    self._phase.copy_(torch.remainder(
      self._phase
      + 2.0 * torch.pi * self._frequency * self._env.step_dt,
      2.0 * torch.pi,
    ))
    self._current_target.add_(
      self.cfg.target_rate * bounded[:, 2:] * self._env.step_dt
    )
    limits = self._entity.data.soft_joint_pos_limits[:, self._joint_ids]
    self._current_target.copy_(torch.maximum(
      torch.minimum(self._current_target, limits[:, :, 1]), limits[:, :, 0]
    ))
    corrected = self._current_target.clone()
    heading = self._entity.data.heading_w
    yaw_rate = self._entity.data.root_link_ang_vel_b[:, 2]
    yaw_correction = self.cfg.heading_damping * (heading + yaw_rate)
    corrected[:, 0] += yaw_correction
    corrected[:, 5] -= yaw_correction
    self._position_target.copy_(corrected)

  def apply_actions(self) -> None:
    self._entity.set_joint_position_target(
      self._position_target, joint_ids=self._joint_ids
    )

  def reset(self, env_ids: torch.Tensor | slice | None = None) -> None:
    if env_ids is None:
      env_ids = slice(None)
    self._raw_actions[env_ids] = 0.0
    self._phase[env_ids] = 0.0
    self._frequency[env_ids] = self.cfg.frequency_bias
    default = self._entity.data.default_joint_pos[:, self._joint_ids]
    self._current_target[env_ids] = default[env_ids]
    self._position_target[env_ids] = default[env_ids]


@dataclass(kw_only=True)
class SfSoleReferenceActionCfg(ActionTermCfg):
  """Accepted Isaac SF-sole reference controller plus learned residual."""

  joint_names: tuple[str, ...]
  action_scale: tuple[float, ...]
  parameters: dict[str, float] | None = None

  def build(self, env) -> "SfSoleReferenceAction":
    return SfSoleReferenceAction(self, env)


class SfSoleReferenceAction(ActionTerm):
  """MJLab-calibrated port of the accepted Isaac SF-sole controller."""

  cfg: SfSoleReferenceActionCfg

  REFERENCE_FREQUENCY = 1.7790098905563354
  PHASE_OFFSET = 0.823951005935669
  WAVE_SHAPE = 2.6451663970947266
  HIP_SWING = 1.1762059926986694
  HIP_STANCE = -0.630273985862732
  KNEE_SWING = 0.11292901635169983
  KNEE_STANCE = 0.07195442169904709
  ANKLE_SWING = 0.36283212900161743
  ANKLE_STANCE = -0.15248450636863708
  ROLL_AMPLITUDE = 0.0441075824201107
  ROLL_BIAS = -0.008288122713565826
  ROLL_FEEDBACK = 3.4430060386657715
  PITCH_ANKLE_FEEDBACK = 0.17527921497821808
  PITCH_HIP_FEEDBACK = 2.8118858337402344
  # Keep the accepted Isaac clock exactly; only amplitudes/residual authority
  # are calibrated for MuJoCo-Warp contact dynamics.
  GAIT_SCALE = 0.9
  ROLL_SCALE = 0.9
  POLICY_RESIDUAL_SCALE = 0.445
  RAMP_SECONDS = 0.55
  REFERENCE_ACTION_CLIP = 1.0
  POLICY_ACTION_CLIP = 1.0

  def __init__(self, cfg: SfSoleReferenceActionCfg, env):
    super().__init__(cfg=cfg, env=env)
    for key, value in (cfg.parameters or {}).items():
      if key not in type(self).__dict__ or not isinstance(getattr(self, key), (float, int)):
        raise ValueError(f"Unknown reference-controller parameter: {key}")
      setattr(self, key, float(value))
    joint_ids, matched_names = self._entity.find_joints(
      cfg.joint_names, preserve_order=True
    )
    if tuple(matched_names) != tuple(cfg.joint_names) or len(joint_ids) != 8:
      raise ValueError(
        f"SF-sole joint order mismatch: requested={cfg.joint_names}, "
        f"matched={tuple(matched_names)}"
      )
    self._joint_ids = torch.tensor(joint_ids, dtype=torch.long, device=self.device)
    self._raw_actions = torch.zeros(self.num_envs, 8, device=self.device)
    self._processed_actions = torch.zeros_like(self._raw_actions)
    self._scale = torch.tensor(
      cfg.action_scale, dtype=torch.float, device=self.device
    ).unsqueeze(0)
    residual_part_scale = []
    for name in cfg.joint_names:
      lowered = name.lower()
      if "hip" in lowered and "pitch" in lowered:
        residual_part_scale.append(1.05)
      elif "ankle" in lowered or "sole" in lowered or "foot" in lowered:
        residual_part_scale.append(1.1)
      else:
        residual_part_scale.append(1.0)
    self._residual_part_scale = torch.tensor(
      residual_part_scale, dtype=torch.float, device=self.device
    ).unsqueeze(0)
    self._position_target = self._entity.data.default_joint_pos[:, self._joint_ids].clone()

  @property
  def action_dim(self) -> int:
    return 8

  @property
  def raw_action(self) -> torch.Tensor:
    return self._raw_actions

  def _aligned_action(self, actions: torch.Tensor) -> torch.Tensor:
    phase_angle = (
      2.0
      * torch.pi
      * self.REFERENCE_FREQUENCY
      * self._env.episode_length_buf.float()
      * self._env.step_dt
      + self.PHASE_OFFSET
    )
    sine = torch.sin(phase_angle)
    right_swing = torch.relu(sine).pow(self.WAVE_SHAPE)
    left_swing = torch.relu(-sine).pow(self.WAVE_SHAPE)
    right_stance = left_swing
    left_stance = right_swing
    gravity = self._entity.data.projected_gravity_b
    roll_angle = torch.atan2(-gravity[:, 1], -gravity[:, 2])
    pitch_angle = torch.asin(torch.clamp(gravity[:, 0], -1.0, 1.0))
    roll = (
      self.ROLL_AMPLITUDE * sine * self.GAIT_SCALE * self.ROLL_SCALE
      + self.ROLL_BIAS
      - self.ROLL_FEEDBACK * roll_angle
    )
    pitch_ankle = self.PITCH_ANKLE_FEEDBACK * pitch_angle
    pitch_hip = self.PITCH_HIP_FEEDBACK * pitch_angle
    reference = torch.zeros_like(actions)
    for action_index, joint_name in enumerate(self.cfg.joint_names):
      lowered = joint_name.lower()
      is_left = "left" in lowered
      is_right = "right" in lowered
      if not is_left and not is_right:
        continue
      swing = right_swing if is_left else left_swing
      stance = right_stance if is_left else left_stance
      side_sign = 1.0 if is_left else -1.0
      if "hip" in lowered and "pitch" in lowered:
        reference[:, action_index] = side_sign * (
          self.GAIT_SCALE
          * (self.HIP_SWING * swing + self.HIP_STANCE * stance)
          + pitch_hip
        )
      elif "hip" in lowered and "roll" in lowered:
        reference[:, action_index] = roll
      elif "knee" in lowered:
        reference[:, action_index] = side_sign * self.GAIT_SCALE * (
          self.KNEE_STANCE + self.KNEE_SWING * swing
        )
      elif "ankle" in lowered or "sole" in lowered or "foot" in lowered:
        reference[:, action_index] = side_sign * (
          self.GAIT_SCALE
          * (self.ANKLE_SWING * swing + self.ANKLE_STANCE * stance)
          - pitch_ankle
        )
    ramp = torch.clamp(
      self._env.episode_length_buf.float() * self._env.step_dt / self.RAMP_SECONDS,
      0.0,
      1.0,
    )
    reference = torch.clamp(
      reference * ramp.unsqueeze(1),
      -self.REFERENCE_ACTION_CLIP,
      self.REFERENCE_ACTION_CLIP,
    )
    residual = (
      torch.clamp(actions, -self.POLICY_ACTION_CLIP, self.POLICY_ACTION_CLIP)
      * self.POLICY_RESIDUAL_SCALE
      * self._residual_part_scale
    )
    return reference + residual

  def process_actions(self, actions: torch.Tensor) -> None:
    self._raw_actions.copy_(actions)
    self._processed_actions.copy_(self._aligned_action(actions))
    default = self._entity.data.default_joint_pos[:, self._joint_ids]
    self._position_target.copy_(default + self._processed_actions * self._scale)

  def apply_actions(self) -> None:
    self._entity.set_joint_position_target(
      self._position_target, joint_ids=self._joint_ids
    )

  def reset(self, env_ids: torch.Tensor | slice | None = None) -> None:
    if env_ids is None:
      env_ids = slice(None)
    self._raw_actions[env_ids] = 0.0
    self._processed_actions[env_ids] = 0.0
    default = self._entity.data.default_joint_pos[:, self._joint_ids]
    self._position_target[env_ids] = default[env_ids]


@dataclass(kw_only=True)
class PhaseReferenceActionCfg(ActionTermCfg):
  """Editable periodic joint reference plus policy residual, for any position-controlled robot."""

  joint_names: tuple[str, ...]
  action_scale: tuple[float, ...]
  period_s: float
  amplitudes: tuple[float, ...]
  offsets: tuple[float, ...]
  waveform_codes: tuple[int, ...]
  residual_scale: float
  residual_smoothing_alpha: float
  action_clip: float
  ramp_seconds: float

  def build(self, env) -> "PhaseReferenceAction":
    return PhaseReferenceAction(self, env)


class PhaseReferenceAction(ActionTerm):
  cfg: PhaseReferenceActionCfg

  def __init__(self, cfg: PhaseReferenceActionCfg, env):
    super().__init__(cfg=cfg, env=env)
    joint_ids, matched_names = self._entity.find_joints(cfg.joint_names, preserve_order=True)
    count = len(cfg.joint_names)
    if tuple(matched_names) != tuple(cfg.joint_names) or not all(len(values) == count for values in (cfg.action_scale, cfg.amplitudes, cfg.offsets, cfg.waveform_codes)):
      raise ValueError("Phase reference arrays must match the ordered action joints")
    if cfg.period_s <= 0 or cfg.residual_scale < 0 or not 0 < cfg.residual_smoothing_alpha <= 1 or cfg.action_clip <= 0 or cfg.ramp_seconds < 0:
      raise ValueError("Invalid phase reference timing or residual scale")
    if any(code not in (0, 1, 2) for code in cfg.waveform_codes):
      raise ValueError("Phase waveform code must be 0=sin, 1=positive half sine or 2=negative half sine")
    self._joint_ids = torch.tensor(joint_ids, dtype=torch.long, device=self.device)
    self._raw_actions = torch.zeros(self.num_envs, count, device=self.device)
    self._processed_actions = torch.zeros_like(self._raw_actions)
    self._filtered_residual = torch.zeros_like(self._raw_actions)
    self._filter_ready = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
    self._scale = torch.tensor(cfg.action_scale, dtype=torch.float, device=self.device).unsqueeze(0)
    self._amplitudes = torch.tensor(cfg.amplitudes, dtype=torch.float, device=self.device).unsqueeze(0)
    self._offsets = torch.tensor(cfg.offsets, dtype=torch.float, device=self.device).unsqueeze(0)
    self._position_target = self._entity.data.default_joint_pos[:, self._joint_ids].clone()

  @property
  def action_dim(self) -> int:
    return len(self.cfg.joint_names)

  @property
  def raw_action(self) -> torch.Tensor:
    return self._raw_actions

  def process_actions(self, actions: torch.Tensor) -> None:
    self._raw_actions.copy_(actions)
    time = self._env.episode_length_buf.float() * self._env.step_dt
    phase = 2.0 * torch.pi * (time[:, None] / self.cfg.period_s + self._offsets)
    sine = torch.sin(phase)
    reference = torch.stack([
      sine[:, index] if code == 0 else torch.relu(sine[:, index]) if code == 1 else torch.relu(-sine[:, index])
      for index, code in enumerate(self.cfg.waveform_codes)
    ], dim=1) * self._amplitudes
    if self.cfg.ramp_seconds > 0:
      reference *= torch.clamp(time / self.cfg.ramp_seconds, max=1.0)[:, None]
    residual = torch.clamp(actions, -self.cfg.action_clip, self.cfg.action_clip)
    alpha = self.cfg.residual_smoothing_alpha
    self._filtered_residual.copy_(torch.where(
      self._filter_ready[:, None], alpha * residual + (1.0 - alpha) * self._filtered_residual, residual
    ))
    self._filter_ready[:] = True
    self._processed_actions.copy_(reference + self._filtered_residual * self.cfg.residual_scale)
    default = self._entity.data.default_joint_pos[:, self._joint_ids]
    target = default + self._processed_actions * self._scale
    limits = self._entity.data.soft_joint_pos_limits[:, self._joint_ids]
    self._position_target.copy_(torch.maximum(torch.minimum(target, limits[:, :, 1]), limits[:, :, 0]))

  def apply_actions(self) -> None:
    self._entity.set_joint_position_target(self._position_target, joint_ids=self._joint_ids)

  def reset(self, env_ids: torch.Tensor | slice | None = None) -> None:
    if env_ids is None:
      env_ids = slice(None)
    self._raw_actions[env_ids] = 0.0
    self._processed_actions[env_ids] = 0.0
    self._filtered_residual[env_ids] = 0.0
    self._filter_ready[env_ids] = False
    default = self._entity.data.default_joint_pos[:, self._joint_ids]
    self._position_target[env_ids] = default[env_ids]


@dataclass(kw_only=True)
class StackForceMixedJointActionCfg(ActionTermCfg):
  """Preserve policy action order while driving mixed position/velocity/effort joints."""

  action_specs: tuple[tuple[str, str, float, float, float], ...]
  base_body: str
  wheel_joint_names: tuple[str, ...]
  archetype: str
  forward_axis_index: int = 0
  forward_axis_sign: float = 1.0
  wheel_radius: float = 1.0
  command_ramp_time_s: float = 0.0
  command_feedforward: bool = False
  command_feedforward_scale: float = 0.0
  symmetric_actions: bool = False
  drive_feedforward: float = 0.0
  drive_velocity_gain: float = 0.0
  drive_limit_fraction: float = 0.55
  pitch_kp: float = 0.0
  pitch_kd: float = 0.0
  pitch_gravity_axis: int = 0
  pitch_rate_axis: int = 1
  pitch_sign: float = 1.0
  pitch_target: float = 0.0
  pitch_target_speed: float = 0.5
  pitch_target_always_on: bool = False
  speed_pitch_kp: float = 0.0
  speed_pitch_limit: float = 0.0
  forward_velocity_kd: float = 0.0
  velocity_balance_kd: float = 0.0
  velocity_balance_target_sign: float = 1.0
  yaw_kd: float = 0.0
  heading_kp: float = 0.0
  lateral_kp: float = 0.0
  wheel_velocity_kd: float = 0.0
  wheel_action_torque_scale: float = 0.0
  torque_rate_limit: float = 0.0
  base_heading_torque_kp: float = 0.0
  base_heading_torque_kd: float = 0.0
  base_heading_torque_ki: float = 0.0
  base_heading_torque_max: float = 0.0
  quad_drive_feedforward: float = 0.0
  quad_drive_kp_vx: float = 0.0
  quad_max_drive_torque: float = 0.0
  quad_heading_kp: float = 0.0
  quad_yaw_kd: float = 0.0
  quad_yaw_torque_scale: float = 0.0
  quad_max_yaw_cmd: float = 0.0
  quad_yaw_sign: float = 1.0

  def build(self, env) -> "StackForceMixedJointAction":
    return StackForceMixedJointAction(self, env)


class StackForceMixedJointAction(ActionTerm):
  """Contract-driven mixed controller for wheel-biped and wheel-quadruped tasks."""

  cfg: StackForceMixedJointActionCfg

  def __init__(self, cfg: StackForceMixedJointActionCfg, env):
    super().__init__(cfg=cfg, env=env)
    names = tuple(spec[0] for spec in cfg.action_specs)
    joint_ids, matched_names = self._entity.find_joints(names, preserve_order=True)
    if tuple(matched_names) != names:
      raise ValueError(
        f"Mixed action joint order mismatch: requested={names}, matched={tuple(matched_names)}"
      )
    self._joint_ids = torch.tensor(joint_ids, dtype=torch.long, device=self.device)
    self._raw_actions = torch.zeros(self.num_envs, len(names), device=self.device)
    self._processed_actions = torch.zeros_like(self._raw_actions)
    self._scale = torch.tensor(
      [spec[2] * spec[3] for spec in cfg.action_specs],
      dtype=torch.float,
      device=self.device,
    ).unsqueeze(0)
    self._mode_by_action = tuple(spec[1] for spec in cfg.action_specs)
    self._position_action_ids = torch.tensor(
      [i for i, mode in enumerate(self._mode_by_action) if mode == "position"],
      dtype=torch.long,
      device=self.device,
    )
    self._body_effort_action_ids = torch.tensor(
      [
        i for i, (name, mode, *_rest) in enumerate(cfg.action_specs)
        if mode == "effort" and name not in cfg.wheel_joint_names
      ],
      dtype=torch.long,
      device=self.device,
    )
    self._wheel_action_ids = torch.tensor(
      [names.index(name) for name in cfg.wheel_joint_names],
      dtype=torch.long,
      device=self.device,
    )
    self._position_joint_ids = self._joint_ids[self._position_action_ids]
    self._body_effort_joint_ids = self._joint_ids[self._body_effort_action_ids]
    self._wheel_joint_ids = self._joint_ids[self._wheel_action_ids]
    wheel_specs = [cfg.action_specs[index] for index in self._wheel_action_ids.tolist()]
    self._wheel_mode = wheel_specs[0][1] if wheel_specs else "velocity"
    if any(spec[1] != self._wheel_mode for spec in wheel_specs):
      raise ValueError("All wheel joints must use the same control mode")
    self._wheel_scale = torch.tensor(
      [spec[2] for spec in wheel_specs], dtype=torch.float, device=self.device
    ).unsqueeze(0)
    self._wheel_residual_scale = torch.full_like(
      self._wheel_scale, cfg.wheel_action_torque_scale
    )
    self._wheel_direction = torch.tensor(
      [spec[3] for spec in wheel_specs], dtype=torch.float, device=self.device
    ).unsqueeze(0)
    self._wheel_limit = torch.tensor(
      [spec[4] for spec in wheel_specs], dtype=torch.float, device=self.device
    ).unsqueeze(0)
    self._wheel_yaw_side = torch.tensor(
      [
        -1.0 if any(
          token in {"l", "left", "lf", "fl", "rl"}
          for token in name.lower().replace("-", "_").split("_")
        ) else 1.0
        for name in cfg.wheel_joint_names
      ],
      dtype=torch.float,
      device=self.device,
    ).unsqueeze(0)
    base_ids, _ = self._entity.find_bodies((cfg.base_body,), preserve_order=True)
    if len(base_ids) != 1:
      raise ValueError(f"Expected one base body named {cfg.base_body}, found {base_ids}")
    self._base_body_id = base_ids[0]
    self._position_target = torch.empty(
      self.num_envs, len(self._position_action_ids), device=self.device
    )
    self._body_effort_target = torch.empty(
      self.num_envs, len(self._body_effort_action_ids), device=self.device
    )
    self._wheel_target = torch.zeros(
      self.num_envs, len(self._wheel_action_ids), device=self.device
    )
    self._last_wheel_torque = torch.zeros_like(self._wheel_target)
    self._heading_error_integral = torch.zeros(self.num_envs, device=self.device)
    self._base_yaw_torque = torch.zeros(self.num_envs, device=self.device)

  @property
  def action_dim(self) -> int:
    return self._raw_actions.shape[1]

  @property
  def raw_action(self) -> torch.Tensor:
    return self._raw_actions

  def _command_ramp(self) -> torch.Tensor:
    if self.cfg.command_ramp_time_s <= 0.0:
      return torch.ones((self.num_envs, 1), dtype=torch.float, device=self.device)
    return torch.clamp(
      self._env.episode_length_buf.float().unsqueeze(1)
      * self._env.step_dt
      / self.cfg.command_ramp_time_s,
      0.0,
      1.0,
    )

  def _forward_velocity(self) -> torch.Tensor:
    return (
      self._entity.data.root_link_lin_vel_b[
        :, self.cfg.forward_axis_index:self.cfg.forward_axis_index + 1
      ]
      * self.cfg.forward_axis_sign
    )

  @staticmethod
  def _wrap_to_pi(angle: torch.Tensor) -> torch.Tensor:
    return torch.atan2(torch.sin(angle), torch.cos(angle))

  def _biped_wheel_effort(self, wheel_actions: torch.Tensor) -> torch.Tensor:
    if self._wheel_target.shape[1] != 2:
      raise RuntimeError("Wheel-biped effort control requires exactly two wheels")
    if self.cfg.symmetric_actions:
      wheel_actions = torch.mean(wheel_actions, dim=1, keepdim=True).expand_as(wheel_actions)
    command = self._env.command_manager.get_command("twist")[:, 0:1]
    ramp = self._command_ramp()
    forward_velocity = self._forward_velocity()
    speed_error = command - forward_velocity
    drive_fraction = min(max(self.cfg.drive_limit_fraction, 0.05), 0.95)
    drive_limit = self._wheel_limit * drive_fraction
    drive_raw = ramp * (
      self.cfg.drive_feedforward * command
      + self.cfg.drive_velocity_gain * speed_error
    )
    drive_torque = torch.clamp(drive_raw, -drive_limit, drive_limit)

    gravity_axis = 1 if self.cfg.pitch_gravity_axis == 1 else 0
    rate_axis = 0 if self.cfg.pitch_rate_axis == 0 else 1
    pitch_error = self.cfg.pitch_sign * torch.clamp(
      self._entity.data.projected_gravity_b[:, gravity_axis:gravity_axis + 1],
      -1.0,
      1.0,
    )
    pitch_rate = self.cfg.pitch_sign * torch.tanh(
      self._entity.data.root_link_ang_vel_b[:, rate_axis:rate_axis + 1]
    )
    pitch_target = torch.full_like(pitch_error, self.cfg.pitch_target)
    if not self.cfg.pitch_target_always_on and self.cfg.pitch_target_speed > 1.0e-6:
      pitch_target *= torch.clamp(
        torch.abs(command) / self.cfg.pitch_target_speed, 0.0, 1.0
      )
    pitch_target += self.cfg.speed_pitch_kp * speed_error
    if self.cfg.speed_pitch_limit > 0.0:
      pitch_target = torch.clamp(
        pitch_target, -self.cfg.speed_pitch_limit, self.cfg.speed_pitch_limit
      )
    if not self.cfg.pitch_target_always_on:
      pitch_target *= ramp
    pitch_torque = -self.cfg.pitch_kp * (pitch_error - pitch_target)
    pitch_torque -= self.cfg.pitch_kd * pitch_rate
    pitch_torque -= self.cfg.forward_velocity_kd * (forward_velocity - ramp * command)

    signed_wheel_velocity = (
      self._entity.data.joint_vel[:, self._wheel_joint_ids] * self._wheel_direction
    )
    if self.cfg.velocity_balance_kd != 0.0:
      target_velocity = (
        self.cfg.velocity_balance_target_sign
        * ramp
        * command
        / max(self.cfg.wheel_radius, 1.0e-6)
      )
      pitch_torque -= self.cfg.velocity_balance_kd * (
        torch.mean(signed_wheel_velocity, dim=1, keepdim=True) - target_velocity
      )
    yaw_torque = -self.cfg.yaw_kd * torch.tanh(
      self._entity.data.root_link_ang_vel_b[:, 2:3]
    )
    heading_error = self._wrap_to_pi(-self._entity.data.heading_w).unsqueeze(1)
    yaw_torque += self.cfg.heading_kp * heading_error
    correction_limit = torch.clamp(
      self._wheel_limit - torch.abs(drive_torque), min=self._wheel_limit * 0.05
    )
    correction = torch.cat(
      (pitch_torque + yaw_torque, pitch_torque - yaw_torque), dim=1
    )
    correction = torch.clamp(correction, -correction_limit, correction_limit)
    residual = ramp * wheel_actions * self._wheel_residual_scale
    braking = -self.cfg.wheel_velocity_kd * signed_wheel_velocity
    signed_torque = torch.clamp(
      drive_torque + correction + residual + braking,
      -self._wheel_limit,
      self._wheel_limit,
    )
    effort = signed_torque * self._wheel_direction
    if self.cfg.torque_rate_limit > 0.0:
      max_delta = self.cfg.torque_rate_limit * self._env.step_dt
      effort = self._last_wheel_torque + torch.clamp(
        effort - self._last_wheel_torque, -max_delta, max_delta
      )
    self._last_wheel_torque.copy_(effort.detach())
    return torch.clamp(effort, -self._wheel_limit, self._wheel_limit)

  def _quad_wheel_effort(self) -> torch.Tensor:
    command = self._env.command_manager.get_command("twist")[:, 0:1]
    speed_error = command - self._forward_velocity()
    drive_torque = (
      self.cfg.quad_drive_feedforward * command
      + self.cfg.quad_drive_kp_vx * speed_error
    )
    if self.cfg.quad_max_drive_torque > 0.0:
      drive_torque = torch.clamp(
        drive_torque,
        -self.cfg.quad_max_drive_torque,
        self.cfg.quad_max_drive_torque,
      )
    heading_error = self._wrap_to_pi(-self._entity.data.heading_w).unsqueeze(1)
    yaw_command = self.cfg.quad_yaw_sign * (
      self.cfg.quad_heading_kp * heading_error
      - self.cfg.quad_yaw_kd * self._entity.data.root_link_ang_vel_b[:, 2:3]
    )
    if self.cfg.quad_max_yaw_cmd > 0.0:
      yaw_command = torch.clamp(
        yaw_command, -self.cfg.quad_max_yaw_cmd, self.cfg.quad_max_yaw_cmd
      )
    yaw_torque = self.cfg.quad_yaw_torque_scale * yaw_command * self._wheel_yaw_side
    return torch.clamp(
      (drive_torque + yaw_torque) * self._wheel_direction,
      -self._wheel_limit,
      self._wheel_limit,
    )

  def process_actions(self, actions: torch.Tensor) -> None:
    self._raw_actions.copy_(actions)
    self._processed_actions.copy_(actions * self._scale)
    if self._position_action_ids.numel() > 0:
      default = self._entity.data.default_joint_pos[:, self._position_joint_ids]
      self._position_target.copy_(
        default + self._processed_actions[:, self._position_action_ids]
      )
    if self._body_effort_action_ids.numel() > 0:
      self._body_effort_target.copy_(
        self._processed_actions[:, self._body_effort_action_ids]
      )
    wheel_actions = self._raw_actions[:, self._wheel_action_ids]
    if self._wheel_mode == "effort":
      if self.cfg.archetype == "wheel_quadruped":
        self._wheel_target.copy_(self._quad_wheel_effort())
      else:
        self._wheel_target.copy_(self._biped_wheel_effort(wheel_actions))
    else:
      target = self._processed_actions[:, self._wheel_action_ids]
      if self.cfg.command_feedforward:
        command = self._env.command_manager.get_command("twist")[:, 0:1]
        target = target + (
          self.cfg.command_feedforward_scale
          * command
          / max(self.cfg.wheel_radius, 1.0e-6)
          * self._wheel_direction
          * self._command_ramp()
        )
      self._wheel_target.copy_(target)

    if self.cfg.base_heading_torque_max > 0.0:
      heading_error = self._wrap_to_pi(-self._entity.data.heading_w)
      yaw_rate = self._entity.data.root_link_ang_vel_b[:, 2]
      self._heading_error_integral.add_(heading_error * self._env.step_dt)
      self._heading_error_integral.clamp_(-0.5, 0.5)
      self._base_yaw_torque.copy_(torch.clamp(
        self.cfg.base_heading_torque_kp * heading_error
        - self.cfg.base_heading_torque_kd * yaw_rate
        + self.cfg.base_heading_torque_ki * self._heading_error_integral,
        -self.cfg.base_heading_torque_max,
        self.cfg.base_heading_torque_max,
      ))

  def apply_actions(self) -> None:
    if self._position_action_ids.numel() > 0:
      self._entity.set_joint_position_target(
        self._position_target, joint_ids=self._position_joint_ids
      )
    if self._body_effort_action_ids.numel() > 0:
      self._entity.set_joint_effort_target(
        self._body_effort_target, joint_ids=self._body_effort_joint_ids
      )
    if self._wheel_mode == "effort":
      self._entity.set_joint_effort_target(
        self._wheel_target, joint_ids=self._wheel_joint_ids
      )
    else:
      self._entity.set_joint_velocity_target(
        self._wheel_target, joint_ids=self._wheel_joint_ids
      )
    if self.cfg.base_heading_torque_max > 0.0:
      forces = torch.zeros((self.num_envs, 1, 3), device=self.device)
      torques = torch.zeros_like(forces)
      torques[:, 0, 2] = self._base_yaw_torque
      self._entity.write_external_wrench_to_sim(
        forces, torques, body_ids=[self._base_body_id]
      )

  def reset(self, env_ids: torch.Tensor | slice | None = None) -> None:
    self._raw_actions[env_ids] = 0.0
    self._processed_actions[env_ids] = 0.0
    self._last_wheel_torque[env_ids] = 0.0
    self._heading_error_integral[env_ids] = 0.0
    self._base_yaw_torque[env_ids] = 0.0


def qmini_native_observation(
  env,
  action_name: str = "qmini_native",
  command_name: str = "twist",
  command_scale_x: float = 0.5,
  angular_noise: float = 0.0,
  position_noise: float = 0.0,
  velocity_noise: float = 0.0,
) -> torch.Tensor:
  """Exact 43-D RoboTamer frame; the observation manager supplies 3-frame history."""
  action = env.action_manager.get_term(action_name)
  if not isinstance(action, QminiNativeAction):
    raise TypeError(f"Expected QminiNativeAction, got {type(action).__name__}")
  robot: Entity = env.scene["robot"]
  joint_pos = robot.data.joint_pos[:, action.joint_ids]
  joint_vel = robot.data.joint_vel[:, action.joint_ids]
  default = robot.data.default_joint_pos[:, action.joint_ids]
  quaternion = robot.data.root_link_quat_w
  w, x, y, z = quaternion.unbind(dim=1)
  roll = torch.atan2(
    2.0 * (w * x + y * z), 1.0 - 2.0 * (x * x + y * y)
  )
  pitch = torch.asin(torch.clamp(2.0 * (w * y - z * x), -1.0, 1.0))
  phase_obs = torch.cat((torch.sin(action.phase), torch.cos(action.phase)), dim=1)
  command = env.command_manager.get_command(command_name).clone()
  command[:, 0] *= command_scale_x
  angular_velocity = robot.data.root_link_ang_vel_b
  if angular_noise:
    angular_velocity = angular_velocity + (torch.rand_like(angular_velocity) * 2 - 1) * angular_noise
  if position_noise:
    joint_pos = joint_pos + (torch.rand_like(joint_pos) * 2 - 1) * position_noise
  if velocity_noise:
    joint_vel = joint_vel + (torch.rand_like(joint_vel) * 2 - 1) * velocity_noise
  return torch.clamp(torch.cat(
    (
      command[:, [0, 2]],
      torch.stack((roll, pitch), dim=1),
      angular_velocity * 0.5,
      joint_pos - default,
      joint_vel * 0.1,
      action.current_target - joint_pos,
      phase_obs,
      action.frequency * 0.3 - 1.0,
    ),
    dim=1,
  ), -3.0, 3.0)


def qmini_frequency_tracking(
  env,
  target_hz: float,
  std_hz: float,
  action_name: str = "qmini_native",
) -> torch.Tensor:
  """Keep the learned native frequency heads near the reviewed Isaac cadence."""
  action = env.action_manager.get_term(action_name)
  if not isinstance(action, QminiNativeAction):
    raise TypeError(f"Expected QminiNativeAction, got {type(action).__name__}")
  error = torch.mean(torch.square(action.frequency - target_hz), dim=1)
  return torch.exp(-error / max(std_hz, 1.0e-6) ** 2)


def sf_sole_phase_contact_match(
  env,
  sensor_name: str,
  frequency_hz: float,
  phase_offset: float,
  double_support_threshold: float = 0.1,
) -> torch.Tensor:
  """Reward the same alternating support clock used by the Isaac controller."""
  sensor: ContactSensor = env.scene[sensor_name]
  assert sensor.data.found is not None
  contact = sensor.data.found > 0
  phase_angle = (
    2.0 * torch.pi * frequency_hz
    * env.episode_length_buf.float() * env.step_dt
    + phase_offset
  )
  sine = torch.sin(phase_angle)
  double_support = torch.abs(sine) < double_support_threshold
  desired_columns = []
  for name in sensor.primary_names:
    lowered = name.lower()
    if "left" in lowered:
      desired = sine < 0.0
    elif "right" in lowered:
      desired = sine >= 0.0
    else:
      desired = torch.ones_like(sine, dtype=torch.bool)
    desired_columns.append(desired | double_support)
  desired_contact = torch.stack(desired_columns, dim=1)
  return (contact == desired_contact).float().mean(dim=1)


def sf_sole_accepted_alignment_reward(
  env,
  command_name: str,
  forward_axis_index: int = 0,
  forward_axis_sign: float = 1.0,
  min_root_height: float = 0.38,
  max_root_height: float = 0.62,
  fallen_projected_gravity_z: float = -0.35,
  asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
  """Port the accepted Isaac SF-sole speed/heading corridor to MJLab.

  The 1.779 Hz contact clock remains a separate reward so cadence quality is
  independently visible in training logs.  The coefficients below match the
  user-accepted Isaac custom reward.
  """
  robot: Entity = env.scene[asset_cfg.name]
  command = env.command_manager.get_command(command_name)
  assert command is not None, f"Command '{command_name}' not found."

  root_lin_vel = robot.data.root_link_lin_vel_b
  root_ang_vel = robot.data.root_link_ang_vel_b
  projected_gravity = robot.data.projected_gravity_b
  root_height, terrain_valid = root_clearance(env, robot, return_valid=True)
  forward_velocity = root_lin_vel[:, forward_axis_index] * forward_axis_sign
  lateral_velocity = root_lin_vel[:, 1 - forward_axis_index]

  reward_target = command[:, 0]
  target_magnitude = torch.abs(reward_target)
  command_direction = torch.where(reward_target < 0.0, -1.0, 1.0)
  directed_speed = forward_velocity * command_direction
  target_active = (target_magnitude > 0.05).float()
  speed_error = directed_speed - target_magnitude
  speed_reward = torch.exp(-torch.square(speed_error) / 0.06)
  progress_reward = 2.0 * torch.clamp(
    directed_speed / torch.clamp(target_magnitude, min=0.05),
    min=-1.0,
    max=1.2,
  ) * target_active
  underspeed_error = torch.clamp(target_magnitude - directed_speed, min=0.0)
  stall_error = torch.clamp(
    target_magnitude * 0.3 - directed_speed, min=0.0
  ) * target_active
  overspeed_error = torch.clamp(
    directed_speed - target_magnitude * 1.2, min=0.0
  )

  heading_error = torch.atan2(
    torch.sin(robot.data.heading_w), torch.cos(robot.data.heading_w)
  )
  env_origins = getattr(env.scene, "env_origins", None)
  root_xy = robot.data.root_link_pos_w[:, :2]
  if env_origins is not None:
    root_xy = root_xy - env_origins[:, :2]
  low_height_error = torch.clamp(min_root_height - root_height, min=0.0)
  high_height_error = torch.clamp(root_height - max_root_height, min=0.0)

  upright = torch.clamp((-projected_gravity[:, 2] - 0.2) / 0.8, 0.0, 1.0)
  yaw_reward_gate = torch.exp(-1.2 * torch.abs(root_ang_vel[:, 2]))
  heading_reward_gate = torch.exp(-0.8 * torch.abs(heading_error))
  height_reward_gate = torch.clamp((root_height - 0.36) / 0.08, 0.0, 1.0)
  speed_terms = (
    speed_reward + progress_reward
  ) * upright * yaw_reward_gate * heading_reward_gate * torch.square(height_reward_gate)
  fallen = (projected_gravity[:, 2] > fallen_projected_gravity_z).float()

  return torch.where(terrain_valid, (
    speed_terms
    - 2.0 * torch.square(speed_error)
    - 4.0 * torch.square(underspeed_error)
    - 6.0 * torch.square(stall_error)
    - 8.0 * torch.square(overspeed_error)
    - 1.5 * torch.abs(root_ang_vel[:, 2])
    - 0.5 * torch.abs(heading_error)
    - 2.5 * torch.abs(lateral_velocity)
    - 0.5 * torch.abs(root_xy[:, 1 - forward_axis_index])
    - 1.5 * torch.abs(root_lin_vel[:, 2])
    - 2.0 * torch.norm(projected_gravity[:, :2], dim=1)
    - 100.0 * (low_height_error + torch.square(low_height_error))
    - 100.0 * (high_height_error + torch.square(high_height_error))
    - 15.0 * fallen
  ), 0.)


def policy_residual_l2(env) -> torch.Tensor:
  """Penalize fast residual motion without penalizing the reference gait itself."""
  return torch.mean(torch.square(env.action_manager.action), dim=1)


class debounced_fall:
  """Apply the shared startup grace period and persistent-failure duration."""

  def __init__(self, cfg, env):
    del cfg
    self._failure_time = torch.zeros(env.num_envs, dtype=torch.float, device=env.device)

  def __call__(
    self,
    env,
    limit_angle: float,
    minimum_height: float,
    grace_time_s: float,
    failure_time_s: float,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
  ) -> torch.Tensor:
    asset: Entity = env.scene[asset_cfg.name]
    projected_gravity = asset.data.projected_gravity_b
    bad_orientation = (
      torch.acos(torch.clamp(-projected_gravity[:, 2], -1.0, 1.0)).abs()
      > limit_angle
    )
    bad_height = torch.zeros_like(bad_orientation)
    if minimum_height > 0.0:
      clearance, valid = root_clearance(env, asset, return_valid=True)
      bad_height = valid & (clearance < minimum_height)
    outside_grace = env.episode_length_buf.float() * env.step_dt >= grace_time_s
    failing = outside_grace & (bad_orientation | bad_height)
    self._failure_time = torch.where(
      failing,
      self._failure_time + env.step_dt,
      torch.zeros_like(self._failure_time),
    )
    return self._failure_time >= max(failure_time_s, env.step_dt)

  def reset(self, env_ids: torch.Tensor | slice | None = None) -> None:
    self._failure_time[env_ids] = 0.0


class delayed_ground_contact:
  """Terminate when any configured robot link contacts terrain after grace."""

  def __init__(self, cfg, env):
    del cfg, env

  def __call__(
    self,
    env,
    sensor_name: str,
    force_threshold: float,
    grace_time_s: float,
  ) -> torch.Tensor:
    sensor: ContactSensor = env.scene[sensor_name]
    force = getattr(sensor.data, "force", None)
    if force is not None:
      contact = torch.linalg.vector_norm(force, dim=-1) > force_threshold
    else:
      found = sensor.data.found
      assert found is not None
      contact = found > 0
    while contact.ndim > 1:
      contact = torch.any(contact, dim=-1)
    outside_grace = env.episode_length_buf.float() * env.step_dt >= grace_time_s
    return outside_grace & contact


class PolicyFrameHistory:
    def __init__(self, num_envs, frames, dim, device, order="old_to_new", initialize="zero"):
        if order not in ("old_to_new", "new_to_old") or initialize not in ("zero", "repeat_first"):
            raise ValueError("Invalid policy observation history settings")
        self.order = order
        self.initialize = initialize
        self.buffer = torch.zeros(num_envs, frames, dim, device=device)
        self.pending = torch.ones(num_envs, dtype=torch.bool, device=device)

    def reset(self, env_ids=None):
        ids = slice(None) if env_ids is None else env_ids
        self.buffer[ids] = 0.0
        self.pending[ids] = True

    def append(self, frame):
        if self.initialize == "repeat_first":
            self.buffer[self.pending] = frame[self.pending].unsqueeze(1)
        self.pending[:] = False
        self.buffer = torch.roll(self.buffer, shifts=-1, dims=1)
        self.buffer[:, -1] = frame
        ordered = self.buffer.flip(1) if self.order == "new_to_old" else self.buffer
        return ordered.flatten(start_dim=1)



import torch

class SpecialObservations:
    def __init__(self, config, num_envs, device):
        self.config = config or {}
        self.num_envs = num_envs
        self.device = device
        history = self.config.get('history')
        self.buffer = torch.zeros(num_envs, history['frames'], device=device) if history else None
        self.ticks = torch.full((num_envs,), -1, dtype=torch.long, device=device)

    def reset(self, env_ids=None):
        ids = slice(None) if env_ids is None else env_ids
        self.ticks[ids] = -1
        if self.buffer is not None:
            self.buffer[ids] = 0

    def history(self, sources, tick):
        settings = self.config.get('history')
        if not settings:
            return
        source = sources.get(settings['source'])
        component = settings['component']
        if source is None or component < 0 or component >= source.shape[1]:
            raise RuntimeError('Signal history source is unavailable: ' + settings['source'])
        value = source[:, component]
        fresh = (self.ticks < 0) | (tick < self.ticks)
        advance = fresh | (tick != self.ticks)
        shifted = torch.cat((self.buffer[:, 1:], value[:, None]), dim=1)
        initial = value[:, None].expand_as(self.buffer) if settings['initialize'] == 'repeat_first' else torch.cat((torch.zeros_like(self.buffer[:, 1:]), value[:, None]), dim=1)
        shifted = torch.where(fresh[:, None], initial, shifted)
        self.buffer[:] = torch.where(advance[:, None], shifted, self.buffer)
        self.ticks.copy_(tick)
        sources['signal_history'] = self.buffer.flip(1) if settings['order'] == 'new_to_old' else self.buffer.clone()

def motor_targets(robot, joints, modes):
    ids = [robot.joint_names.index(name) for name in joints]
    attributes = {'position': 'joint_pos_target', 'velocity': 'joint_vel_target', 'effort': 'joint_effort_target'}
    return torch.stack([getattr(robot.data, attributes[mode])[:, joint] for joint, mode in zip(ids, modes, strict=True)], dim=1).clone()

def contact_signal(force, threshold):
    # One output per configured body: norm of the net terrain contact force.
    return (torch.linalg.vector_norm(force, dim=-1) > threshold).float()

def mjlab_special_sources(env, sources, settings, joints, modes, native_ctrl=False):
    if settings.get('motorTargets'):
        if native_ctrl:
            terms = list(env.action_manager._terms.values())
            if len(terms) != 1 or terms[0].processed_actions.shape[1] != len(modes):
                raise RuntimeError('Native ctrl target order is unavailable')
            sources['motor_target_cache'] = terms[0].processed_actions.clone()
        else:
            sources['motor_target_cache'] = motor_targets(env.scene['robot'], joints, modes)
    contact = settings.get('contact')
    if contact:
        values = []
        for index in range(len(contact['bodies'])):
            force = env.scene['policy_contact_' + str(index)].data.force
            if force is None:
                raise RuntimeError('Terrain contact force is unavailable')
            # Each sensor binds one body and one net-force slot; reject shape drift.
            if force.numel() != env.num_envs * 3:
                raise RuntimeError('Terrain contact sensor must resolve exactly one body')
            values.append(contact_signal(force.reshape(env.num_envs, 3), contact['threshold']))
        sources['foot_contact'] = torch.stack(values, dim=1)


class policy_channel_history:
  """One independent, resettable history per Actor/Critic observation term."""
  def __init__(self, cfg, env):
    params = cfg.params
    self.env = env
    self.special = SpecialObservations(params["special_observations"], env.num_envs, env.device) if params.get("special_observations") else None
    self.history = PolicyFrameHistory(
      env.num_envs, params["history_frames"], len(params["channels"]), env.device,
      params["history_order"], params["history_initialize"],
    )

  def reset(self, env_ids=None):
    self.history.reset(env_ids)
    if self.special is not None: self.special.reset(env_ids)
    observer = getattr(self.env, "_stackforce_virtual_servo", None)
    if observer is not None: observer.reset(env_ids)

  def __call__(self, env, channels, joint_names, source_scales, phase_period_s,
               history_frames, history_order, history_initialize, constant_value=0.0, source_noise=None,
               special_observations=None, action_joints=(), action_modes=(), native_ctrl=False,
               virtual_servo=None, phase_idle=None, imu_randomization=None):
    kwargs = dict(special_state=self.special, action_joints=action_joints, action_modes=action_modes, native_ctrl=native_ctrl) if self.special is not None else {}
    frame = policy_channel_observation(env, channels, joint_names, source_scales, phase_period_s, constant_value, source_noise=source_noise, virtual_servo=virtual_servo, phase_idle=phase_idle, imu_randomization=imu_randomization, **kwargs)
    return self.history.append(frame)


def policy_channel_observation(
  env,
  channels,
  joint_names,
  source_scales,
  phase_period_s: float,
  constant_value: float = 0.0,
  command_name: str = "twist",
  source_noise=None,
  special_state=None, action_joints=(), action_modes=(), native_ctrl=False,
  virtual_servo=None, phase_idle=None, imu_randomization=None,
) -> torch.Tensor:
  """Assemble an explicitly wired scalar OBS bus in the authored order."""
  robot: Entity = env.scene["robot"]
  needed = {channel[0] for channel in channels}
  if special_state is not None and special_state.config.get('history'):
    needed.add(special_state.config['history']['source'])
  joint_ids = [robot.joint_names.index(name) for name in joint_names]
  phase = policy_phase(env, phase_period_s, phase_idle, command_name)
  heading = robot.data.heading_w
  reach = env.command_manager.get_term('reach') if 'reach' in env.command_manager.active_terms else None
  command = reach.command if reach is not None else env.command_manager.get_command(command_name)
  command_scale = torch.tensor(
    source_scales["command"], dtype=torch.float, device=env.device
  )
  gyro, gravity = robot.data.root_link_ang_vel_b, robot.data.projected_gravity_b
  if imu_randomization is not None:
    from .imu_randomization import randomized_imu
    gyro, gravity = randomized_imu(env, gyro, gravity, imu_randomization)
  sources = {
    "base_linear_velocity": robot.data.root_link_lin_vel_b * source_scales["linear_velocity"],
    "base_angular_velocity": gyro * source_scales["angular_velocity"],
    "projected_gravity": gravity,
    "commands": command * command_scale,
    "joint_position_error": (
      robot.data.joint_pos[:, joint_ids] - robot.data.default_joint_pos[:, joint_ids]
    ) * source_scales["joint_position"],
    "joint_velocity": robot.data.joint_vel[:, joint_ids] * source_scales["joint_velocity"],
    "previous_actions": env.hardware_action.raw_actions if hasattr(env, "hardware_action") else env.action_manager.action,
    "phase_sin_cos": torch.stack(
      (torch.sin(2.0 * torch.pi * phase), torch.cos(2.0 * torch.pi * phase)), dim=1
    ),
    "heading_sin_cos": torch.stack((torch.sin(heading), torch.cos(heading)), dim=1),
  }
  if needed.intersection(('target_position', 'end_effector_error')):
    if reach is None:
      raise RuntimeError('Reach observations require a manipulator task')
    sources['target_position'] = reach.command
    sources['end_effector_error'] = reach.error()
  if virtual_servo is not None:
    from .virtual_servo import virtual_servo_state
    observer = virtual_servo_state(env, joint_names, virtual_servo)
    sources.update({"virtual_joint_position_error": (observer.q-observer.default)*source_scales["joint_position"],
                    "virtual_joint_velocity": observer.dq*source_scales["joint_velocity"],
                    "applied_actions": observer.applied})
  if needed.intersection(("virtual_servo_position_error", "virtual_servo_velocity", "encoder_position", "encoder_velocity")):
    feedback = getattr(env, "hardware_feedback", None)
    if feedback is None:
      raise RuntimeError("Hardware observation requested without a configured producer")
    values = feedback.observe(env.episode_length_buf, robot.data.joint_pos[:, env.hardware_feedback_joint_ids])
    for name, value in values.items():
      sources[name] = value * source_scales["joint_velocity" if name.endswith("velocity") else "joint_position"]
  if "height_scan" in needed:
    height_scan = envs_mdp.height_scan(
      env, "terrain_scan", offset=source_scales["height_offset"]
    ) * source_scales["height_scale"]
    height_clip = source_scales["height_clip"]
    if height_clip is not None:
      height_scan = torch.clamp(height_scan, min=height_clip[0], max=height_clip[1])
    sources["height_scan"] = height_scan
  if any(name.startswith('reference_') for name in needed):
    from .reference_task import reference_observations
    sources.update(reference_observations(env))
  if 'base_orientation' in needed:
    w,x,y,z = robot.data.root_link_quat_w.unbind(-1)
    sources['base_orientation'] = torch.stack((torch.atan2(2*(w*x+y*z),1-2*(x*x+y*y)),torch.asin((2*(w*y-z*x)).clamp(-1,1))),dim=1)
  if 'joint_position' in needed:
    sources['joint_position'] = robot.data.joint_pos[:, joint_ids]
  if special_state is not None:
    sources['constant_zero'] = torch.full((env.num_envs, 1), constant_value, dtype=torch.float, device=env.device)
    mjlab_special_sources(env, sources, special_state.config, action_joints, action_modes, native_ctrl)
  for source_name, amplitude in (source_noise or {}).items():
    if imu_randomization and imu_randomization.get("enabled", False) and source_name in ("base_angular_velocity", "projected_gravity"):
      continue
    if amplitude and source_name in sources:
      value = sources[source_name]
      sources[source_name] = value + (torch.rand_like(value) * 2.0 - 1.0) * amplitude
  if special_state is not None:
    special_state.history(sources, env.episode_length_buf)
  output = []
  for source_name, component, scale, bias, clip in channels:
    if source_name == "constant_zero":
      value = torch.full((env.num_envs, 1), constant_value, dtype=torch.float, device=env.device)
    else:
      source = sources.get(source_name)
      if source is None:
        raise RuntimeError(f"Policy observation source is unavailable: {source_name}")
      if component < 0 or component >= source.shape[-1]:
        raise RuntimeError(f"Policy observation component is out of range: {source_name}[{component}]")
      value = source[:, component:component + 1]
    value = value * float(scale) + float(bias)
    if clip is not None:
      value = torch.clamp(value, min=float(clip[0]), max=float(clip[1]))
    output.append(value)
  return torch.cat(output, dim=1)


def policy_phase(env, period_s, phase_idle=None, command_name="twist"):
  phase = fixed_step_phase_cycles(env, period_s) if _EXACT_PHASE_STEP_CLOCK else torch.remainder(env.episode_length_buf.float()*env.step_dt/period_s, 1.)
  if phase_idle is not None:
    command = env.command_manager.get_command(command_name)
    idle = torch.linalg.vector_norm(command[:, :2], dim=1) + command[:, 2].abs() <= phase_idle["commandThreshold"]
    phase = torch.where(idle, float(phase_idle["cycles"]), phase)
  return phase


def phase_sin_cos(env, period_s: float, phase_idle=None) -> torch.Tensor:
  phase = policy_phase(env, period_s, phase_idle)
  return torch.stack(
    (torch.sin(2.0 * torch.pi * phase), torch.cos(2.0 * torch.pi * phase)),
    dim=1,
  )



def swing_direction_cost(
  relative_velocity_h, local_phase, command_h, contact_force,
  swing_fraction, swing_start, swing_end, command_threshold,
  force_threshold, target_speed_ratio, max_target_speed, velocity_std, aggregation,
):
  """One-sided speed shortfall during unloaded mid-swing; landing is exempt."""
  if not 0 < swing_fraction < 1 or not 0 <= swing_start < swing_end <= 1:
    raise ValueError("Invalid swing direction phase window")
  if not all(0 < x < float("inf") for x in (target_speed_ratio, max_target_speed, velocity_std)):
    raise ValueError("Swing direction speed settings must be positive and finite")
  if not all(0 <= x < float("inf") for x in (command_threshold, force_threshold)):
    raise ValueError("Swing direction thresholds must be nonnegative and finite")
  speed = torch.linalg.vector_norm(command_h, dim=-1)
  direction = command_h / speed[:, None].clamp(min=1.e-6)
  along = (relative_velocity_h * direction[:, None, :]).sum(-1)
  target = (speed * target_speed_ratio).clamp(max=max_target_speed)
  swing_progress = local_phase / swing_fraction
  # A smooth mid-swing window avoids a reward jump at its edges. No request
  # for forward relative foot speed at touchdown, where braking is needed.
  window_phase = ((swing_progress-swing_start)/(swing_end-swing_start)).clamp(0, 1)
  gate = torch.sin(torch.pi * window_phase).square()
  gate *= ((swing_progress > swing_start) & (swing_progress < swing_end)).to(gate.dtype)
  gate *= (contact_force <= force_threshold).to(gate.dtype)
  gate *= (speed > command_threshold)[:, None].to(gate.dtype)
  cost = ((target[:, None]-along).clamp(min=0)/velocity_std).square() * gate
  if aggregation == "mean":
    return cost.mean(dim=1)
  if aggregation == "worst_foot":
    return cost.amax(dim=1)
  raise ValueError("Invalid swing direction aggregation")


def phase_foot_swing_direction(
  env, asset_cfg, sensor_name, period_s, phase_offsets, swing_fraction,
  swing_start, swing_end, command_threshold, force_threshold,
  target_speed_ratio, max_target_speed, velocity_std, aggregation,
  command_name, forward_axis_index=0, forward_axis_sign=1.0,
):
  """Relative site velocity in the yaw-only frame, including frame rotation.

  This uses simulation state for reward evaluation only, never actor inputs.
  The supplied site order must equal the contact sensor's mapped foot order.
  """
  asset = env.scene[asset_cfg.name]
  position = asset.data.site_pos_w[:, asset_cfg.site_ids]
  velocity = asset.data.site_lin_vel_w[:, asset_cfg.site_ids]
  force = torch.linalg.vector_norm(env.scene[sensor_name].data.force, dim=-1)
  if position.shape[1] != len(phase_offsets) or force.shape[1] != len(phase_offsets):
    raise ValueError("Swing direction phases/sites/contact feet must have matching order and count")
  if not 0 < period_s < float("inf") or forward_axis_index not in (0, 1) or forward_axis_sign not in (-1, 1):
    raise ValueError("Invalid swing direction period or forward axis")
  if any(not 0 <= x < 1 for x in phase_offsets):
    raise ValueError("Swing direction phase offsets must be in [0,1)")
  w, x, y, z = asset.data.root_link_quat_w.unbind(-1)
  forward = torch.stack((1-2*(y*y+z*z), 2*(x*y+w*z), 2*(x*z-w*y)), dim=-1)
  forward_dot = torch.cross(asset.data.root_link_ang_vel_w, forward, dim=-1)
  norm_xy_sq = forward[:, :2].square().sum(-1).clamp(min=1.e-8)
  yaw_rate = (forward[:, 0]*forward_dot[:, 1]-forward[:, 1]*forward_dot[:, 0])/norm_xy_sq
  cosine, sine = (forward[:, :2]/norm_xy_sq.sqrt()[:, None]).unbind(-1)
  delta = position-asset.data.root_link_pos_w[:, None, :]
  relative = velocity-asset.data.root_link_lin_vel_w[:, None, :]
  # Derivative of R_yaw^-1 * (p_foot-p_root), not just the velocity difference.
  vx = relative[:, :, 0] + yaw_rate[:, None]*delta[:, :, 1]
  vy = relative[:, :, 1] - yaw_rate[:, None]*delta[:, :, 0]
  relative_h = torch.stack((cosine[:, None]*vx+sine[:, None]*vy,
                           -sine[:, None]*vx+cosine[:, None]*vy), dim=-1)
  command = env.command_manager.get_command(command_name)
  command_h = torch.zeros_like(command[:, :2])
  command_h[:, forward_axis_index] = command[:, 0]*forward_axis_sign
  command_h[:, 1-forward_axis_index] = command[:, 1]
  offsets = torch.as_tensor(phase_offsets, device=position.device, dtype=position.dtype)
  local_phase = torch.remainder(env.episode_length_buf[:, None]*env.step_dt/period_s + offsets[None, :], 1.)
  return swing_direction_cost(relative_h, local_phase, command_h, force,
    swing_fraction, swing_start, swing_end, command_threshold, force_threshold,
    target_speed_ratio, max_target_speed, velocity_std, aggregation)



def phase_foot_clearance(
  env,
  height_sensor_name: str,
  target_height: float,
  period_s: float,
  phase_offsets: list[float],
  aggregation: str,
  command_name: str,
  command_threshold: float,
  swing_fraction: float = 0.5,
) -> torch.Tensor:
  """Dense alternating-foot target, including policies that never break contact."""
  sensor = env.scene[height_sensor_name]
  assert isinstance(sensor, TerrainHeightSensor)
  heights = torch.clamp(sensor.data.heights, min=0.0)
  if heights.shape[1] != len(phase_offsets):
    raise ValueError("phase_offsets must match the number of foot height frames")
  offsets = torch.as_tensor(phase_offsets, device=heights.device, dtype=heights.dtype)
  phase = env.episode_length_buf.to(heights.dtype) * env.step_dt / max(period_s, 1.0e-6)
  if not 0.0 < swing_fraction < 1.0:
    raise ValueError("swing_fraction must be between zero and one")
  if swing_fraction == 0.5:
    # Preserve the legacy half-cycle waveform, including boundary behavior.
    swing = torch.clamp(torch.sin(2.0 * torch.pi * (phase[:, None] + offsets[None, :])), min=0.0)
  else:
    local_phase = torch.remainder(phase[:, None] + offsets[None, :], 1.0)
    swing = torch.where(local_phase < swing_fraction,
      torch.sin(torch.pi * local_phase / swing_fraction), 0.0)
  target = target_height * swing
  command = env.command_manager.get_command(command_name)
  assert command is not None
  active = (torch.linalg.vector_norm(command[:, :2], dim=1) + torch.abs(command[:, 2]) > command_threshold).to(heights.dtype)
  error = torch.abs(heights - target) / max(target_height, 1.0e-6)
  if aggregation == "worst_foot":
    return torch.amax(error, dim=1) * active
  if aggregation == "mean":
    return torch.mean(error, dim=1) * active
  raise ValueError(f"Unsupported foot error aggregation: {aggregation}")


def phase_foot_contact(
  env,
  sensor_name: str,
  period_s: float,
  phase_offsets: list[float],
  force_threshold: float,
  aggregation: str,
  command_name: str,
  command_threshold: float,
  swing_fraction: float = 0.5,
  load_transfer_weight: float = 0.0,
) -> torch.Tensor:
  """Penalize real ground contact during swing and absent contact during stance."""
  sensor: ContactSensor = env.scene[sensor_name]
  if sensor.data.force is None:
    raise RuntimeError(f"Foot-contact sensor {sensor_name} has no force field")
  force = torch.linalg.vector_norm(sensor.data.force, dim=-1)
  if force.shape[1] != len(phase_offsets):
    raise ValueError("phase_offsets must match the number of contact-sensor feet")
  offsets = torch.as_tensor(phase_offsets, device=force.device, dtype=force.dtype)
  phase = env.episode_length_buf.to(force.dtype) * env.step_dt / max(period_s, 1.0e-6)
  if not 0.0 < swing_fraction < 1.0:
    raise ValueError("swing_fraction must be between zero and one")
  if swing_fraction == 0.5:
    desired_swing = torch.sin(2.0 * torch.pi * (phase[:, None] + offsets[None, :])) > 0.0
  else:
    local_phase = torch.remainder(phase[:, None] + offsets[None, :], 1.0)
    desired_swing = (local_phase > 0.0) & (local_phase < swing_fraction)
  touching = force > force_threshold
  mismatch = torch.logical_xor(desired_swing, ~touching).float()
  if not 0.0 <= load_transfer_weight < float("inf"):
    raise ValueError("load_transfer_weight must be finite and non-negative")
  if load_transfer_weight > 0.0:
    # Supply dense feedback before a loaded swing foot crosses the binary
    # contact threshold. Retain the binary term: unloading alone is not lift.
    stance = (~desired_swing).to(force.dtype)
    desired_share = stance / stance.sum(dim=1, keepdim=True).clamp(min=1.0)
    actual_share = force / force.sum(dim=1, keepdim=True).clamp(min=max(force_threshold, 1.0e-6))
    mismatch = mismatch + load_transfer_weight * torch.abs(actual_share - desired_share)
  command = env.command_manager.get_command(command_name)
  assert command is not None
  active = (torch.linalg.vector_norm(command[:, :2], dim=1) + torch.abs(command[:, 2]) > command_threshold).float()
  if aggregation == "worst_foot":
    return torch.amax(mismatch, dim=1) * active
  if aggregation == "mean":
    return torch.mean(mismatch, dim=1) * active
  raise ValueError(f"Unsupported foot contact aggregation: {aggregation}")


def ground_contact_point_slip(
  env,
  sensor_name: str,
  force_threshold: float,
  command_name: str,
  command_threshold: float,
) -> torch.Tensor:
  """Penalize the measured ground contact point's xy velocity, including foot rotation."""
  sensor: ContactSensor = env.scene[sensor_name]
  if sensor.data.force is None or sensor.data.pos is None or sensor.data.found is None:
    raise RuntimeError(f"Contact-point sensor {sensor_name} must expose force, pos and found")
  asset: Entity = env.scene["robot"]
  if sensor.cfg.primary.mode == "geom":
    model = env.sim.mj_model
    names = [model.body(int(model.geom(f"{sensor.cfg.primary.entity}/{name}").bodyid[0])).name.rsplit("/", 1)[-1] for name in sensor.primary_names]
  else:
    names = [name.rsplit("/", 1)[-1] for name in sensor.primary_names]
  body_ids = [asset.body_names.index(name) for name in names]
  if sensor.data.pos.shape[1] != len(body_ids):
    raise ValueError("Contact-point sensor must have one slot per foot body")
  point_offset = sensor.data.pos - asset.data.body_link_pos_w[:, body_ids, :]
  point_velocity = asset.data.body_link_lin_vel_w[:, body_ids, :] + torch.cross(
    asset.data.body_link_ang_vel_w[:, body_ids, :], point_offset, dim=-1
  )
  loaded = (sensor.data.found > 0) & (torch.linalg.vector_norm(sensor.data.force, dim=-1) > force_threshold)
  command = env.command_manager.get_command(command_name)
  assert command is not None
  active = (torch.linalg.vector_norm(command[:, :2], dim=1) + torch.abs(command[:, 2]) > command_threshold).float()
  return torch.sum(torch.square(point_velocity[:, :, :2]).sum(dim=-1) * loaded.float(), dim=1) * active


def selected_ground_contact_cost(
  env,
  sensor_name: str,
  force_threshold: float,
) -> torch.Tensor:
  """Count selected robot links bearing ground contact above a force threshold."""
  sensor: ContactSensor = env.scene[sensor_name]
  if sensor.data.force is None:
    raise RuntimeError(f"Ground-contact sensor {sensor_name} has no force field")
  return (torch.linalg.vector_norm(sensor.data.force, dim=-1) > force_threshold).float().sum(dim=1)


def heading_sin_cos(
  env,
  asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
  asset: Entity = env.scene[asset_cfg.name]
  heading = asset.data.heading_w
  return torch.stack((torch.sin(heading), torch.cos(heading)), dim=1)


def track_linear_velocity_robot_frame(
  env,
  std: float,
  command_name: str,
  forward_axis_index: int,
  forward_axis_sign: float,
  asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
  """Track logical forward/lateral velocity for nonstandard robot body axes."""
  asset: Entity = env.scene[asset_cfg.name]
  command = env.command_manager.get_command(command_name)
  assert command is not None, f"Command '{command_name}' not found."
  actual = asset.data.root_link_lin_vel_b
  lateral_axis_index = 1 if forward_axis_index == 0 else 0
  logical_forward = actual[:, forward_axis_index] * forward_axis_sign
  logical_lateral = actual[:, lateral_axis_index]
  xy_error = torch.square(command[:, 0] - logical_forward)
  xy_error += torch.square(command[:, 1] - logical_lateral)
  z_error = torch.square(actual[:, 2])
  return torch.exp(-(xy_error + z_error) / std**2)


def commanded_forward_progress(
  env,
  command_name: str,
  forward_axis_index: int,
  forward_axis_sign: float,
  asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
  reference_frame: str = "world",
) -> torch.Tensor:
  """Signed progress in the explicit GUI-selected frame; legacy default is world."""
  asset: Entity = env.scene[asset_cfg.name]
  command = env.command_manager.get_command(command_name)
  assert command is not None, f"Command '{command_name}' not found."
  requested = command[:, 0]
  if reference_frame not in ("robot", "world"):
    raise ValueError("forward_progress.reference_frame must be robot or world")
  velocity = asset.data.root_link_lin_vel_b if reference_frame == "robot" else asset.data.root_link_lin_vel_w
  progress = velocity[:, forward_axis_index] * forward_axis_sign
  return torch.clamp(progress * torch.sign(requested), min=-1.0, max=1.0) * torch.clamp(torch.abs(requested), max=1.0)


def base_height_gaussian(
  env,
  target_height: float,
  std: float,
  low_height_recovery_scale: float = 0.0,
  asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
  """Reward standing height and retain a recovery gradient below the target."""
  asset: Entity = env.scene[asset_cfg.name]
  clearance, terrain_valid = root_clearance(env, asset, return_valid=True)
  height_error = clearance - target_height
  gaussian = torch.exp(-torch.square(height_error) / max(std, 1.0e-6) ** 2)
  low_height_error = torch.clamp(-height_error, min=0.0)
  recovery = low_height_recovery_scale * low_height_error / max(target_height, 1.0e-6)
  return torch.where(terrain_valid, gaussian - recovery, 0.)


def track_angular_velocity_with_heading(
  env,
  std: float,
  command_name: str,
  heading_std: float,
  yaw_only: bool,
  asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
  """Track yaw rate and start heading without a vanishing recovery gradient."""
  asset: Entity = env.scene[asset_cfg.name]
  command = env.command_manager.get_command(command_name)
  assert command is not None, f"Command '{command_name}' not found."
  actual = asset.data.root_link_ang_vel_b
  angular_error = torch.square(command[:, 2] - actual[:, 2])
  if not yaw_only:
    angular_error += torch.sum(torch.square(actual[:, :2]), dim=1)
  heading = torch.atan2(torch.sin(asset.data.heading_w), torch.cos(asset.data.heading_w))
  # A product of narrow Gaussians becomes effectively zero after an already
  # trained policy has drifted beyond either tolerance.  The cosine term gives
  # global heading feedback, while the signed quadratic term makes sustained
  # yaw unambiguously worse instead of leaving a positive local optimum.
  heading_alignment = 0.5 * (torch.cos(heading) + 1.0)
  heading_alignment = torch.pow(
    torch.clamp(heading_alignment, min=0.0, max=1.0),
    0.25 / max(heading_std, 1.0e-6),
  )
  return heading_alignment - 0.5 * angular_error


def reset_joints_by_scale(
  env,
  env_ids: torch.Tensor | None,
  position_scale_range: tuple[float, float],
  velocity_range: tuple[float, float],
  asset_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> None:
  if env_ids is None:
    env_ids = torch.arange(env.num_envs, device=env.device)
  asset: Entity = env.scene[asset_cfg.name]
  default_joint_pos = asset.data.default_joint_pos
  default_joint_vel = asset.data.default_joint_vel
  soft_joint_pos_limits = asset.data.soft_joint_pos_limits
  assert default_joint_pos is not None
  assert default_joint_vel is not None
  assert soft_joint_pos_limits is not None

  joint_ids = asset_cfg.joint_ids
  joint_pos = default_joint_pos[env_ids][:, joint_ids].clone()
  scale = torch.empty_like(joint_pos).uniform_(*position_scale_range)
  joint_pos.mul_(scale)
  limits = soft_joint_pos_limits[env_ids][:, joint_ids]
  joint_pos.clamp_(limits[..., 0], limits[..., 1])

  joint_vel = default_joint_vel[env_ids][:, joint_ids].clone()
  joint_vel.add_(torch.empty_like(joint_vel).uniform_(*velocity_range))
  if isinstance(joint_ids, list):
    joint_ids = torch.tensor(joint_ids, device=env.device)
  asset.write_joint_state_to_sim(
    joint_pos.view(len(env_ids), -1),
    joint_vel.view(len(env_ids), -1),
    env_ids=env_ids,
    joint_ids=joint_ids,
  )
