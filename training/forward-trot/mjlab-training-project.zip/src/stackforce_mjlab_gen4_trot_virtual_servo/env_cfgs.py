"""MJLab velocity task aligned with the SimReady policy and terrain contract."""

import math
import json
from dataclasses import replace
from copy import deepcopy

from mjlab.envs import ManagerBasedRlEnvCfg
from mjlab.envs import mdp as envs_mdp
from mjlab.envs.mdp.actions import JointPositionActionCfg
from mjlab.managers.event_manager import EventTermCfg
from mjlab.managers.curriculum_manager import CurriculumTermCfg
from mjlab.managers.observation_manager import ObservationTermCfg
from mjlab.managers.reward_manager import RewardTermCfg

from . import locomotion_rewards as extended_rewards
from mjlab.managers.scene_entity_config import SceneEntityCfg
from mjlab.managers.termination_manager import TerminationTermCfg
from mjlab.sensor import (
  ContactMatch,
  ContactSensorCfg,
  GridPatternCfg,
  ObjRef,
  RingPatternCfg,
  TerrainHeightSensorCfg,
)
from mjlab.tasks.velocity.mdp import UniformVelocityCommandCfg
from mjlab.tasks.velocity.velocity_env_cfg import make_velocity_env_cfg
from .terrain import configure_terrain
from mjlab.utils.noise import UniformNoiseCfg as Unoise


from .velocity_curriculum import failure_termination, gated_velocity_curriculum
from .prolonged_standstill import ProlongedStandstill
from .contact_capacity import configure_contact_capacity
from .policy_mdp import (
  QminiNativeActionCfg,
  SfSoleReferenceActionCfg,
  PhaseReferenceActionCfg,
  StackForceMixedJointActionCfg,
  base_height_gaussian,
  debounced_fall,
  delayed_ground_contact,
  heading_sin_cos,
  phase_sin_cos,
  phase_foot_clearance,
  phase_foot_contact,
  phase_foot_swing_direction,
  ground_contact_point_slip,
  yaw_rate_error,
  selected_ground_contact_cost,
  commanded_forward_progress,
  policy_channel_observation,
  policy_channel_history,
  policy_residual_l2,
  qmini_frequency_tracking,
  qmini_native_observation,
  reset_joints_by_scale,
  sf_sole_accepted_alignment_reward,
  sf_sole_phase_contact_match,
  track_angular_velocity_with_heading,
  track_linear_velocity_robot_frame,
)
from .robot_constants import (
  ACTION_SCALE,
  ACTION_SPECS,
  ACTUATED_JOINTS,
  ACTUATED_JOINT_PATTERNS,
  STATE_JOINT_PATTERNS,
  BASE_BODY,
  FOOT_BODY_PATTERNS,
  FOOT_GEOM_PATTERNS,
  FOOT_SITE_NAMES,
  POSITION_JOINT_PATTERNS,
  get_robot_cfg,
)


def stackforce_env_cfg(play: bool = False) -> ManagerBasedRlEnvCfg:
  import json
  cfg = make_velocity_env_cfg()
  cfg.scene.entities = {"robot": get_robot_cfg()}
  cfg.scene.num_envs = 1


  assert cfg.scene.terrain is not None
  training_uses_rough_terrain = False
  terrain_curriculum_enabled = False
  configure_terrain(cfg, "plane" if play or not training_uses_rough_terrain else "mixed",
    scale=0.107, seed=7,
    curriculum=terrain_curriculum_enabled, legacy=True)
  # Larger articulated meshes (for example Unitree B2) exceed MJLab's generic
  # 35-contact default during model compilation even with a single environment.
  cfg.sim.nconmax = 128
  cfg.sim.njmax = 512
  cfg.sim.contact_sensor_maxmatch = 128
  cfg.episode_length_s = 20
  cfg.sim.mujoco.timestep = 0.001

  cfg.sim.mujoco.integrator = "implicitfast"


  cfg.decimation = 20
  from .numerical_timing import configure_timing
  configure_timing(cfg, __file__)


  sensors = {sensor.name: sensor for sensor in (cfg.scene.sensors or ())}
  selected_sensors = []
  if False:
    terrain_scan = sensors["terrain_scan"]
    terrain_scan.frame = ObjRef(type="body", name=BASE_BODY, entity="robot")
    terrain_scan.debug_vis = False
    selected_sensors.append(terrain_scan)

  if True:
    foot_height_scan = sensors["foot_height_scan"]
    assert isinstance(foot_height_scan, TerrainHeightSensorCfg)
    foot_height_scan.frame = tuple(
      ObjRef(type="site", name=name, entity="robot") for name in FOOT_SITE_NAMES
    )
    foot_height_scan.pattern = RingPatternCfg.single_ring(radius=0.03, num_samples=4)
    foot_height_scan.debug_vis = False
    selected_sensors.append(foot_height_scan)
    selected_sensors.append(ContactSensorCfg(
      name="feet_ground_contact",
      primary=ContactMatch(mode="geom", pattern=FOOT_GEOM_PATTERNS, entity="robot"),
      secondary=ContactMatch(mode="body", pattern="terrain"),
      fields=("found", "force"),
      reduce="netforce",
      num_slots=1,
      track_air_time=True,
    ))
    selected_sensors.append(ContactSensorCfg(
      name="feet_contact_point",
      primary=ContactMatch(mode="geom", pattern=FOOT_GEOM_PATTERNS, entity="robot"),
      secondary=ContactMatch(mode="body", pattern="terrain"),
      fields=("found", "force", "pos"),
      reduce="maxforce",
      num_slots=1,
    ))

  selected_sensors.append(ContactSensorCfg(
    name="non_foot_ground_contact",
    primary=ContactMatch(mode="geom", pattern=".*", exclude=FOOT_GEOM_PATTERNS, entity="robot"),
    secondary=ContactMatch(mode="body", pattern="terrain"),
    fields=("found", "force"), reduce="netforce", num_slots=1,
  ))

  cfg.scene.sensors = tuple(selected_sensors)

  # Build the actor in the exact frame order declared by backend_task.v1.
  actor = cfg.observations["actor"]
  terms = actor.terms
  terms["phase_sin_cos"] = ObservationTermCfg(
    func=phase_sin_cos, params={"period_s": 0.44, "phase_idle": {"cycles":0.75,"commandThreshold":0.000001}}
  )
  terms["heading_sin_cos"] = ObservationTermCfg(func=heading_sin_cos)
  terms["base_lin_vel"].scale = 1
  terms["base_ang_vel"].scale = 1
  terms["command"].scale = (
    1,
    1,
    1,
  )
  terms["joint_pos"].params["biased"] = False
  terms["joint_pos"].scale = 1
  terms["joint_vel"].scale = 1


  for term in terms.values():
    term.noise = None
  actor.terms = {
    "policy_bus": ObservationTermCfg(
      func=policy_channel_history,
      params={
        "virtual_servo": {"kp":35,"kd":1.2,"inertia":1},
        "phase_idle": {"cycles":0.75,"commandThreshold":0.000001},
        "imu_randomization": None,
        "source_noise": {},
        "channels": [("base_angular_velocity", 0, 1.0, 0.0, None), ("base_angular_velocity", 1, 1.0, 0.0, None), ("base_angular_velocity", 2, 1.0, 0.0, None), ("projected_gravity", 0, 1.0, 0.0, None), ("projected_gravity", 1, 1.0, 0.0, None), ("projected_gravity", 2, 1.0, 0.0, None), ("commands", 0, 1.0, 0.0, None), ("commands", 1, 1.0, 0.0, None), ("commands", 2, 1.0, 0.0, None), ("phase_sin_cos", 0, 1.0, 0.0, None), ("phase_sin_cos", 1, 1.0, 0.0, None), ("virtual_joint_position_error", 0, 1.0, 0.0, None), ("virtual_joint_position_error", 1, 1.0, 0.0, None), ("virtual_joint_position_error", 2, 1.0, 0.0, None), ("virtual_joint_position_error", 3, 1.0, 0.0, None), ("virtual_joint_position_error", 4, 1.0, 0.0, None), ("virtual_joint_position_error", 5, 1.0, 0.0, None), ("virtual_joint_position_error", 6, 1.0, 0.0, None), ("virtual_joint_position_error", 7, 1.0, 0.0, None), ("virtual_joint_position_error", 8, 1.0, 0.0, None), ("virtual_joint_position_error", 9, 1.0, 0.0, None), ("virtual_joint_position_error", 10, 1.0, 0.0, None), ("virtual_joint_position_error", 11, 1.0, 0.0, None), ("virtual_joint_velocity", 0, 1.0, 0.0, None), ("virtual_joint_velocity", 1, 1.0, 0.0, None), ("virtual_joint_velocity", 2, 1.0, 0.0, None), ("virtual_joint_velocity", 3, 1.0, 0.0, None), ("virtual_joint_velocity", 4, 1.0, 0.0, None), ("virtual_joint_velocity", 5, 1.0, 0.0, None), ("virtual_joint_velocity", 6, 1.0, 0.0, None), ("virtual_joint_velocity", 7, 1.0, 0.0, None), ("virtual_joint_velocity", 8, 1.0, 0.0, None), ("virtual_joint_velocity", 9, 1.0, 0.0, None), ("virtual_joint_velocity", 10, 1.0, 0.0, None), ("virtual_joint_velocity", 11, 1.0, 0.0, None), ("applied_actions", 0, 1.0, 0.0, None), ("applied_actions", 1, 1.0, 0.0, None), ("applied_actions", 2, 1.0, 0.0, None), ("applied_actions", 3, 1.0, 0.0, None), ("applied_actions", 4, 1.0, 0.0, None), ("applied_actions", 5, 1.0, 0.0, None), ("applied_actions", 6, 1.0, 0.0, None), ("applied_actions", 7, 1.0, 0.0, None), ("applied_actions", 8, 1.0, 0.0, None), ("applied_actions", 9, 1.0, 0.0, None), ("applied_actions", 10, 1.0, 0.0, None), ("applied_actions", 11, 1.0, 0.0, None)],
        "history_frames": 6,
        "history_order": "old_to_new",
        "history_initialize": "zero",
        "joint_names": ("FL_abad_joint", "FL_thigh_joint", "FL_calf_joint", "FR_abad_joint", "FR_thigh_joint", "FR_calf_joint", "RL_abad_joint", "RL_thigh_joint", "RL_calf_joint", "RR_abad_joint", "RR_thigh_joint", "RR_calf_joint"),
        "phase_period_s": 0.44,
        "constant_value": 0.0,
        "source_scales": {
          "linear_velocity": 1.0,
          "angular_velocity": 1.0,
          "command": (1.0, 1.0, 1.0),
          "joint_position": 1.0,
          "joint_velocity": 1.0,
          "height_offset": 0.0,
          "height_scale": 1.0,
          "height_clip": None,
        },
      },
    ),
  }
  actor.enable_corruption = False
  actor.history_length = None
  actor.flatten_history_dim = True
  critic = cfg.observations["critic"]
  critic.terms = {
    "policy_bus": ObservationTermCfg(
      func=policy_channel_history,
      params={
        "virtual_servo": {"kp":35,"kd":1.2,"inertia":1},
        "phase_idle": {"cycles":0.75,"commandThreshold":0.000001},
        "imu_randomization": None,
        "source_noise": {},
        "channels": [("base_linear_velocity", 0, 1.0, 0.0, None), ("base_linear_velocity", 1, 1.0, 0.0, None), ("base_linear_velocity", 2, 1.0, 0.0, None), ("base_angular_velocity", 0, 1.0, 0.0, None), ("base_angular_velocity", 1, 1.0, 0.0, None), ("base_angular_velocity", 2, 1.0, 0.0, None), ("projected_gravity", 0, 1.0, 0.0, None), ("projected_gravity", 1, 1.0, 0.0, None), ("projected_gravity", 2, 1.0, 0.0, None), ("commands", 0, 1.0, 0.0, None), ("commands", 1, 1.0, 0.0, None), ("commands", 2, 1.0, 0.0, None), ("phase_sin_cos", 0, 1.0, 0.0, None), ("phase_sin_cos", 1, 1.0, 0.0, None), ("virtual_joint_position_error", 0, 1.0, 0.0, None), ("virtual_joint_position_error", 1, 1.0, 0.0, None), ("virtual_joint_position_error", 2, 1.0, 0.0, None), ("virtual_joint_position_error", 3, 1.0, 0.0, None), ("virtual_joint_position_error", 4, 1.0, 0.0, None), ("virtual_joint_position_error", 5, 1.0, 0.0, None), ("virtual_joint_position_error", 6, 1.0, 0.0, None), ("virtual_joint_position_error", 7, 1.0, 0.0, None), ("virtual_joint_position_error", 8, 1.0, 0.0, None), ("virtual_joint_position_error", 9, 1.0, 0.0, None), ("virtual_joint_position_error", 10, 1.0, 0.0, None), ("virtual_joint_position_error", 11, 1.0, 0.0, None), ("virtual_joint_velocity", 0, 1.0, 0.0, None), ("virtual_joint_velocity", 1, 1.0, 0.0, None), ("virtual_joint_velocity", 2, 1.0, 0.0, None), ("virtual_joint_velocity", 3, 1.0, 0.0, None), ("virtual_joint_velocity", 4, 1.0, 0.0, None), ("virtual_joint_velocity", 5, 1.0, 0.0, None), ("virtual_joint_velocity", 6, 1.0, 0.0, None), ("virtual_joint_velocity", 7, 1.0, 0.0, None), ("virtual_joint_velocity", 8, 1.0, 0.0, None), ("virtual_joint_velocity", 9, 1.0, 0.0, None), ("virtual_joint_velocity", 10, 1.0, 0.0, None), ("virtual_joint_velocity", 11, 1.0, 0.0, None), ("applied_actions", 0, 1.0, 0.0, None), ("applied_actions", 1, 1.0, 0.0, None), ("applied_actions", 2, 1.0, 0.0, None), ("applied_actions", 3, 1.0, 0.0, None), ("applied_actions", 4, 1.0, 0.0, None), ("applied_actions", 5, 1.0, 0.0, None), ("applied_actions", 6, 1.0, 0.0, None), ("applied_actions", 7, 1.0, 0.0, None), ("applied_actions", 8, 1.0, 0.0, None), ("applied_actions", 9, 1.0, 0.0, None), ("applied_actions", 10, 1.0, 0.0, None), ("applied_actions", 11, 1.0, 0.0, None), ("joint_position_error", 0, 1.0, 0.0, None), ("joint_position_error", 1, 1.0, 0.0, None), ("joint_position_error", 2, 1.0, 0.0, None), ("joint_position_error", 3, 1.0, 0.0, None), ("joint_position_error", 4, 1.0, 0.0, None), ("joint_position_error", 5, 1.0, 0.0, None), ("joint_position_error", 6, 1.0, 0.0, None), ("joint_position_error", 7, 1.0, 0.0, None), ("joint_position_error", 8, 1.0, 0.0, None), ("joint_position_error", 9, 1.0, 0.0, None), ("joint_position_error", 10, 1.0, 0.0, None), ("joint_position_error", 11, 1.0, 0.0, None), ("joint_velocity", 0, 1.0, 0.0, None), ("joint_velocity", 1, 1.0, 0.0, None), ("joint_velocity", 2, 1.0, 0.0, None), ("joint_velocity", 3, 1.0, 0.0, None), ("joint_velocity", 4, 1.0, 0.0, None), ("joint_velocity", 5, 1.0, 0.0, None), ("joint_velocity", 6, 1.0, 0.0, None), ("joint_velocity", 7, 1.0, 0.0, None), ("joint_velocity", 8, 1.0, 0.0, None), ("joint_velocity", 9, 1.0, 0.0, None), ("joint_velocity", 10, 1.0, 0.0, None), ("joint_velocity", 11, 1.0, 0.0, None)],
        "history_frames": 1,
        "history_order": "old_to_new",
        "history_initialize": "zero",
        "joint_names": ("FL_abad_joint", "FL_thigh_joint", "FL_calf_joint", "FR_abad_joint", "FR_thigh_joint", "FR_calf_joint", "RL_abad_joint", "RL_thigh_joint", "RL_calf_joint", "RR_abad_joint", "RR_thigh_joint", "RR_calf_joint"),
        "phase_period_s": 0.44,
        "constant_value": 0.0,
        "source_scales": {
          "linear_velocity": 1.0,
          "angular_velocity": 1.0,
          "command": (1.0, 1.0, 1.0),
          "joint_position": 1.0,
          "joint_velocity": 1.0,
          "height_offset": 0.0,
          "height_scale": 1.0,
          "height_clip": None,
        },
      },
    ),
  }
  critic.enable_corruption = False
  critic.history_length = None
  critic.flatten_history_dim = True

  action = cfg.actions["joint_pos"]
  assert isinstance(action, JointPositionActionCfg)
  action.actuator_names = ACTUATED_JOINT_PATTERNS
  action.scale = ACTION_SCALE
  action.use_default_offset = True
  from .virtual_servo import VirtualServoPositionActionCfg
  cfg.actions["joint_pos"] = VirtualServoPositionActionCfg(**vars(cfg.actions["joint_pos"]), joint_names=ACTUATED_JOINTS,
    target_velocity_limit=0, target_smoothing_alpha=1, target_resolution_rad=0)

  cfg.viewer.body_name = BASE_BODY
  cfg.events.pop("encoder_bias", None)
  cfg.events.pop("base_com", None)
  cfg.events["reset_base"].params["pose_range"] = {
    "x": (0, 0),
    "y": (0, 0),
    "z": (0.0, 0.0),
    "yaw": (0.0, 0.0),
  }
  cfg.events["reset_base"].params["velocity_range"] = {
    "x": (0, 0), "y": (0, 0), "z": (0, 0),
    "roll": (0, 0), "pitch": (0, 0), "yaw": (0, 0),
  }
  cfg.events["reset_robot_joints"].func = reset_joints_by_scale
  cfg.events["reset_robot_joints"].params = {
    "position_scale_range": (1, 1),
    "velocity_range": (0.0, 0.0),
    "asset_cfg": SceneEntityCfg("robot", joint_names=STATE_JOINT_PATTERNS),
  }

  if False:
    cfg.events["foot_friction"].params["asset_cfg"].geom_names = FOOT_GEOM_PATTERNS
    cfg.events["foot_friction"].params["ranges"] = (1, 1)
  else:
    cfg.events.pop("foot_friction", None)
  if False:
    cfg.events["push_robot"].interval_range_s = (
      15, 15
    )
    cfg.events["push_robot"].params["velocity_range"] = {
      "x": (0, 0),
      "y": (0, 0),
    }
  else:
    cfg.events.pop("push_robot", None)

  if True:
    cfg.rewards["air_time"].weight = 0.25
    cfg.rewards["foot_clearance"].params["asset_cfg"] = SceneEntityCfg(
      "robot", site_names=FOOT_SITE_NAMES
    )
    cfg.rewards["foot_slip"].params["asset_cfg"] = SceneEntityCfg(
      "robot", site_names=FOOT_SITE_NAMES
    )
    cfg.rewards["phase_foot_clearance"] = RewardTermCfg(
      func=phase_foot_clearance,
      weight=-4,
      params={
        "height_sensor_name": "foot_height_scan",
        "target_height": 0.035,
        "period_s": 0.44,
        "phase_offsets": [0,0.5,0,0.5],
        "swing_fraction": 0.45,
        "aggregation": "mean",
        "command_name": "twist",
        "command_threshold": 0.02,
      },
    )
    cfg.rewards["phase_foot_contact"] = RewardTermCfg(
      func=phase_foot_contact,
      weight=-2.5,
      params={
        "sensor_name": "feet_ground_contact",
        "period_s": 0.44,
        "phase_offsets": [0,0.5,0,0.5],
        "swing_fraction": 0.45,
        "load_transfer_weight": 0.5,
        "force_threshold": 0.2,
        "aggregation": "mean",
        "command_name": "twist",
        "command_threshold": 0.02,
      },
    )

    cfg.rewards["ground_contact_point_slip"] = RewardTermCfg(
      func=ground_contact_point_slip,
      weight=-0.5,
      params={
        "sensor_name": "feet_contact_point",
        "force_threshold": 0.2,
        "command_name": "twist",
        "command_threshold": 0.02,
      },
    )
  else:
    for key in ("air_time", "foot_clearance", "foot_swing_height", "foot_slip", "soft_landing"):
      cfg.rewards.pop(key, None)

  cfg.rewards["termination"] = RewardTermCfg(
    func=failure_termination, weight=-50,
    params={"per_event": True},
  )
  cfg.rewards["track_linear_velocity"].weight = 4


  cfg.rewards["prolonged_standstill"] = RewardTermCfg(
    func=ProlongedStandstill, weight=-2,
    params={"command_threshold": 0.1, "speed_threshold": 0.08, "command_speed_ratio": 0.25,
            "window_seconds": 0.8, "grace_seconds": 1.0, "ramp_seconds": 1.5,
            "forward_axis_index": 0,
            "forward_axis_sign": 1.0},
  )
  cfg.rewards["yaw_rate_error"] = RewardTermCfg(func=yaw_rate_error, weight=-0.5)
  cfg.rewards["track_angular_velocity"].weight = 1

  cfg.rewards["upright"].weight = 2
  cfg.rewards["upright"].params["asset_cfg"] = SceneEntityCfg(
    "robot", body_names=(rf"^base_link$",)
  )
  cfg.rewards["pose"].weight = 0.15
  cfg.rewards["base_height"] = RewardTermCfg(
    func=base_height_gaussian,
    weight=2,
    params={
      "target_height": 0.107,
      "std": 0.015,
      "low_height_recovery_scale": 0,
      "asset_cfg": SceneEntityCfg("robot"),
    },
  )

  cfg.rewards["non_foot_ground_contact"] = RewardTermCfg(
    func=selected_ground_contact_cost, weight=-5,
    params={"sensor_name": "non_foot_ground_contact", "force_threshold": 0.2},
  )
  cfg.rewards["body_ang_vel"].weight = -0.05
  cfg.rewards["body_ang_vel"].params["asset_cfg"] = SceneEntityCfg(
    "robot", body_names=(rf"^base_link$",)
  )
  cfg.rewards["angular_momentum"].weight = 0.0
  cfg.rewards["dof_pos_limits"].weight = -1
  cfg.rewards["action_rate_l2"].weight = -0.03

  posture_patterns = POSITION_JOINT_PATTERNS or STATE_JOINT_PATTERNS
  cfg.rewards["pose"].params["asset_cfg"] = SceneEntityCfg(
    "robot", joint_names=posture_patterns
  )
  posture_std = {".*": 0.8}
  cfg.rewards["pose"].params["std_standing"] = {".*": 0.5}
  cfg.rewards["pose"].params["std_walking"] = posture_std
  cfg.rewards["pose"].params["std_running"] = {".*": 1}

  if play or not training_uses_rough_terrain:
    cfg.terminations.pop("out_of_terrain_bounds", None)
  cfg.terminations.pop("nonfinite_state", None)
  cfg.terminations.pop("fell_over", None)
  cfg.terminations.pop("illegal_contact", None)
  cfg.terminations["nonfinite_state"] = TerminationTermCfg(
    func=envs_mdp.nan_detection,
  )
  cfg.terminations["fell_over"] = TerminationTermCfg(
    func=debounced_fall,
    params={
      "limit_angle": 1.0471975511965976,
      "minimum_height": 0.06,
      "grace_time_s": 0.5,
      "failure_time_s": 0.15,
    },
  )

  cfg.terminations.pop("base_height", None)

  if play or not terrain_curriculum_enabled:
    cfg.curriculum.pop("terrain_levels", None)
  cfg.curriculum.pop("command_vel", None)

  command = cfg.commands["twist"]
  assert isinstance(command, UniformVelocityCommandCfg)
  command.resampling_time_range = (
    3, 8
  )
  command.rel_standing_envs = 0.5
  command.rel_forward_envs = 0
  command.heading_command = False
  command.rel_heading_envs = 0
  command.heading_control_stiffness = 0.5
  command.ranges = UniformVelocityCommandCfg.Ranges(
    lin_vel_x=(-0.1, -0.1),
    lin_vel_y=(0, 0),
    ang_vel_z=(0, 0),
    heading=None,
  )
  cfg.rewards["track_linear_velocity"].func = extended_rewards.track_planar_velocity
  cfg.rewards["track_angular_velocity"].func = extended_rewards.track_yaw_velocity
  cfg.rewards["phase_foot_clearance"] = RewardTermCfg(
    func=extended_rewards.phase_foot_clearance, weight=-4,
    params={"command_name": "twist", "period_s": 0.44, "foot_geom_names": json.loads("[\"FL_wheel_collision_0\",\"FR_wheel_collision_0\",\"RR_wheel_collision_0\",\"RL_wheel_collision_0\"]"), "height_sensor_name": "foot_height_scan", **json.loads("{\"height_source\":\"sphere_bottom\",\"worst_foot_weight\":0.25,\"peak_tracking_weight\":3,\"peak_symmetry_weight\":0,\"peak_tolerance\":0.001,\"profile_tracking_weight\":0.25,\"peak_tracking_aggregation\":\"worst_valid\",\"target_height\":0.035,\"phase_offsets\":[0,0.5,0,0.5],\"swing_fraction\":0.45,\"command_threshold\":0.02,\"aggregation\":\"mean\",\"target_heights\":[0.035,0.035,0.035,0.035],\"peak_tolerances\":[0.001,0.001,0.001,0.001],\"direction_target_heights\":[[0.03525251672153113,0.034140771747075575,0.034675769859335626,0.034636219680915785],[0.033950305783917716,0.034453996046148426,0.03488942699389313,0.036284611791825044],[0.03380170878137292,0.03630692452006228,0.03353469612703349,0.03614254875888507],[0.035771157537597055,0.03411774679856623,0.035788949285443385,0.035879637526682905],[0.034555664637804684,0.037412185019828625,0.034077343925909116,0.03514910226068685],[0.03602226513616815,0.03347643789906446,0.03577737988172143,0.03938944730435454]],\"direction_peak_tolerances\":[[0.001,0.001,0.001,0.001],[0.001,0.001,0.001,0.001],[0.001,0.001,0.001,0.001],[0.001,0.001,0.001,0.001],[0.001,0.001,0.001,0.001],[0.001,0.001,0.001,0.001]],\"direction_command_scales\":[0.1,1,1]}")},
  )
  cfg.rewards["phase_foot_contact"] = RewardTermCfg(
    func=extended_rewards.phase_foot_contact, weight=-2.5,
    params={"command_name": "twist", "period_s": 0.44, "sensor_name": "feet_ground_contact", **json.loads("{\"swing_unload_weight\":0,\"phase_zero_is_swing\":false,\"phase_offsets\":[0,0.5,0,0.5],\"swing_fraction\":0.45,\"load_transfer_weight\":0.5,\"force_threshold\":0.2,\"command_threshold\":0.02,\"aggregation\":\"mean\"}")},
  )
  cfg.rewards["phase_foot_horizontal_stride"] = RewardTermCfg(
    func=extended_rewards.phase_foot_horizontal_stride, weight=-4,
    params={"command_name": "twist", "period_s": 0.44, "foot_geom_names": json.loads("[\"FL_wheel_collision_0\",\"FR_wheel_collision_0\",\"RR_wheel_collision_0\",\"RL_wheel_collision_0\"]"), "forward_axis_index": 0, "forward_axis_sign": 1, "sensor_name": "feet_ground_contact", **json.loads("{\"phase_offsets\":[0,0.5,0,0.5],\"swing_fraction\":0.45,\"min_excursion\":0.03,\"target_ratio\":1,\"relative_tolerance\":0.1,\"symmetry_weight\":0.5,\"force_threshold\":0.2,\"command_threshold\":0.03,\"lateral_threshold\":0.003,\"yaw_threshold\":0.01,\"min_excursion_reference_speed\":0.1,\"minimum_air_seconds\":0.04,\"minimum_air_height\":0.003,\"maximum_air_fraction\":0.9,\"actual_air_weight\":0,\"symmetry_floor_at_target\":false,\"symmetry_floor_reference\":\"minimum\",\"planar_straight\":true,\"actual_air_dense_weight\":0,\"actual_air_dense_aggregation\":\"worst_valid\",\"actual_air_shortfall_cost\":\"linear\",\"actual_air_shortfall_aggregation\":\"worst_valid\",\"actual_air_completed_floor_weight\":2,\"actual_air_dense_linear_weight\":0,\"actual_air_completed_backtracking_weight\":0,\"command_mode\":\"planar_twist\",\"angular_command_threshold\":0.01,\"turn_min_excursion\":0.015,\"turn_reference_yaw_rate\":0.4,\"cycle_shortfall_aggregation\":\"worst_valid\",\"cycle_minimum_excursions\":[0.03,0.03,0.03,0.03],\"cycle_spread_limit\":0.1,\"direction_cycle_minimum_excursions\":[[0.027542164091083024,0.02934903637059667,0.028835807284717543,0.026870680941469324],[0.03328141855015766,0.028667120614784408,0.03071417296424865,0.029421533229213984],[0.020522208654890843,0.020498093945199965,0.02070510022707817,0.020970031793792837],[0.020013100242368503,0.02112395167443346,0.020187689644727603,0.020092905927730435],[0.01484312833328178,0.02658537274158726,0.01862098235049828,0.012678291523841749],[0.02131731094756634,0.015205201982466677,0.02538190479221333,0.021036588614854673]],\"direction_cycle_spread_limits\":[0.13804285267338406,0.2011840589038163,0.07282775830399926,0.10457546201941018,0.8148841850287766,0.540792347919436],\"cycle_command_limits\":[1,0.1,1,1,1,1]}")},
  )
  cfg.rewards["cycle_mean_velocity_error"] = RewardTermCfg(
    func=extended_rewards.cycle_mean_velocity_error, weight=-1,
    params={"command_name": "twist", "forward_axis_index": 0, "forward_axis_sign": 1, "asset_cfg": SceneEntityCfg("robot"), **json.loads("{\"window_seconds\":0.44,\"grace_seconds\":1,\"linear_std\":0.05,\"angular_std\":0.2,\"command_threshold\":0.000001,\"command_change_threshold\":0.001,\"off_axis_weight\":0.25,\"cost_mode\":\"axis_log_huber\",\"track_zero_commands\":true,\"angular_reference\":\"heading_delta\"}")},
  )
  from .command_sampling import with_axis_aligned_sampling
  cfg.commands["twist"] = with_axis_aligned_sampling(cfg.commands["twist"], 0.9,
    axis_boundary_ratio=0.8, axis_interior_ratio=0.5,
    axis_interior_fraction=0.6666666666666666, axis_weights=[2,2,2])
  # Explicit, GUI-owned weights and arguments are applied last. No robot-name overrides.
  import json
  configured_weights = json.loads("{\"phase_foot_swing_direction\":0,\"prolonged_standstill\":-2,\"phase_foot_clearance\":-4,\"phase_foot_contact\":-2.5,\"ground_contact_point_slip\":-0.5,\"forward_progress\":0,\"track_linear_velocity\":4,\"track_angular_velocity\":1,\"yaw_rate_error\":-0.5,\"upright\":2,\"base_height\":2,\"pose\":0.15,\"body_ang_vel\":-0.05,\"non_foot_ground_contact\":-5,\"dof_pos_limits\":-1,\"action_rate_l2\":-0.03,\"termination\":-50,\"air_time\":0,\"foot_clearance\":0,\"foot_swing_height\":0,\"foot_slip\":0,\"soft_landing\":0,\"stance_support\":-4,\"phase_foot_horizontal_stride\":-4,\"phase_foot_swing_advance\":0,\"cycle_mean_velocity_error\":-1}")
  # Model-derived parameters belong to apply_task's replacement reward terms.
  configured_parameters = json.loads("{\"phase_foot_swing_direction\":{\"phase_offsets\":[0,0.5],\"swing_fraction\":0.5,\"swing_start\":0.15,\"swing_end\":0.75,\"command_threshold\":0.1,\"force_threshold\":2,\"target_speed_ratio\":1,\"max_target_speed\":0.6,\"velocity_std\":0.5,\"aggregation\":\"mean\"},\"prolonged_standstill\":{\"command_threshold\":0.025,\"speed_threshold\":0.015,\"command_speed_ratio\":0.2,\"window_seconds\":0.8,\"grace_seconds\":1,\"ramp_seconds\":1},\"non_foot_ground_contact\":{\"force_threshold\":0.2},\"termination\":{\"per_event\":true},\"forward_progress\":{\"reference_frame\":\"robot\"},\"track_linear_velocity\":{\"std\":0.05},\"track_angular_velocity\":{\"std\":0.1},\"upright\":{\"std\":0.4472135954999579},\"pose\":{\"walking_threshold\":0.05,\"running_threshold\":1.5},\"air_time\":{\"threshold_min\":0.05,\"threshold_max\":0.5,\"command_threshold\":0.5},\"foot_clearance\":{\"target_height\":0.1,\"command_threshold\":0.05},\"foot_swing_height\":{\"target_height\":0.1,\"command_threshold\":0.05},\"phase_foot_clearance\":{\"height_source\":\"sphere_bottom\",\"worst_foot_weight\":0.25,\"peak_tracking_weight\":3,\"peak_symmetry_weight\":0,\"peak_tolerance\":0.001,\"target_height\":0.035,\"phase_offsets\":[0,0.5,0,0.5],\"swing_fraction\":0.45,\"command_threshold\":0.02,\"aggregation\":\"mean\",\"profile_tracking_weight\":0.25,\"peak_tracking_aggregation\":\"worst_valid\"},\"phase_foot_contact\":{\"phase_offsets\":[0,0.5,0,0.5],\"swing_fraction\":0.45,\"load_transfer_weight\":0.5,\"swing_unload_weight\":0,\"force_threshold\":0.2,\"command_threshold\":0.02,\"aggregation\":\"mean\"},\"ground_contact_point_slip\":{\"force_threshold\":0.2,\"command_threshold\":0.02},\"foot_slip\":{\"command_threshold\":0.05},\"soft_landing\":{\"command_threshold\":0.05},\"stance_support\":{\"height_source\":\"sphere_bottom\",\"height_scale\":0.035,\"force_threshold\":0.2,\"linear_deadband\":0.005,\"angular_deadband\":0.02,\"height_weight\":1,\"contact_weight\":0.5,\"motion_weight\":1,\"joint_motion_weight\":0.3,\"worst_foot_weight\":0.25,\"linear_speed_std\":0.02,\"angular_speed_std\":0.1,\"motion_cost_mode\":\"bounded\"},\"cycle_mean_velocity_error\":{\"window_seconds\":0.44,\"grace_seconds\":1,\"linear_std\":0.05,\"angular_std\":0.2,\"command_threshold\":0.000001,\"command_change_threshold\":0.001,\"off_axis_weight\":0.25,\"cost_mode\":\"axis_log_huber\",\"track_zero_commands\":true,\"angular_reference\":\"heading_delta\"},\"phase_foot_horizontal_stride\":{\"phase_offsets\":[0,0.5,0,0.5],\"swing_fraction\":0.45,\"min_excursion\":0.03,\"target_ratio\":1,\"relative_tolerance\":0.1,\"symmetry_weight\":0.5,\"force_threshold\":0.2,\"command_threshold\":0.03,\"lateral_threshold\":0.003,\"yaw_threshold\":0.01,\"min_excursion_reference_speed\":0.1,\"minimum_air_seconds\":0.04,\"minimum_air_height\":0.003,\"maximum_air_fraction\":0.9,\"actual_air_weight\":0,\"symmetry_floor_at_target\":false,\"symmetry_floor_reference\":\"minimum\",\"planar_straight\":true,\"actual_air_dense_weight\":0,\"actual_air_dense_aggregation\":\"worst_valid\",\"actual_air_shortfall_cost\":\"linear\",\"actual_air_shortfall_aggregation\":\"worst_valid\",\"actual_air_completed_floor_weight\":2,\"actual_air_dense_linear_weight\":0,\"actual_air_completed_backtracking_weight\":0,\"command_mode\":\"planar_twist\",\"angular_command_threshold\":0.01,\"turn_min_excursion\":0.015,\"turn_reference_yaw_rate\":0.4,\"cycle_shortfall_aggregation\":\"worst_valid\"},\"phase_foot_swing_advance\":{\"phase_offsets\":[0,0.5,0,0.5],\"swing_fraction\":0.45,\"command_threshold\":0.2,\"force_threshold\":0.2,\"target_step_ratio\":1.5,\"max_target_advance\":0.06,\"advance_std\":0.01,\"dense_weight\":0.25,\"aggregation\":\"worst_foot\",\"minimum_reference_feet\":2,\"command_mode\":\"planar_twist\",\"point_source\":\"collision_geom\",\"exclude_swing_references\":true,\"angular_command_threshold\":0.01}}")
  for name, term in cfg.rewards.items():
    if name in configured_weights:
      term.weight = float(configured_weights[name])
    for key, value in configured_parameters.get(name, {}).items():
      if key not in term.params:
        raise ValueError(f"Unknown reward parameter: {name}.{key}")
      term.params[key] = value


  if play:
    cfg.episode_length_s = int(1e9)
    actor.enable_corruption = False
    if "policy_bus" in actor.terms:
      actor.terms["policy_bus"].params["source_noise"] = {}
      actor.terms["policy_bus"].params["imu_randomization"] = None
    if "policy_bus" in critic.terms:
      critic.terms["policy_bus"].params["imu_randomization"] = None
    if "qmini_native_frame" in actor.terms:
      actor.terms["qmini_native_frame"].params.update(angular_noise=0.0, position_noise=0.0, velocity_noise=0.0)
    cfg.events.pop("push_robot", None)
    cfg.events.pop("foot_friction", None)

    cfg.events["reset_base"].params["pose_range"] = {
      "x": (0.0, 0.0), "y": (0.0, 0.0), "z": (0.0, 0.0), "yaw": (0.0, 0.0)
    }
    cfg.events["reset_base"].params["velocity_range"] = {}
    cfg.events["reset_robot_joints"].params["position_scale_range"] = (1.0, 1.0)
    command.resampling_time_range = (1.0e9, 1.0e9)
    command.heading_command = False
    command.rel_heading_envs = 0.0
    command.ranges = UniformVelocityCommandCfg.Ranges(
      lin_vel_x=(-0.1, -0.1),
      lin_vel_y=(0, 0),
      ang_vel_z=(0, 0),
      heading=None,
    )
    cfg.curriculum = {}

  if not any(sensor.name == "foot_height_scan" for sensor in (cfg.scene.sensors or ())):
    cfg.scene.sensors = tuple(cfg.scene.sensors or ()) + (foot_height_scan,)
  cfg.rewards["stance_support"] = RewardTermCfg(
    func=extended_rewards.stance_support, weight=-4,
    params={"command_name": "twist", "sensor_name": "feet_ground_contact", "height_sensor_name": "foot_height_scan",
      "asset_cfg": SceneEntityCfg("robot", site_names=FOOT_SITE_NAMES, preserve_order=True),
      "foot_geom_names": json.loads("[\"FL_wheel_collision_0\",\"FR_wheel_collision_0\",\"RR_wheel_collision_0\",\"RL_wheel_collision_0\"]"),
      **json.loads("{\"height_source\":\"sphere_bottom\",\"height_scale\":0.035,\"force_threshold\":0.2,\"linear_deadband\":0.005,\"angular_deadband\":0.02,\"height_weight\":1,\"contact_weight\":0.5,\"motion_weight\":1,\"joint_motion_weight\":0.3,\"worst_foot_weight\":0.25,\"linear_speed_std\":0.02,\"angular_speed_std\":0.1,\"motion_cost_mode\":\"bounded\"}")},
  )


  from .terrain import configure_terrain_boundary
  configure_terrain_boundary(cfg)


  configure_contact_capacity(cfg)
  return cfg
