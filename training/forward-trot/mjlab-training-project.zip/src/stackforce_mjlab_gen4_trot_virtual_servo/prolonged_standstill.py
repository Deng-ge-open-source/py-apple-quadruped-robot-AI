"""Command-gated no-progress cost, shared by all GUI-configured MJLab robots."""
import math
import torch


class ProlongedStandstill:
    """Measure new signed progress, not repeated excursions over the same ground.

    Track signed travel along the command and its furthest attained progress.
    The window measures advances of that frontier. Returning from a backward
    sway does not count as fresh progress until the previous frontier is passed.
    This also works on curved paths because each displacement is projected in
    the current commanded frame, rather than on an absolute world axis.

    Returns a cost in [0, 1]; the GUI supplies a non-positive reward weight.
    Stops and direction reversals clear the timer. Partial environment resets
    clear only their own history. No observations or actuator parameters change.
    """

    def __init__(self, cfg, env):
        window = float(cfg.params.get('window_seconds', 0.8))
        if not math.isfinite(window) or not 0 < window <= 10:
            raise ValueError('No-progress window must be in (0, 10] seconds')
        self.steps = max(1, math.ceil(window / env.step_dt))
        self.duration = self.steps * env.step_dt
        self.progress_history = torch.zeros(self.steps, env.num_envs, device=env.device)
        self.previous_position = torch.zeros(env.num_envs, 2, device=env.device)
        self.signed_progress = torch.zeros(env.num_envs, device=env.device)
        self.furthest_progress = torch.zeros_like(self.signed_progress)
        self.age = torch.zeros(env.num_envs, device=env.device)
        self.blocked_seconds = torch.zeros_like(self.age)
        self.previous_direction = torch.zeros(env.num_envs, 2, device=env.device)
        self.was_active = torch.zeros(env.num_envs, dtype=torch.bool, device=env.device)
        self.cursor = 0

    def reset(self, env_ids=None):
        ids = slice(None) if env_ids is None else env_ids
        self.progress_history[:, ids] = 0
        self.previous_position[ids] = 0
        self.signed_progress[ids] = 0
        self.furthest_progress[ids] = 0
        self.age[ids] = 0
        self.blocked_seconds[ids] = 0
        self.previous_direction[ids] = 0
        self.was_active[ids] = False

    def __call__(self, env, command_threshold=0.1, speed_threshold=0.08,
                 command_speed_ratio=0.25, window_seconds=0.8,
                 grace_seconds=1.0, ramp_seconds=1.5, command_name='twist',
                 forward_axis_index=0, forward_axis_sign=1.0):
        if forward_axis_index not in (0, 1) or forward_axis_sign not in (-1, 1):
            raise ValueError('Invalid no-progress command forward axis or sign')
        robot = env.scene['robot']
        command = env.command_manager.get_command(command_name)[:, :2]
        magnitude = torch.linalg.vector_norm(command, dim=-1)
        active = magnitude > command_threshold
        direction = command / magnitude.clamp(min=1e-6)[:, None]
        reversed_command = (direction * self.previous_direction).sum(-1) < 0
        restart = active & (~self.was_active | reversed_command)
        position = robot.data.root_link_pos_w[:, :2]
        clear = restart | ~active
        self.progress_history.masked_fill_(clear[None, :], 0)
        self.age.masked_fill_(clear, 0)
        self.blocked_seconds.masked_fill_(clear, 0)
        self.signed_progress.masked_fill_(clear, 0)
        self.furthest_progress.masked_fill_(clear, 0)

        displacement = position - self.previous_position
        yaw = robot.data.heading_w
        c, s = torch.cos(yaw), torch.sin(yaw)
        # Commands are logical forward/lateral; heading_w follows the body's X
        # axis. Match the axis/sign convention of the velocity tracking reward.
        forward = direction[:, 0] * forward_axis_sign
        lateral = direction[:, 1]
        body_x, body_y = (forward, lateral) if forward_axis_index == 0 else (lateral, forward)
        world_direction = torch.stack((c*body_x-s*body_y,
                                       s*body_x+c*body_y), dim=-1)
        increment = (displacement * world_direction).sum(-1).masked_fill(clear, 0)
        self.signed_progress.add_(increment)
        self.furthest_progress.copy_(torch.maximum(self.furthest_progress, self.signed_progress))
        progress_speed = (self.furthest_progress - self.progress_history[self.cursor]) / self.duration
        minimum_speed = torch.clamp(magnitude * command_speed_ratio, max=speed_threshold, min=1e-6)
        ready = self.age >= self.steps
        blocked = active & (~ready | (progress_speed < minimum_speed))
        self.blocked_seconds.copy_(torch.where(blocked, self.blocked_seconds + env.step_dt, 0))
        ramp = torch.clamp((self.blocked_seconds-grace_seconds)/ramp_seconds, min=0, max=1)
        deficit = torch.clamp(1-progress_speed/minimum_speed, min=0, max=1)
        cost = ramp * deficit * active * ready

        self.progress_history[self.cursor].copy_(self.furthest_progress)
        self.previous_position.copy_(position)
        self.cursor = (self.cursor + 1) % self.steps
        self.age.add_(1)
        self.was_active.copy_(active)
        self.previous_direction.copy_(direction)
        return cost
