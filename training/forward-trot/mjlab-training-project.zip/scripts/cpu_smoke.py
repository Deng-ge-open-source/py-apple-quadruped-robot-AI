"""Run one MJLab reset/step entirely on CPU and verify the shared contract."""

import torch
from mjlab.envs.manager_based_rl_env import ManagerBasedRlEnv

from stackforce_mjlab_gen4_trot_virtual_servo.env_cfgs import stackforce_env_cfg
from stackforce_mjlab_gen4_trot_virtual_servo.numerical_timing import project_timing
from pathlib import Path


def main() -> None:
  cfg = stackforce_env_cfg()
  cfg.scene.num_envs = 1
  env = ManagerBasedRlEnv(cfg, device="cpu")
  try:
    env.reset(seed=7)
    action = torch.zeros(
      (env.num_envs, env.action_manager.total_action_dim), device="cpu"
    )
    obs, reward, terminated, truncated, _ = env.step(action)
    assert env.action_manager.total_action_dim == 12
    assert tuple(obs["actor"].shape) == (1, 282)
    timing = project_timing(Path(__file__).resolve().parents[1])["effective"]
    assert abs(env.cfg.sim.mujoco.timestep - timing["simDt"]) < 1.0e-12
    assert env.cfg.decimation == timing["decimation"]
    print(
      {
        "device": env.device,
        "action_dim": env.action_manager.total_action_dim,
        "actor_obs_shape": tuple(obs["actor"].shape),
        "reward": reward.detach().cpu().tolist(),
        "terminated": terminated.detach().cpu().tolist(),
        "truncated": truncated.detach().cpu().tolist(),
      }
    )
  finally:
    env.close()


if __name__ == "__main__":
  main()
