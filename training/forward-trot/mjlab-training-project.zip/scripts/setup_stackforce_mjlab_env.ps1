param(
  [ValidateSet("auto", "cpu", "cu128")]
  [string]$Backend = "auto",
  [switch]$SkipSmoke
)

$ErrorActionPreference = "Stop"

# Run this script from the root or scripts\ folder of a StackForce MJLab export.
$projectCandidates = @($PSScriptRoot, (Split-Path -Parent $PSScriptRoot))
$ProjectRoot = $projectCandidates | Where-Object { Test-Path (Join-Path $_ "pyproject.toml") } | Select-Object -First 1
if (-not $ProjectRoot) {
  throw "pyproject.toml was not found. Put this script in the exported project root or scripts\ folder."
}

$uvCommand = Get-Command uv -ErrorAction SilentlyContinue
$uvPrefix = @()
if ($uvCommand) {
  $uvExe = $uvCommand.Source
} else {
  $pythonCommand = Get-Command py -ErrorAction SilentlyContinue
  if (-not $pythonCommand) { $pythonCommand = Get-Command python -ErrorAction SilentlyContinue }
  if (-not $pythonCommand) { throw "Python was not found. Install Python 3.12 or uv first, then rerun this script." }
  & $pythonCommand.Source -m pip install --user "uv==0.8.19"
  if ($LASTEXITCODE -ne 0) { throw "uv installation failed with exit code $LASTEXITCODE." }
  $uvExe = $pythonCommand.Source
  $uvPrefix = @("-m", "uv")
}

if ($Backend -eq "auto") {
  $Backend = "cpu"
  $nvidiaSmi = Get-Command nvidia-smi -ErrorAction SilentlyContinue
  if ($nvidiaSmi) {
    & $nvidiaSmi.Source | Out-Null
    if ($LASTEXITCODE -eq 0) { $Backend = "cu128" }
  }
}

Push-Location $ProjectRoot
try {
  & $uvExe @uvPrefix python install 3.12
  if ($LASTEXITCODE -ne 0) { throw "Python 3.12 setup failed with exit code $LASTEXITCODE." }
  & $uvExe @uvPrefix sync --extra $Backend
  if ($LASTEXITCODE -ne 0) { throw "MJLab dependency setup failed with exit code $LASTEXITCODE." }
  & $uvExe @uvPrefix run python -m compileall -q src
  if ($LASTEXITCODE -ne 0) { throw "Generated Python source validation failed with exit code $LASTEXITCODE." }

  $taskOutput = (& $uvExe @uvPrefix run list-envs 2>&1 | Out-String)
  Write-Host ($taskOutput.Trim())
  if ($taskOutput -notmatch "Mjlab-Velocity-Flat-") { throw "The exported MJLab task was not discovered." }

  if ($Backend -eq "cpu" -and -not $SkipSmoke -and (Test-Path "scripts\cpu_smoke.py")) {
    & $uvExe @uvPrefix run python scripts\cpu_smoke.py
    if ($LASTEXITCODE -ne 0) { throw "MJLab CPU smoke test failed with exit code $LASTEXITCODE." }
  }

  Write-Host "StackForce MJLab setup completed with backend: $Backend" -ForegroundColor Green
  if ($Backend -eq "cpu") {
    Write-Host "CPU smoke is ready. Use Linux plus NVIDIA CUDA for high-throughput training."
  } else {
    Write-Host "CUDA environment is ready for high-throughput training."
  }
  $uvDisplay = if ($uvPrefix.Count) { "$(Split-Path -Leaf $uvExe) -m uv" } else { "uv" }
  Write-Host "Use $uvDisplay for the training commands shown in the exported README."
} finally {
  Pop-Location
}
